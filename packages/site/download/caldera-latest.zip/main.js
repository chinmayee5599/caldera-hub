"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// (disabled):crypto
var require_crypto = __commonJS({
  "(disabled):crypto"() {
  }
});

// ../../node_modules/tweetnacl/nacl-fast.js
var require_nacl_fast = __commonJS({
  "../../node_modules/tweetnacl/nacl-fast.js"(exports, module2) {
    (function(nacl2) {
      "use strict";
      var gf = function(init) {
        var i, r = new Float64Array(16);
        if (init) for (i = 0; i < init.length; i++) r[i] = init[i];
        return r;
      };
      var randombytes = function() {
        throw new Error("no PRNG");
      };
      var _0 = new Uint8Array(16);
      var _9 = new Uint8Array(32);
      _9[0] = 9;
      var gf0 = gf(), gf1 = gf([1]), _121665 = gf([56129, 1]), D = gf([30883, 4953, 19914, 30187, 55467, 16705, 2637, 112, 59544, 30585, 16505, 36039, 65139, 11119, 27886, 20995]), D2 = gf([61785, 9906, 39828, 60374, 45398, 33411, 5274, 224, 53552, 61171, 33010, 6542, 64743, 22239, 55772, 9222]), X = gf([54554, 36645, 11616, 51542, 42930, 38181, 51040, 26924, 56412, 64982, 57905, 49316, 21502, 52590, 14035, 8553]), Y = gf([26200, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214]), I = gf([41136, 18958, 6951, 50414, 58488, 44335, 6150, 12099, 55207, 15867, 153, 11085, 57099, 20417, 9344, 11139]);
      function ts64(x, i, h, l) {
        x[i] = h >> 24 & 255;
        x[i + 1] = h >> 16 & 255;
        x[i + 2] = h >> 8 & 255;
        x[i + 3] = h & 255;
        x[i + 4] = l >> 24 & 255;
        x[i + 5] = l >> 16 & 255;
        x[i + 6] = l >> 8 & 255;
        x[i + 7] = l & 255;
      }
      function vn(x, xi, y, yi, n) {
        var i, d = 0;
        for (i = 0; i < n; i++) d |= x[xi + i] ^ y[yi + i];
        return (1 & d - 1 >>> 8) - 1;
      }
      function crypto_verify_16(x, xi, y, yi) {
        return vn(x, xi, y, yi, 16);
      }
      function crypto_verify_32(x, xi, y, yi) {
        return vn(x, xi, y, yi, 32);
      }
      function core_salsa20(o, p, k, c) {
        var j0 = c[0] & 255 | (c[1] & 255) << 8 | (c[2] & 255) << 16 | (c[3] & 255) << 24, j1 = k[0] & 255 | (k[1] & 255) << 8 | (k[2] & 255) << 16 | (k[3] & 255) << 24, j2 = k[4] & 255 | (k[5] & 255) << 8 | (k[6] & 255) << 16 | (k[7] & 255) << 24, j3 = k[8] & 255 | (k[9] & 255) << 8 | (k[10] & 255) << 16 | (k[11] & 255) << 24, j4 = k[12] & 255 | (k[13] & 255) << 8 | (k[14] & 255) << 16 | (k[15] & 255) << 24, j5 = c[4] & 255 | (c[5] & 255) << 8 | (c[6] & 255) << 16 | (c[7] & 255) << 24, j6 = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, j7 = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j8 = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, j9 = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, j10 = c[8] & 255 | (c[9] & 255) << 8 | (c[10] & 255) << 16 | (c[11] & 255) << 24, j11 = k[16] & 255 | (k[17] & 255) << 8 | (k[18] & 255) << 16 | (k[19] & 255) << 24, j12 = k[20] & 255 | (k[21] & 255) << 8 | (k[22] & 255) << 16 | (k[23] & 255) << 24, j13 = k[24] & 255 | (k[25] & 255) << 8 | (k[26] & 255) << 16 | (k[27] & 255) << 24, j14 = k[28] & 255 | (k[29] & 255) << 8 | (k[30] & 255) << 16 | (k[31] & 255) << 24, j15 = c[12] & 255 | (c[13] & 255) << 8 | (c[14] & 255) << 16 | (c[15] & 255) << 24;
        var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7, x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14, x15 = j15, u;
        for (var i = 0; i < 20; i += 2) {
          u = x0 + x12 | 0;
          x4 ^= u << 7 | u >>> 32 - 7;
          u = x4 + x0 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x4 | 0;
          x12 ^= u << 13 | u >>> 32 - 13;
          u = x12 + x8 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x1 | 0;
          x9 ^= u << 7 | u >>> 32 - 7;
          u = x9 + x5 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x9 | 0;
          x1 ^= u << 13 | u >>> 32 - 13;
          u = x1 + x13 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x6 | 0;
          x14 ^= u << 7 | u >>> 32 - 7;
          u = x14 + x10 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x14 | 0;
          x6 ^= u << 13 | u >>> 32 - 13;
          u = x6 + x2 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x11 | 0;
          x3 ^= u << 7 | u >>> 32 - 7;
          u = x3 + x15 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x3 | 0;
          x11 ^= u << 13 | u >>> 32 - 13;
          u = x11 + x7 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
          u = x0 + x3 | 0;
          x1 ^= u << 7 | u >>> 32 - 7;
          u = x1 + x0 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x1 | 0;
          x3 ^= u << 13 | u >>> 32 - 13;
          u = x3 + x2 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x4 | 0;
          x6 ^= u << 7 | u >>> 32 - 7;
          u = x6 + x5 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x6 | 0;
          x4 ^= u << 13 | u >>> 32 - 13;
          u = x4 + x7 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x9 | 0;
          x11 ^= u << 7 | u >>> 32 - 7;
          u = x11 + x10 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x11 | 0;
          x9 ^= u << 13 | u >>> 32 - 13;
          u = x9 + x8 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x14 | 0;
          x12 ^= u << 7 | u >>> 32 - 7;
          u = x12 + x15 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x12 | 0;
          x14 ^= u << 13 | u >>> 32 - 13;
          u = x14 + x13 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
        }
        x0 = x0 + j0 | 0;
        x1 = x1 + j1 | 0;
        x2 = x2 + j2 | 0;
        x3 = x3 + j3 | 0;
        x4 = x4 + j4 | 0;
        x5 = x5 + j5 | 0;
        x6 = x6 + j6 | 0;
        x7 = x7 + j7 | 0;
        x8 = x8 + j8 | 0;
        x9 = x9 + j9 | 0;
        x10 = x10 + j10 | 0;
        x11 = x11 + j11 | 0;
        x12 = x12 + j12 | 0;
        x13 = x13 + j13 | 0;
        x14 = x14 + j14 | 0;
        x15 = x15 + j15 | 0;
        o[0] = x0 >>> 0 & 255;
        o[1] = x0 >>> 8 & 255;
        o[2] = x0 >>> 16 & 255;
        o[3] = x0 >>> 24 & 255;
        o[4] = x1 >>> 0 & 255;
        o[5] = x1 >>> 8 & 255;
        o[6] = x1 >>> 16 & 255;
        o[7] = x1 >>> 24 & 255;
        o[8] = x2 >>> 0 & 255;
        o[9] = x2 >>> 8 & 255;
        o[10] = x2 >>> 16 & 255;
        o[11] = x2 >>> 24 & 255;
        o[12] = x3 >>> 0 & 255;
        o[13] = x3 >>> 8 & 255;
        o[14] = x3 >>> 16 & 255;
        o[15] = x3 >>> 24 & 255;
        o[16] = x4 >>> 0 & 255;
        o[17] = x4 >>> 8 & 255;
        o[18] = x4 >>> 16 & 255;
        o[19] = x4 >>> 24 & 255;
        o[20] = x5 >>> 0 & 255;
        o[21] = x5 >>> 8 & 255;
        o[22] = x5 >>> 16 & 255;
        o[23] = x5 >>> 24 & 255;
        o[24] = x6 >>> 0 & 255;
        o[25] = x6 >>> 8 & 255;
        o[26] = x6 >>> 16 & 255;
        o[27] = x6 >>> 24 & 255;
        o[28] = x7 >>> 0 & 255;
        o[29] = x7 >>> 8 & 255;
        o[30] = x7 >>> 16 & 255;
        o[31] = x7 >>> 24 & 255;
        o[32] = x8 >>> 0 & 255;
        o[33] = x8 >>> 8 & 255;
        o[34] = x8 >>> 16 & 255;
        o[35] = x8 >>> 24 & 255;
        o[36] = x9 >>> 0 & 255;
        o[37] = x9 >>> 8 & 255;
        o[38] = x9 >>> 16 & 255;
        o[39] = x9 >>> 24 & 255;
        o[40] = x10 >>> 0 & 255;
        o[41] = x10 >>> 8 & 255;
        o[42] = x10 >>> 16 & 255;
        o[43] = x10 >>> 24 & 255;
        o[44] = x11 >>> 0 & 255;
        o[45] = x11 >>> 8 & 255;
        o[46] = x11 >>> 16 & 255;
        o[47] = x11 >>> 24 & 255;
        o[48] = x12 >>> 0 & 255;
        o[49] = x12 >>> 8 & 255;
        o[50] = x12 >>> 16 & 255;
        o[51] = x12 >>> 24 & 255;
        o[52] = x13 >>> 0 & 255;
        o[53] = x13 >>> 8 & 255;
        o[54] = x13 >>> 16 & 255;
        o[55] = x13 >>> 24 & 255;
        o[56] = x14 >>> 0 & 255;
        o[57] = x14 >>> 8 & 255;
        o[58] = x14 >>> 16 & 255;
        o[59] = x14 >>> 24 & 255;
        o[60] = x15 >>> 0 & 255;
        o[61] = x15 >>> 8 & 255;
        o[62] = x15 >>> 16 & 255;
        o[63] = x15 >>> 24 & 255;
      }
      function core_hsalsa20(o, p, k, c) {
        var j0 = c[0] & 255 | (c[1] & 255) << 8 | (c[2] & 255) << 16 | (c[3] & 255) << 24, j1 = k[0] & 255 | (k[1] & 255) << 8 | (k[2] & 255) << 16 | (k[3] & 255) << 24, j2 = k[4] & 255 | (k[5] & 255) << 8 | (k[6] & 255) << 16 | (k[7] & 255) << 24, j3 = k[8] & 255 | (k[9] & 255) << 8 | (k[10] & 255) << 16 | (k[11] & 255) << 24, j4 = k[12] & 255 | (k[13] & 255) << 8 | (k[14] & 255) << 16 | (k[15] & 255) << 24, j5 = c[4] & 255 | (c[5] & 255) << 8 | (c[6] & 255) << 16 | (c[7] & 255) << 24, j6 = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, j7 = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j8 = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, j9 = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, j10 = c[8] & 255 | (c[9] & 255) << 8 | (c[10] & 255) << 16 | (c[11] & 255) << 24, j11 = k[16] & 255 | (k[17] & 255) << 8 | (k[18] & 255) << 16 | (k[19] & 255) << 24, j12 = k[20] & 255 | (k[21] & 255) << 8 | (k[22] & 255) << 16 | (k[23] & 255) << 24, j13 = k[24] & 255 | (k[25] & 255) << 8 | (k[26] & 255) << 16 | (k[27] & 255) << 24, j14 = k[28] & 255 | (k[29] & 255) << 8 | (k[30] & 255) << 16 | (k[31] & 255) << 24, j15 = c[12] & 255 | (c[13] & 255) << 8 | (c[14] & 255) << 16 | (c[15] & 255) << 24;
        var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7, x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14, x15 = j15, u;
        for (var i = 0; i < 20; i += 2) {
          u = x0 + x12 | 0;
          x4 ^= u << 7 | u >>> 32 - 7;
          u = x4 + x0 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x4 | 0;
          x12 ^= u << 13 | u >>> 32 - 13;
          u = x12 + x8 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x1 | 0;
          x9 ^= u << 7 | u >>> 32 - 7;
          u = x9 + x5 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x9 | 0;
          x1 ^= u << 13 | u >>> 32 - 13;
          u = x1 + x13 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x6 | 0;
          x14 ^= u << 7 | u >>> 32 - 7;
          u = x14 + x10 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x14 | 0;
          x6 ^= u << 13 | u >>> 32 - 13;
          u = x6 + x2 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x11 | 0;
          x3 ^= u << 7 | u >>> 32 - 7;
          u = x3 + x15 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x3 | 0;
          x11 ^= u << 13 | u >>> 32 - 13;
          u = x11 + x7 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
          u = x0 + x3 | 0;
          x1 ^= u << 7 | u >>> 32 - 7;
          u = x1 + x0 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x1 | 0;
          x3 ^= u << 13 | u >>> 32 - 13;
          u = x3 + x2 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x4 | 0;
          x6 ^= u << 7 | u >>> 32 - 7;
          u = x6 + x5 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x6 | 0;
          x4 ^= u << 13 | u >>> 32 - 13;
          u = x4 + x7 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x9 | 0;
          x11 ^= u << 7 | u >>> 32 - 7;
          u = x11 + x10 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x11 | 0;
          x9 ^= u << 13 | u >>> 32 - 13;
          u = x9 + x8 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x14 | 0;
          x12 ^= u << 7 | u >>> 32 - 7;
          u = x12 + x15 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x12 | 0;
          x14 ^= u << 13 | u >>> 32 - 13;
          u = x14 + x13 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
        }
        o[0] = x0 >>> 0 & 255;
        o[1] = x0 >>> 8 & 255;
        o[2] = x0 >>> 16 & 255;
        o[3] = x0 >>> 24 & 255;
        o[4] = x5 >>> 0 & 255;
        o[5] = x5 >>> 8 & 255;
        o[6] = x5 >>> 16 & 255;
        o[7] = x5 >>> 24 & 255;
        o[8] = x10 >>> 0 & 255;
        o[9] = x10 >>> 8 & 255;
        o[10] = x10 >>> 16 & 255;
        o[11] = x10 >>> 24 & 255;
        o[12] = x15 >>> 0 & 255;
        o[13] = x15 >>> 8 & 255;
        o[14] = x15 >>> 16 & 255;
        o[15] = x15 >>> 24 & 255;
        o[16] = x6 >>> 0 & 255;
        o[17] = x6 >>> 8 & 255;
        o[18] = x6 >>> 16 & 255;
        o[19] = x6 >>> 24 & 255;
        o[20] = x7 >>> 0 & 255;
        o[21] = x7 >>> 8 & 255;
        o[22] = x7 >>> 16 & 255;
        o[23] = x7 >>> 24 & 255;
        o[24] = x8 >>> 0 & 255;
        o[25] = x8 >>> 8 & 255;
        o[26] = x8 >>> 16 & 255;
        o[27] = x8 >>> 24 & 255;
        o[28] = x9 >>> 0 & 255;
        o[29] = x9 >>> 8 & 255;
        o[30] = x9 >>> 16 & 255;
        o[31] = x9 >>> 24 & 255;
      }
      function crypto_core_salsa20(out, inp, k, c) {
        core_salsa20(out, inp, k, c);
      }
      function crypto_core_hsalsa20(out, inp, k, c) {
        core_hsalsa20(out, inp, k, c);
      }
      var sigma = new Uint8Array([101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]);
      function crypto_stream_salsa20_xor(c, cpos, m, mpos, b, n, k) {
        var z = new Uint8Array(16), x = new Uint8Array(64);
        var u, i;
        for (i = 0; i < 16; i++) z[i] = 0;
        for (i = 0; i < 8; i++) z[i] = n[i];
        while (b >= 64) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < 64; i++) c[cpos + i] = m[mpos + i] ^ x[i];
          u = 1;
          for (i = 8; i < 16; i++) {
            u = u + (z[i] & 255) | 0;
            z[i] = u & 255;
            u >>>= 8;
          }
          b -= 64;
          cpos += 64;
          mpos += 64;
        }
        if (b > 0) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < b; i++) c[cpos + i] = m[mpos + i] ^ x[i];
        }
        return 0;
      }
      function crypto_stream_salsa20(c, cpos, b, n, k) {
        var z = new Uint8Array(16), x = new Uint8Array(64);
        var u, i;
        for (i = 0; i < 16; i++) z[i] = 0;
        for (i = 0; i < 8; i++) z[i] = n[i];
        while (b >= 64) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < 64; i++) c[cpos + i] = x[i];
          u = 1;
          for (i = 8; i < 16; i++) {
            u = u + (z[i] & 255) | 0;
            z[i] = u & 255;
            u >>>= 8;
          }
          b -= 64;
          cpos += 64;
        }
        if (b > 0) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < b; i++) c[cpos + i] = x[i];
        }
        return 0;
      }
      function crypto_stream(c, cpos, d, n, k) {
        var s = new Uint8Array(32);
        crypto_core_hsalsa20(s, n, k, sigma);
        var sn = new Uint8Array(8);
        for (var i = 0; i < 8; i++) sn[i] = n[i + 16];
        return crypto_stream_salsa20(c, cpos, d, sn, s);
      }
      function crypto_stream_xor(c, cpos, m, mpos, d, n, k) {
        var s = new Uint8Array(32);
        crypto_core_hsalsa20(s, n, k, sigma);
        var sn = new Uint8Array(8);
        for (var i = 0; i < 8; i++) sn[i] = n[i + 16];
        return crypto_stream_salsa20_xor(c, cpos, m, mpos, d, sn, s);
      }
      var poly1305 = function(key) {
        this.buffer = new Uint8Array(16);
        this.r = new Uint16Array(10);
        this.h = new Uint16Array(10);
        this.pad = new Uint16Array(8);
        this.leftover = 0;
        this.fin = 0;
        var t0, t1, t2, t3, t4, t5, t6, t7;
        t0 = key[0] & 255 | (key[1] & 255) << 8;
        this.r[0] = t0 & 8191;
        t1 = key[2] & 255 | (key[3] & 255) << 8;
        this.r[1] = (t0 >>> 13 | t1 << 3) & 8191;
        t2 = key[4] & 255 | (key[5] & 255) << 8;
        this.r[2] = (t1 >>> 10 | t2 << 6) & 7939;
        t3 = key[6] & 255 | (key[7] & 255) << 8;
        this.r[3] = (t2 >>> 7 | t3 << 9) & 8191;
        t4 = key[8] & 255 | (key[9] & 255) << 8;
        this.r[4] = (t3 >>> 4 | t4 << 12) & 255;
        this.r[5] = t4 >>> 1 & 8190;
        t5 = key[10] & 255 | (key[11] & 255) << 8;
        this.r[6] = (t4 >>> 14 | t5 << 2) & 8191;
        t6 = key[12] & 255 | (key[13] & 255) << 8;
        this.r[7] = (t5 >>> 11 | t6 << 5) & 8065;
        t7 = key[14] & 255 | (key[15] & 255) << 8;
        this.r[8] = (t6 >>> 8 | t7 << 8) & 8191;
        this.r[9] = t7 >>> 5 & 127;
        this.pad[0] = key[16] & 255 | (key[17] & 255) << 8;
        this.pad[1] = key[18] & 255 | (key[19] & 255) << 8;
        this.pad[2] = key[20] & 255 | (key[21] & 255) << 8;
        this.pad[3] = key[22] & 255 | (key[23] & 255) << 8;
        this.pad[4] = key[24] & 255 | (key[25] & 255) << 8;
        this.pad[5] = key[26] & 255 | (key[27] & 255) << 8;
        this.pad[6] = key[28] & 255 | (key[29] & 255) << 8;
        this.pad[7] = key[30] & 255 | (key[31] & 255) << 8;
      };
      poly1305.prototype.blocks = function(m, mpos, bytes) {
        var hibit = this.fin ? 0 : 1 << 11;
        var t0, t1, t2, t3, t4, t5, t6, t7, c;
        var d0, d1, d2, d3, d4, d5, d6, d7, d8, d9;
        var h0 = this.h[0], h1 = this.h[1], h2 = this.h[2], h3 = this.h[3], h4 = this.h[4], h5 = this.h[5], h6 = this.h[6], h7 = this.h[7], h8 = this.h[8], h9 = this.h[9];
        var r0 = this.r[0], r1 = this.r[1], r2 = this.r[2], r3 = this.r[3], r4 = this.r[4], r5 = this.r[5], r6 = this.r[6], r7 = this.r[7], r8 = this.r[8], r9 = this.r[9];
        while (bytes >= 16) {
          t0 = m[mpos + 0] & 255 | (m[mpos + 1] & 255) << 8;
          h0 += t0 & 8191;
          t1 = m[mpos + 2] & 255 | (m[mpos + 3] & 255) << 8;
          h1 += (t0 >>> 13 | t1 << 3) & 8191;
          t2 = m[mpos + 4] & 255 | (m[mpos + 5] & 255) << 8;
          h2 += (t1 >>> 10 | t2 << 6) & 8191;
          t3 = m[mpos + 6] & 255 | (m[mpos + 7] & 255) << 8;
          h3 += (t2 >>> 7 | t3 << 9) & 8191;
          t4 = m[mpos + 8] & 255 | (m[mpos + 9] & 255) << 8;
          h4 += (t3 >>> 4 | t4 << 12) & 8191;
          h5 += t4 >>> 1 & 8191;
          t5 = m[mpos + 10] & 255 | (m[mpos + 11] & 255) << 8;
          h6 += (t4 >>> 14 | t5 << 2) & 8191;
          t6 = m[mpos + 12] & 255 | (m[mpos + 13] & 255) << 8;
          h7 += (t5 >>> 11 | t6 << 5) & 8191;
          t7 = m[mpos + 14] & 255 | (m[mpos + 15] & 255) << 8;
          h8 += (t6 >>> 8 | t7 << 8) & 8191;
          h9 += t7 >>> 5 | hibit;
          c = 0;
          d0 = c;
          d0 += h0 * r0;
          d0 += h1 * (5 * r9);
          d0 += h2 * (5 * r8);
          d0 += h3 * (5 * r7);
          d0 += h4 * (5 * r6);
          c = d0 >>> 13;
          d0 &= 8191;
          d0 += h5 * (5 * r5);
          d0 += h6 * (5 * r4);
          d0 += h7 * (5 * r3);
          d0 += h8 * (5 * r2);
          d0 += h9 * (5 * r1);
          c += d0 >>> 13;
          d0 &= 8191;
          d1 = c;
          d1 += h0 * r1;
          d1 += h1 * r0;
          d1 += h2 * (5 * r9);
          d1 += h3 * (5 * r8);
          d1 += h4 * (5 * r7);
          c = d1 >>> 13;
          d1 &= 8191;
          d1 += h5 * (5 * r6);
          d1 += h6 * (5 * r5);
          d1 += h7 * (5 * r4);
          d1 += h8 * (5 * r3);
          d1 += h9 * (5 * r2);
          c += d1 >>> 13;
          d1 &= 8191;
          d2 = c;
          d2 += h0 * r2;
          d2 += h1 * r1;
          d2 += h2 * r0;
          d2 += h3 * (5 * r9);
          d2 += h4 * (5 * r8);
          c = d2 >>> 13;
          d2 &= 8191;
          d2 += h5 * (5 * r7);
          d2 += h6 * (5 * r6);
          d2 += h7 * (5 * r5);
          d2 += h8 * (5 * r4);
          d2 += h9 * (5 * r3);
          c += d2 >>> 13;
          d2 &= 8191;
          d3 = c;
          d3 += h0 * r3;
          d3 += h1 * r2;
          d3 += h2 * r1;
          d3 += h3 * r0;
          d3 += h4 * (5 * r9);
          c = d3 >>> 13;
          d3 &= 8191;
          d3 += h5 * (5 * r8);
          d3 += h6 * (5 * r7);
          d3 += h7 * (5 * r6);
          d3 += h8 * (5 * r5);
          d3 += h9 * (5 * r4);
          c += d3 >>> 13;
          d3 &= 8191;
          d4 = c;
          d4 += h0 * r4;
          d4 += h1 * r3;
          d4 += h2 * r2;
          d4 += h3 * r1;
          d4 += h4 * r0;
          c = d4 >>> 13;
          d4 &= 8191;
          d4 += h5 * (5 * r9);
          d4 += h6 * (5 * r8);
          d4 += h7 * (5 * r7);
          d4 += h8 * (5 * r6);
          d4 += h9 * (5 * r5);
          c += d4 >>> 13;
          d4 &= 8191;
          d5 = c;
          d5 += h0 * r5;
          d5 += h1 * r4;
          d5 += h2 * r3;
          d5 += h3 * r2;
          d5 += h4 * r1;
          c = d5 >>> 13;
          d5 &= 8191;
          d5 += h5 * r0;
          d5 += h6 * (5 * r9);
          d5 += h7 * (5 * r8);
          d5 += h8 * (5 * r7);
          d5 += h9 * (5 * r6);
          c += d5 >>> 13;
          d5 &= 8191;
          d6 = c;
          d6 += h0 * r6;
          d6 += h1 * r5;
          d6 += h2 * r4;
          d6 += h3 * r3;
          d6 += h4 * r2;
          c = d6 >>> 13;
          d6 &= 8191;
          d6 += h5 * r1;
          d6 += h6 * r0;
          d6 += h7 * (5 * r9);
          d6 += h8 * (5 * r8);
          d6 += h9 * (5 * r7);
          c += d6 >>> 13;
          d6 &= 8191;
          d7 = c;
          d7 += h0 * r7;
          d7 += h1 * r6;
          d7 += h2 * r5;
          d7 += h3 * r4;
          d7 += h4 * r3;
          c = d7 >>> 13;
          d7 &= 8191;
          d7 += h5 * r2;
          d7 += h6 * r1;
          d7 += h7 * r0;
          d7 += h8 * (5 * r9);
          d7 += h9 * (5 * r8);
          c += d7 >>> 13;
          d7 &= 8191;
          d8 = c;
          d8 += h0 * r8;
          d8 += h1 * r7;
          d8 += h2 * r6;
          d8 += h3 * r5;
          d8 += h4 * r4;
          c = d8 >>> 13;
          d8 &= 8191;
          d8 += h5 * r3;
          d8 += h6 * r2;
          d8 += h7 * r1;
          d8 += h8 * r0;
          d8 += h9 * (5 * r9);
          c += d8 >>> 13;
          d8 &= 8191;
          d9 = c;
          d9 += h0 * r9;
          d9 += h1 * r8;
          d9 += h2 * r7;
          d9 += h3 * r6;
          d9 += h4 * r5;
          c = d9 >>> 13;
          d9 &= 8191;
          d9 += h5 * r4;
          d9 += h6 * r3;
          d9 += h7 * r2;
          d9 += h8 * r1;
          d9 += h9 * r0;
          c += d9 >>> 13;
          d9 &= 8191;
          c = (c << 2) + c | 0;
          c = c + d0 | 0;
          d0 = c & 8191;
          c = c >>> 13;
          d1 += c;
          h0 = d0;
          h1 = d1;
          h2 = d2;
          h3 = d3;
          h4 = d4;
          h5 = d5;
          h6 = d6;
          h7 = d7;
          h8 = d8;
          h9 = d9;
          mpos += 16;
          bytes -= 16;
        }
        this.h[0] = h0;
        this.h[1] = h1;
        this.h[2] = h2;
        this.h[3] = h3;
        this.h[4] = h4;
        this.h[5] = h5;
        this.h[6] = h6;
        this.h[7] = h7;
        this.h[8] = h8;
        this.h[9] = h9;
      };
      poly1305.prototype.finish = function(mac, macpos) {
        var g = new Uint16Array(10);
        var c, mask, f, i;
        if (this.leftover) {
          i = this.leftover;
          this.buffer[i++] = 1;
          for (; i < 16; i++) this.buffer[i] = 0;
          this.fin = 1;
          this.blocks(this.buffer, 0, 16);
        }
        c = this.h[1] >>> 13;
        this.h[1] &= 8191;
        for (i = 2; i < 10; i++) {
          this.h[i] += c;
          c = this.h[i] >>> 13;
          this.h[i] &= 8191;
        }
        this.h[0] += c * 5;
        c = this.h[0] >>> 13;
        this.h[0] &= 8191;
        this.h[1] += c;
        c = this.h[1] >>> 13;
        this.h[1] &= 8191;
        this.h[2] += c;
        g[0] = this.h[0] + 5;
        c = g[0] >>> 13;
        g[0] &= 8191;
        for (i = 1; i < 10; i++) {
          g[i] = this.h[i] + c;
          c = g[i] >>> 13;
          g[i] &= 8191;
        }
        g[9] -= 1 << 13;
        mask = (c ^ 1) - 1;
        for (i = 0; i < 10; i++) g[i] &= mask;
        mask = ~mask;
        for (i = 0; i < 10; i++) this.h[i] = this.h[i] & mask | g[i];
        this.h[0] = (this.h[0] | this.h[1] << 13) & 65535;
        this.h[1] = (this.h[1] >>> 3 | this.h[2] << 10) & 65535;
        this.h[2] = (this.h[2] >>> 6 | this.h[3] << 7) & 65535;
        this.h[3] = (this.h[3] >>> 9 | this.h[4] << 4) & 65535;
        this.h[4] = (this.h[4] >>> 12 | this.h[5] << 1 | this.h[6] << 14) & 65535;
        this.h[5] = (this.h[6] >>> 2 | this.h[7] << 11) & 65535;
        this.h[6] = (this.h[7] >>> 5 | this.h[8] << 8) & 65535;
        this.h[7] = (this.h[8] >>> 8 | this.h[9] << 5) & 65535;
        f = this.h[0] + this.pad[0];
        this.h[0] = f & 65535;
        for (i = 1; i < 8; i++) {
          f = (this.h[i] + this.pad[i] | 0) + (f >>> 16) | 0;
          this.h[i] = f & 65535;
        }
        mac[macpos + 0] = this.h[0] >>> 0 & 255;
        mac[macpos + 1] = this.h[0] >>> 8 & 255;
        mac[macpos + 2] = this.h[1] >>> 0 & 255;
        mac[macpos + 3] = this.h[1] >>> 8 & 255;
        mac[macpos + 4] = this.h[2] >>> 0 & 255;
        mac[macpos + 5] = this.h[2] >>> 8 & 255;
        mac[macpos + 6] = this.h[3] >>> 0 & 255;
        mac[macpos + 7] = this.h[3] >>> 8 & 255;
        mac[macpos + 8] = this.h[4] >>> 0 & 255;
        mac[macpos + 9] = this.h[4] >>> 8 & 255;
        mac[macpos + 10] = this.h[5] >>> 0 & 255;
        mac[macpos + 11] = this.h[5] >>> 8 & 255;
        mac[macpos + 12] = this.h[6] >>> 0 & 255;
        mac[macpos + 13] = this.h[6] >>> 8 & 255;
        mac[macpos + 14] = this.h[7] >>> 0 & 255;
        mac[macpos + 15] = this.h[7] >>> 8 & 255;
      };
      poly1305.prototype.update = function(m, mpos, bytes) {
        var i, want;
        if (this.leftover) {
          want = 16 - this.leftover;
          if (want > bytes)
            want = bytes;
          for (i = 0; i < want; i++)
            this.buffer[this.leftover + i] = m[mpos + i];
          bytes -= want;
          mpos += want;
          this.leftover += want;
          if (this.leftover < 16)
            return;
          this.blocks(this.buffer, 0, 16);
          this.leftover = 0;
        }
        if (bytes >= 16) {
          want = bytes - bytes % 16;
          this.blocks(m, mpos, want);
          mpos += want;
          bytes -= want;
        }
        if (bytes) {
          for (i = 0; i < bytes; i++)
            this.buffer[this.leftover + i] = m[mpos + i];
          this.leftover += bytes;
        }
      };
      function crypto_onetimeauth(out, outpos, m, mpos, n, k) {
        var s = new poly1305(k);
        s.update(m, mpos, n);
        s.finish(out, outpos);
        return 0;
      }
      function crypto_onetimeauth_verify(h, hpos, m, mpos, n, k) {
        var x = new Uint8Array(16);
        crypto_onetimeauth(x, 0, m, mpos, n, k);
        return crypto_verify_16(h, hpos, x, 0);
      }
      function crypto_secretbox(c, m, d, n, k) {
        var i;
        if (d < 32) return -1;
        crypto_stream_xor(c, 0, m, 0, d, n, k);
        crypto_onetimeauth(c, 16, c, 32, d - 32, c);
        for (i = 0; i < 16; i++) c[i] = 0;
        return 0;
      }
      function crypto_secretbox_open(m, c, d, n, k) {
        var i;
        var x = new Uint8Array(32);
        if (d < 32) return -1;
        crypto_stream(x, 0, 32, n, k);
        if (crypto_onetimeauth_verify(c, 16, c, 32, d - 32, x) !== 0) return -1;
        crypto_stream_xor(m, 0, c, 0, d, n, k);
        for (i = 0; i < 32; i++) m[i] = 0;
        return 0;
      }
      function set25519(r, a) {
        var i;
        for (i = 0; i < 16; i++) r[i] = a[i] | 0;
      }
      function car25519(o) {
        var i, v, c = 1;
        for (i = 0; i < 16; i++) {
          v = o[i] + c + 65535;
          c = Math.floor(v / 65536);
          o[i] = v - c * 65536;
        }
        o[0] += c - 1 + 37 * (c - 1);
      }
      function sel25519(p, q2, b) {
        var t, c = ~(b - 1);
        for (var i = 0; i < 16; i++) {
          t = c & (p[i] ^ q2[i]);
          p[i] ^= t;
          q2[i] ^= t;
        }
      }
      function pack25519(o, n) {
        var i, j, b;
        var m = gf(), t = gf();
        for (i = 0; i < 16; i++) t[i] = n[i];
        car25519(t);
        car25519(t);
        car25519(t);
        for (j = 0; j < 2; j++) {
          m[0] = t[0] - 65517;
          for (i = 1; i < 15; i++) {
            m[i] = t[i] - 65535 - (m[i - 1] >> 16 & 1);
            m[i - 1] &= 65535;
          }
          m[15] = t[15] - 32767 - (m[14] >> 16 & 1);
          b = m[15] >> 16 & 1;
          m[14] &= 65535;
          sel25519(t, m, 1 - b);
        }
        for (i = 0; i < 16; i++) {
          o[2 * i] = t[i] & 255;
          o[2 * i + 1] = t[i] >> 8;
        }
      }
      function neq25519(a, b) {
        var c = new Uint8Array(32), d = new Uint8Array(32);
        pack25519(c, a);
        pack25519(d, b);
        return crypto_verify_32(c, 0, d, 0);
      }
      function par25519(a) {
        var d = new Uint8Array(32);
        pack25519(d, a);
        return d[0] & 1;
      }
      function unpack25519(o, n) {
        var i;
        for (i = 0; i < 16; i++) o[i] = n[2 * i] + (n[2 * i + 1] << 8);
        o[15] &= 32767;
      }
      function A(o, a, b) {
        for (var i = 0; i < 16; i++) o[i] = a[i] + b[i];
      }
      function Z(o, a, b) {
        for (var i = 0; i < 16; i++) o[i] = a[i] - b[i];
      }
      function M(o, a, b) {
        var v, c, t0 = 0, t1 = 0, t2 = 0, t3 = 0, t4 = 0, t5 = 0, t6 = 0, t7 = 0, t8 = 0, t9 = 0, t10 = 0, t11 = 0, t12 = 0, t13 = 0, t14 = 0, t15 = 0, t16 = 0, t17 = 0, t18 = 0, t19 = 0, t20 = 0, t21 = 0, t22 = 0, t23 = 0, t24 = 0, t25 = 0, t26 = 0, t27 = 0, t28 = 0, t29 = 0, t30 = 0, b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3], b4 = b[4], b5 = b[5], b6 = b[6], b7 = b[7], b8 = b[8], b9 = b[9], b10 = b[10], b11 = b[11], b12 = b[12], b13 = b[13], b14 = b[14], b15 = b[15];
        v = a[0];
        t0 += v * b0;
        t1 += v * b1;
        t2 += v * b2;
        t3 += v * b3;
        t4 += v * b4;
        t5 += v * b5;
        t6 += v * b6;
        t7 += v * b7;
        t8 += v * b8;
        t9 += v * b9;
        t10 += v * b10;
        t11 += v * b11;
        t12 += v * b12;
        t13 += v * b13;
        t14 += v * b14;
        t15 += v * b15;
        v = a[1];
        t1 += v * b0;
        t2 += v * b1;
        t3 += v * b2;
        t4 += v * b3;
        t5 += v * b4;
        t6 += v * b5;
        t7 += v * b6;
        t8 += v * b7;
        t9 += v * b8;
        t10 += v * b9;
        t11 += v * b10;
        t12 += v * b11;
        t13 += v * b12;
        t14 += v * b13;
        t15 += v * b14;
        t16 += v * b15;
        v = a[2];
        t2 += v * b0;
        t3 += v * b1;
        t4 += v * b2;
        t5 += v * b3;
        t6 += v * b4;
        t7 += v * b5;
        t8 += v * b6;
        t9 += v * b7;
        t10 += v * b8;
        t11 += v * b9;
        t12 += v * b10;
        t13 += v * b11;
        t14 += v * b12;
        t15 += v * b13;
        t16 += v * b14;
        t17 += v * b15;
        v = a[3];
        t3 += v * b0;
        t4 += v * b1;
        t5 += v * b2;
        t6 += v * b3;
        t7 += v * b4;
        t8 += v * b5;
        t9 += v * b6;
        t10 += v * b7;
        t11 += v * b8;
        t12 += v * b9;
        t13 += v * b10;
        t14 += v * b11;
        t15 += v * b12;
        t16 += v * b13;
        t17 += v * b14;
        t18 += v * b15;
        v = a[4];
        t4 += v * b0;
        t5 += v * b1;
        t6 += v * b2;
        t7 += v * b3;
        t8 += v * b4;
        t9 += v * b5;
        t10 += v * b6;
        t11 += v * b7;
        t12 += v * b8;
        t13 += v * b9;
        t14 += v * b10;
        t15 += v * b11;
        t16 += v * b12;
        t17 += v * b13;
        t18 += v * b14;
        t19 += v * b15;
        v = a[5];
        t5 += v * b0;
        t6 += v * b1;
        t7 += v * b2;
        t8 += v * b3;
        t9 += v * b4;
        t10 += v * b5;
        t11 += v * b6;
        t12 += v * b7;
        t13 += v * b8;
        t14 += v * b9;
        t15 += v * b10;
        t16 += v * b11;
        t17 += v * b12;
        t18 += v * b13;
        t19 += v * b14;
        t20 += v * b15;
        v = a[6];
        t6 += v * b0;
        t7 += v * b1;
        t8 += v * b2;
        t9 += v * b3;
        t10 += v * b4;
        t11 += v * b5;
        t12 += v * b6;
        t13 += v * b7;
        t14 += v * b8;
        t15 += v * b9;
        t16 += v * b10;
        t17 += v * b11;
        t18 += v * b12;
        t19 += v * b13;
        t20 += v * b14;
        t21 += v * b15;
        v = a[7];
        t7 += v * b0;
        t8 += v * b1;
        t9 += v * b2;
        t10 += v * b3;
        t11 += v * b4;
        t12 += v * b5;
        t13 += v * b6;
        t14 += v * b7;
        t15 += v * b8;
        t16 += v * b9;
        t17 += v * b10;
        t18 += v * b11;
        t19 += v * b12;
        t20 += v * b13;
        t21 += v * b14;
        t22 += v * b15;
        v = a[8];
        t8 += v * b0;
        t9 += v * b1;
        t10 += v * b2;
        t11 += v * b3;
        t12 += v * b4;
        t13 += v * b5;
        t14 += v * b6;
        t15 += v * b7;
        t16 += v * b8;
        t17 += v * b9;
        t18 += v * b10;
        t19 += v * b11;
        t20 += v * b12;
        t21 += v * b13;
        t22 += v * b14;
        t23 += v * b15;
        v = a[9];
        t9 += v * b0;
        t10 += v * b1;
        t11 += v * b2;
        t12 += v * b3;
        t13 += v * b4;
        t14 += v * b5;
        t15 += v * b6;
        t16 += v * b7;
        t17 += v * b8;
        t18 += v * b9;
        t19 += v * b10;
        t20 += v * b11;
        t21 += v * b12;
        t22 += v * b13;
        t23 += v * b14;
        t24 += v * b15;
        v = a[10];
        t10 += v * b0;
        t11 += v * b1;
        t12 += v * b2;
        t13 += v * b3;
        t14 += v * b4;
        t15 += v * b5;
        t16 += v * b6;
        t17 += v * b7;
        t18 += v * b8;
        t19 += v * b9;
        t20 += v * b10;
        t21 += v * b11;
        t22 += v * b12;
        t23 += v * b13;
        t24 += v * b14;
        t25 += v * b15;
        v = a[11];
        t11 += v * b0;
        t12 += v * b1;
        t13 += v * b2;
        t14 += v * b3;
        t15 += v * b4;
        t16 += v * b5;
        t17 += v * b6;
        t18 += v * b7;
        t19 += v * b8;
        t20 += v * b9;
        t21 += v * b10;
        t22 += v * b11;
        t23 += v * b12;
        t24 += v * b13;
        t25 += v * b14;
        t26 += v * b15;
        v = a[12];
        t12 += v * b0;
        t13 += v * b1;
        t14 += v * b2;
        t15 += v * b3;
        t16 += v * b4;
        t17 += v * b5;
        t18 += v * b6;
        t19 += v * b7;
        t20 += v * b8;
        t21 += v * b9;
        t22 += v * b10;
        t23 += v * b11;
        t24 += v * b12;
        t25 += v * b13;
        t26 += v * b14;
        t27 += v * b15;
        v = a[13];
        t13 += v * b0;
        t14 += v * b1;
        t15 += v * b2;
        t16 += v * b3;
        t17 += v * b4;
        t18 += v * b5;
        t19 += v * b6;
        t20 += v * b7;
        t21 += v * b8;
        t22 += v * b9;
        t23 += v * b10;
        t24 += v * b11;
        t25 += v * b12;
        t26 += v * b13;
        t27 += v * b14;
        t28 += v * b15;
        v = a[14];
        t14 += v * b0;
        t15 += v * b1;
        t16 += v * b2;
        t17 += v * b3;
        t18 += v * b4;
        t19 += v * b5;
        t20 += v * b6;
        t21 += v * b7;
        t22 += v * b8;
        t23 += v * b9;
        t24 += v * b10;
        t25 += v * b11;
        t26 += v * b12;
        t27 += v * b13;
        t28 += v * b14;
        t29 += v * b15;
        v = a[15];
        t15 += v * b0;
        t16 += v * b1;
        t17 += v * b2;
        t18 += v * b3;
        t19 += v * b4;
        t20 += v * b5;
        t21 += v * b6;
        t22 += v * b7;
        t23 += v * b8;
        t24 += v * b9;
        t25 += v * b10;
        t26 += v * b11;
        t27 += v * b12;
        t28 += v * b13;
        t29 += v * b14;
        t30 += v * b15;
        t0 += 38 * t16;
        t1 += 38 * t17;
        t2 += 38 * t18;
        t3 += 38 * t19;
        t4 += 38 * t20;
        t5 += 38 * t21;
        t6 += 38 * t22;
        t7 += 38 * t23;
        t8 += 38 * t24;
        t9 += 38 * t25;
        t10 += 38 * t26;
        t11 += 38 * t27;
        t12 += 38 * t28;
        t13 += 38 * t29;
        t14 += 38 * t30;
        c = 1;
        v = t0 + c + 65535;
        c = Math.floor(v / 65536);
        t0 = v - c * 65536;
        v = t1 + c + 65535;
        c = Math.floor(v / 65536);
        t1 = v - c * 65536;
        v = t2 + c + 65535;
        c = Math.floor(v / 65536);
        t2 = v - c * 65536;
        v = t3 + c + 65535;
        c = Math.floor(v / 65536);
        t3 = v - c * 65536;
        v = t4 + c + 65535;
        c = Math.floor(v / 65536);
        t4 = v - c * 65536;
        v = t5 + c + 65535;
        c = Math.floor(v / 65536);
        t5 = v - c * 65536;
        v = t6 + c + 65535;
        c = Math.floor(v / 65536);
        t6 = v - c * 65536;
        v = t7 + c + 65535;
        c = Math.floor(v / 65536);
        t7 = v - c * 65536;
        v = t8 + c + 65535;
        c = Math.floor(v / 65536);
        t8 = v - c * 65536;
        v = t9 + c + 65535;
        c = Math.floor(v / 65536);
        t9 = v - c * 65536;
        v = t10 + c + 65535;
        c = Math.floor(v / 65536);
        t10 = v - c * 65536;
        v = t11 + c + 65535;
        c = Math.floor(v / 65536);
        t11 = v - c * 65536;
        v = t12 + c + 65535;
        c = Math.floor(v / 65536);
        t12 = v - c * 65536;
        v = t13 + c + 65535;
        c = Math.floor(v / 65536);
        t13 = v - c * 65536;
        v = t14 + c + 65535;
        c = Math.floor(v / 65536);
        t14 = v - c * 65536;
        v = t15 + c + 65535;
        c = Math.floor(v / 65536);
        t15 = v - c * 65536;
        t0 += c - 1 + 37 * (c - 1);
        c = 1;
        v = t0 + c + 65535;
        c = Math.floor(v / 65536);
        t0 = v - c * 65536;
        v = t1 + c + 65535;
        c = Math.floor(v / 65536);
        t1 = v - c * 65536;
        v = t2 + c + 65535;
        c = Math.floor(v / 65536);
        t2 = v - c * 65536;
        v = t3 + c + 65535;
        c = Math.floor(v / 65536);
        t3 = v - c * 65536;
        v = t4 + c + 65535;
        c = Math.floor(v / 65536);
        t4 = v - c * 65536;
        v = t5 + c + 65535;
        c = Math.floor(v / 65536);
        t5 = v - c * 65536;
        v = t6 + c + 65535;
        c = Math.floor(v / 65536);
        t6 = v - c * 65536;
        v = t7 + c + 65535;
        c = Math.floor(v / 65536);
        t7 = v - c * 65536;
        v = t8 + c + 65535;
        c = Math.floor(v / 65536);
        t8 = v - c * 65536;
        v = t9 + c + 65535;
        c = Math.floor(v / 65536);
        t9 = v - c * 65536;
        v = t10 + c + 65535;
        c = Math.floor(v / 65536);
        t10 = v - c * 65536;
        v = t11 + c + 65535;
        c = Math.floor(v / 65536);
        t11 = v - c * 65536;
        v = t12 + c + 65535;
        c = Math.floor(v / 65536);
        t12 = v - c * 65536;
        v = t13 + c + 65535;
        c = Math.floor(v / 65536);
        t13 = v - c * 65536;
        v = t14 + c + 65535;
        c = Math.floor(v / 65536);
        t14 = v - c * 65536;
        v = t15 + c + 65535;
        c = Math.floor(v / 65536);
        t15 = v - c * 65536;
        t0 += c - 1 + 37 * (c - 1);
        o[0] = t0;
        o[1] = t1;
        o[2] = t2;
        o[3] = t3;
        o[4] = t4;
        o[5] = t5;
        o[6] = t6;
        o[7] = t7;
        o[8] = t8;
        o[9] = t9;
        o[10] = t10;
        o[11] = t11;
        o[12] = t12;
        o[13] = t13;
        o[14] = t14;
        o[15] = t15;
      }
      function S(o, a) {
        M(o, a, a);
      }
      function inv25519(o, i) {
        var c = gf();
        var a;
        for (a = 0; a < 16; a++) c[a] = i[a];
        for (a = 253; a >= 0; a--) {
          S(c, c);
          if (a !== 2 && a !== 4) M(c, c, i);
        }
        for (a = 0; a < 16; a++) o[a] = c[a];
      }
      function pow2523(o, i) {
        var c = gf();
        var a;
        for (a = 0; a < 16; a++) c[a] = i[a];
        for (a = 250; a >= 0; a--) {
          S(c, c);
          if (a !== 1) M(c, c, i);
        }
        for (a = 0; a < 16; a++) o[a] = c[a];
      }
      function crypto_scalarmult(q2, n, p) {
        var z = new Uint8Array(32);
        var x = new Float64Array(80), r, i;
        var a = gf(), b = gf(), c = gf(), d = gf(), e = gf(), f = gf();
        for (i = 0; i < 31; i++) z[i] = n[i];
        z[31] = n[31] & 127 | 64;
        z[0] &= 248;
        unpack25519(x, p);
        for (i = 0; i < 16; i++) {
          b[i] = x[i];
          d[i] = a[i] = c[i] = 0;
        }
        a[0] = d[0] = 1;
        for (i = 254; i >= 0; --i) {
          r = z[i >>> 3] >>> (i & 7) & 1;
          sel25519(a, b, r);
          sel25519(c, d, r);
          A(e, a, c);
          Z(a, a, c);
          A(c, b, d);
          Z(b, b, d);
          S(d, e);
          S(f, a);
          M(a, c, a);
          M(c, b, e);
          A(e, a, c);
          Z(a, a, c);
          S(b, a);
          Z(c, d, f);
          M(a, c, _121665);
          A(a, a, d);
          M(c, c, a);
          M(a, d, f);
          M(d, b, x);
          S(b, e);
          sel25519(a, b, r);
          sel25519(c, d, r);
        }
        for (i = 0; i < 16; i++) {
          x[i + 16] = a[i];
          x[i + 32] = c[i];
          x[i + 48] = b[i];
          x[i + 64] = d[i];
        }
        var x32 = x.subarray(32);
        var x16 = x.subarray(16);
        inv25519(x32, x32);
        M(x16, x16, x32);
        pack25519(q2, x16);
        return 0;
      }
      function crypto_scalarmult_base(q2, n) {
        return crypto_scalarmult(q2, n, _9);
      }
      function crypto_box_keypair(y, x) {
        randombytes(x, 32);
        return crypto_scalarmult_base(y, x);
      }
      function crypto_box_beforenm(k, y, x) {
        var s = new Uint8Array(32);
        crypto_scalarmult(s, x, y);
        return crypto_core_hsalsa20(k, _0, s, sigma);
      }
      var crypto_box_afternm = crypto_secretbox;
      var crypto_box_open_afternm = crypto_secretbox_open;
      function crypto_box(c, m, d, n, y, x) {
        var k = new Uint8Array(32);
        crypto_box_beforenm(k, y, x);
        return crypto_box_afternm(c, m, d, n, k);
      }
      function crypto_box_open(m, c, d, n, y, x) {
        var k = new Uint8Array(32);
        crypto_box_beforenm(k, y, x);
        return crypto_box_open_afternm(m, c, d, n, k);
      }
      var K = [
        1116352408,
        3609767458,
        1899447441,
        602891725,
        3049323471,
        3964484399,
        3921009573,
        2173295548,
        961987163,
        4081628472,
        1508970993,
        3053834265,
        2453635748,
        2937671579,
        2870763221,
        3664609560,
        3624381080,
        2734883394,
        310598401,
        1164996542,
        607225278,
        1323610764,
        1426881987,
        3590304994,
        1925078388,
        4068182383,
        2162078206,
        991336113,
        2614888103,
        633803317,
        3248222580,
        3479774868,
        3835390401,
        2666613458,
        4022224774,
        944711139,
        264347078,
        2341262773,
        604807628,
        2007800933,
        770255983,
        1495990901,
        1249150122,
        1856431235,
        1555081692,
        3175218132,
        1996064986,
        2198950837,
        2554220882,
        3999719339,
        2821834349,
        766784016,
        2952996808,
        2566594879,
        3210313671,
        3203337956,
        3336571891,
        1034457026,
        3584528711,
        2466948901,
        113926993,
        3758326383,
        338241895,
        168717936,
        666307205,
        1188179964,
        773529912,
        1546045734,
        1294757372,
        1522805485,
        1396182291,
        2643833823,
        1695183700,
        2343527390,
        1986661051,
        1014477480,
        2177026350,
        1206759142,
        2456956037,
        344077627,
        2730485921,
        1290863460,
        2820302411,
        3158454273,
        3259730800,
        3505952657,
        3345764771,
        106217008,
        3516065817,
        3606008344,
        3600352804,
        1432725776,
        4094571909,
        1467031594,
        275423344,
        851169720,
        430227734,
        3100823752,
        506948616,
        1363258195,
        659060556,
        3750685593,
        883997877,
        3785050280,
        958139571,
        3318307427,
        1322822218,
        3812723403,
        1537002063,
        2003034995,
        1747873779,
        3602036899,
        1955562222,
        1575990012,
        2024104815,
        1125592928,
        2227730452,
        2716904306,
        2361852424,
        442776044,
        2428436474,
        593698344,
        2756734187,
        3733110249,
        3204031479,
        2999351573,
        3329325298,
        3815920427,
        3391569614,
        3928383900,
        3515267271,
        566280711,
        3940187606,
        3454069534,
        4118630271,
        4000239992,
        116418474,
        1914138554,
        174292421,
        2731055270,
        289380356,
        3203993006,
        460393269,
        320620315,
        685471733,
        587496836,
        852142971,
        1086792851,
        1017036298,
        365543100,
        1126000580,
        2618297676,
        1288033470,
        3409855158,
        1501505948,
        4234509866,
        1607167915,
        987167468,
        1816402316,
        1246189591
      ];
      function crypto_hashblocks_hl(hh, hl, m, n) {
        var wh = new Int32Array(16), wl = new Int32Array(16), bh0, bh1, bh2, bh3, bh4, bh5, bh6, bh7, bl0, bl1, bl2, bl3, bl4, bl5, bl6, bl7, th, tl, i, j, h, l, a, b, c, d;
        var ah0 = hh[0], ah1 = hh[1], ah2 = hh[2], ah3 = hh[3], ah4 = hh[4], ah5 = hh[5], ah6 = hh[6], ah7 = hh[7], al0 = hl[0], al1 = hl[1], al2 = hl[2], al3 = hl[3], al4 = hl[4], al5 = hl[5], al6 = hl[6], al7 = hl[7];
        var pos = 0;
        while (n >= 128) {
          for (i = 0; i < 16; i++) {
            j = 8 * i + pos;
            wh[i] = m[j + 0] << 24 | m[j + 1] << 16 | m[j + 2] << 8 | m[j + 3];
            wl[i] = m[j + 4] << 24 | m[j + 5] << 16 | m[j + 6] << 8 | m[j + 7];
          }
          for (i = 0; i < 80; i++) {
            bh0 = ah0;
            bh1 = ah1;
            bh2 = ah2;
            bh3 = ah3;
            bh4 = ah4;
            bh5 = ah5;
            bh6 = ah6;
            bh7 = ah7;
            bl0 = al0;
            bl1 = al1;
            bl2 = al2;
            bl3 = al3;
            bl4 = al4;
            bl5 = al5;
            bl6 = al6;
            bl7 = al7;
            h = ah7;
            l = al7;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = (ah4 >>> 14 | al4 << 32 - 14) ^ (ah4 >>> 18 | al4 << 32 - 18) ^ (al4 >>> 41 - 32 | ah4 << 32 - (41 - 32));
            l = (al4 >>> 14 | ah4 << 32 - 14) ^ (al4 >>> 18 | ah4 << 32 - 18) ^ (ah4 >>> 41 - 32 | al4 << 32 - (41 - 32));
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = ah4 & ah5 ^ ~ah4 & ah6;
            l = al4 & al5 ^ ~al4 & al6;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = K[i * 2];
            l = K[i * 2 + 1];
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = wh[i % 16];
            l = wl[i % 16];
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            th = c & 65535 | d << 16;
            tl = a & 65535 | b << 16;
            h = th;
            l = tl;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = (ah0 >>> 28 | al0 << 32 - 28) ^ (al0 >>> 34 - 32 | ah0 << 32 - (34 - 32)) ^ (al0 >>> 39 - 32 | ah0 << 32 - (39 - 32));
            l = (al0 >>> 28 | ah0 << 32 - 28) ^ (ah0 >>> 34 - 32 | al0 << 32 - (34 - 32)) ^ (ah0 >>> 39 - 32 | al0 << 32 - (39 - 32));
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = ah0 & ah1 ^ ah0 & ah2 ^ ah1 & ah2;
            l = al0 & al1 ^ al0 & al2 ^ al1 & al2;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            bh7 = c & 65535 | d << 16;
            bl7 = a & 65535 | b << 16;
            h = bh3;
            l = bl3;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = th;
            l = tl;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            bh3 = c & 65535 | d << 16;
            bl3 = a & 65535 | b << 16;
            ah1 = bh0;
            ah2 = bh1;
            ah3 = bh2;
            ah4 = bh3;
            ah5 = bh4;
            ah6 = bh5;
            ah7 = bh6;
            ah0 = bh7;
            al1 = bl0;
            al2 = bl1;
            al3 = bl2;
            al4 = bl3;
            al5 = bl4;
            al6 = bl5;
            al7 = bl6;
            al0 = bl7;
            if (i % 16 === 15) {
              for (j = 0; j < 16; j++) {
                h = wh[j];
                l = wl[j];
                a = l & 65535;
                b = l >>> 16;
                c = h & 65535;
                d = h >>> 16;
                h = wh[(j + 9) % 16];
                l = wl[(j + 9) % 16];
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                th = wh[(j + 1) % 16];
                tl = wl[(j + 1) % 16];
                h = (th >>> 1 | tl << 32 - 1) ^ (th >>> 8 | tl << 32 - 8) ^ th >>> 7;
                l = (tl >>> 1 | th << 32 - 1) ^ (tl >>> 8 | th << 32 - 8) ^ (tl >>> 7 | th << 32 - 7);
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                th = wh[(j + 14) % 16];
                tl = wl[(j + 14) % 16];
                h = (th >>> 19 | tl << 32 - 19) ^ (tl >>> 61 - 32 | th << 32 - (61 - 32)) ^ th >>> 6;
                l = (tl >>> 19 | th << 32 - 19) ^ (th >>> 61 - 32 | tl << 32 - (61 - 32)) ^ (tl >>> 6 | th << 32 - 6);
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                b += a >>> 16;
                c += b >>> 16;
                d += c >>> 16;
                wh[j] = c & 65535 | d << 16;
                wl[j] = a & 65535 | b << 16;
              }
            }
          }
          h = ah0;
          l = al0;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[0];
          l = hl[0];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[0] = ah0 = c & 65535 | d << 16;
          hl[0] = al0 = a & 65535 | b << 16;
          h = ah1;
          l = al1;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[1];
          l = hl[1];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[1] = ah1 = c & 65535 | d << 16;
          hl[1] = al1 = a & 65535 | b << 16;
          h = ah2;
          l = al2;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[2];
          l = hl[2];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[2] = ah2 = c & 65535 | d << 16;
          hl[2] = al2 = a & 65535 | b << 16;
          h = ah3;
          l = al3;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[3];
          l = hl[3];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[3] = ah3 = c & 65535 | d << 16;
          hl[3] = al3 = a & 65535 | b << 16;
          h = ah4;
          l = al4;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[4];
          l = hl[4];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[4] = ah4 = c & 65535 | d << 16;
          hl[4] = al4 = a & 65535 | b << 16;
          h = ah5;
          l = al5;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[5];
          l = hl[5];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[5] = ah5 = c & 65535 | d << 16;
          hl[5] = al5 = a & 65535 | b << 16;
          h = ah6;
          l = al6;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[6];
          l = hl[6];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[6] = ah6 = c & 65535 | d << 16;
          hl[6] = al6 = a & 65535 | b << 16;
          h = ah7;
          l = al7;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[7];
          l = hl[7];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[7] = ah7 = c & 65535 | d << 16;
          hl[7] = al7 = a & 65535 | b << 16;
          pos += 128;
          n -= 128;
        }
        return n;
      }
      function crypto_hash(out, m, n) {
        var hh = new Int32Array(8), hl = new Int32Array(8), x = new Uint8Array(256), i, b = n;
        hh[0] = 1779033703;
        hh[1] = 3144134277;
        hh[2] = 1013904242;
        hh[3] = 2773480762;
        hh[4] = 1359893119;
        hh[5] = 2600822924;
        hh[6] = 528734635;
        hh[7] = 1541459225;
        hl[0] = 4089235720;
        hl[1] = 2227873595;
        hl[2] = 4271175723;
        hl[3] = 1595750129;
        hl[4] = 2917565137;
        hl[5] = 725511199;
        hl[6] = 4215389547;
        hl[7] = 327033209;
        crypto_hashblocks_hl(hh, hl, m, n);
        n %= 128;
        for (i = 0; i < n; i++) x[i] = m[b - n + i];
        x[n] = 128;
        n = 256 - 128 * (n < 112 ? 1 : 0);
        x[n - 9] = 0;
        ts64(x, n - 8, b / 536870912 | 0, b << 3);
        crypto_hashblocks_hl(hh, hl, x, n);
        for (i = 0; i < 8; i++) ts64(out, 8 * i, hh[i], hl[i]);
        return 0;
      }
      function add(p, q2) {
        var a = gf(), b = gf(), c = gf(), d = gf(), e = gf(), f = gf(), g = gf(), h = gf(), t = gf();
        Z(a, p[1], p[0]);
        Z(t, q2[1], q2[0]);
        M(a, a, t);
        A(b, p[0], p[1]);
        A(t, q2[0], q2[1]);
        M(b, b, t);
        M(c, p[3], q2[3]);
        M(c, c, D2);
        M(d, p[2], q2[2]);
        A(d, d, d);
        Z(e, b, a);
        Z(f, d, c);
        A(g, d, c);
        A(h, b, a);
        M(p[0], e, f);
        M(p[1], h, g);
        M(p[2], g, f);
        M(p[3], e, h);
      }
      function cswap(p, q2, b) {
        var i;
        for (i = 0; i < 4; i++) {
          sel25519(p[i], q2[i], b);
        }
      }
      function pack(r, p) {
        var tx = gf(), ty = gf(), zi = gf();
        inv25519(zi, p[2]);
        M(tx, p[0], zi);
        M(ty, p[1], zi);
        pack25519(r, ty);
        r[31] ^= par25519(tx) << 7;
      }
      function scalarmult(p, q2, s) {
        var b, i;
        set25519(p[0], gf0);
        set25519(p[1], gf1);
        set25519(p[2], gf1);
        set25519(p[3], gf0);
        for (i = 255; i >= 0; --i) {
          b = s[i / 8 | 0] >> (i & 7) & 1;
          cswap(p, q2, b);
          add(q2, p);
          add(p, p);
          cswap(p, q2, b);
        }
      }
      function scalarbase(p, s) {
        var q2 = [gf(), gf(), gf(), gf()];
        set25519(q2[0], X);
        set25519(q2[1], Y);
        set25519(q2[2], gf1);
        M(q2[3], X, Y);
        scalarmult(p, q2, s);
      }
      function crypto_sign_keypair(pk, sk, seeded) {
        var d = new Uint8Array(64);
        var p = [gf(), gf(), gf(), gf()];
        var i;
        if (!seeded) randombytes(sk, 32);
        crypto_hash(d, sk, 32);
        d[0] &= 248;
        d[31] &= 127;
        d[31] |= 64;
        scalarbase(p, d);
        pack(pk, p);
        for (i = 0; i < 32; i++) sk[i + 32] = pk[i];
        return 0;
      }
      var L = new Float64Array([237, 211, 245, 92, 26, 99, 18, 88, 214, 156, 247, 162, 222, 249, 222, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16]);
      function modL(r, x) {
        var carry, i, j, k;
        for (i = 63; i >= 32; --i) {
          carry = 0;
          for (j = i - 32, k = i - 12; j < k; ++j) {
            x[j] += carry - 16 * x[i] * L[j - (i - 32)];
            carry = Math.floor((x[j] + 128) / 256);
            x[j] -= carry * 256;
          }
          x[j] += carry;
          x[i] = 0;
        }
        carry = 0;
        for (j = 0; j < 32; j++) {
          x[j] += carry - (x[31] >> 4) * L[j];
          carry = x[j] >> 8;
          x[j] &= 255;
        }
        for (j = 0; j < 32; j++) x[j] -= carry * L[j];
        for (i = 0; i < 32; i++) {
          x[i + 1] += x[i] >> 8;
          r[i] = x[i] & 255;
        }
      }
      function reduce(r) {
        var x = new Float64Array(64), i;
        for (i = 0; i < 64; i++) x[i] = r[i];
        for (i = 0; i < 64; i++) r[i] = 0;
        modL(r, x);
      }
      function crypto_sign(sm, m, n, sk) {
        var d = new Uint8Array(64), h = new Uint8Array(64), r = new Uint8Array(64);
        var i, j, x = new Float64Array(64);
        var p = [gf(), gf(), gf(), gf()];
        crypto_hash(d, sk, 32);
        d[0] &= 248;
        d[31] &= 127;
        d[31] |= 64;
        var smlen = n + 64;
        for (i = 0; i < n; i++) sm[64 + i] = m[i];
        for (i = 0; i < 32; i++) sm[32 + i] = d[32 + i];
        crypto_hash(r, sm.subarray(32), n + 32);
        reduce(r);
        scalarbase(p, r);
        pack(sm, p);
        for (i = 32; i < 64; i++) sm[i] = sk[i];
        crypto_hash(h, sm, n + 64);
        reduce(h);
        for (i = 0; i < 64; i++) x[i] = 0;
        for (i = 0; i < 32; i++) x[i] = r[i];
        for (i = 0; i < 32; i++) {
          for (j = 0; j < 32; j++) {
            x[i + j] += h[i] * d[j];
          }
        }
        modL(sm.subarray(32), x);
        return smlen;
      }
      function unpackneg(r, p) {
        var t = gf(), chk = gf(), num2 = gf(), den = gf(), den2 = gf(), den4 = gf(), den6 = gf();
        set25519(r[2], gf1);
        unpack25519(r[1], p);
        S(num2, r[1]);
        M(den, num2, D);
        Z(num2, num2, r[2]);
        A(den, r[2], den);
        S(den2, den);
        S(den4, den2);
        M(den6, den4, den2);
        M(t, den6, num2);
        M(t, t, den);
        pow2523(t, t);
        M(t, t, num2);
        M(t, t, den);
        M(t, t, den);
        M(r[0], t, den);
        S(chk, r[0]);
        M(chk, chk, den);
        if (neq25519(chk, num2)) M(r[0], r[0], I);
        S(chk, r[0]);
        M(chk, chk, den);
        if (neq25519(chk, num2)) return -1;
        if (par25519(r[0]) === p[31] >> 7) Z(r[0], gf0, r[0]);
        M(r[3], r[0], r[1]);
        return 0;
      }
      function crypto_sign_open(m, sm, n, pk) {
        var i;
        var t = new Uint8Array(32), h = new Uint8Array(64);
        var p = [gf(), gf(), gf(), gf()], q2 = [gf(), gf(), gf(), gf()];
        if (n < 64) return -1;
        if (unpackneg(q2, pk)) return -1;
        for (i = 0; i < n; i++) m[i] = sm[i];
        for (i = 0; i < 32; i++) m[i + 32] = pk[i];
        crypto_hash(h, m, n);
        reduce(h);
        scalarmult(p, q2, h);
        scalarbase(q2, sm.subarray(32));
        add(p, q2);
        pack(t, p);
        n -= 64;
        if (crypto_verify_32(sm, 0, t, 0)) {
          for (i = 0; i < n; i++) m[i] = 0;
          return -1;
        }
        for (i = 0; i < n; i++) m[i] = sm[i + 64];
        return n;
      }
      var crypto_secretbox_KEYBYTES = 32, crypto_secretbox_NONCEBYTES = 24, crypto_secretbox_ZEROBYTES = 32, crypto_secretbox_BOXZEROBYTES = 16, crypto_scalarmult_BYTES = 32, crypto_scalarmult_SCALARBYTES = 32, crypto_box_PUBLICKEYBYTES = 32, crypto_box_SECRETKEYBYTES = 32, crypto_box_BEFORENMBYTES = 32, crypto_box_NONCEBYTES = crypto_secretbox_NONCEBYTES, crypto_box_ZEROBYTES = crypto_secretbox_ZEROBYTES, crypto_box_BOXZEROBYTES = crypto_secretbox_BOXZEROBYTES, crypto_sign_BYTES = 64, crypto_sign_PUBLICKEYBYTES = 32, crypto_sign_SECRETKEYBYTES = 64, crypto_sign_SEEDBYTES = 32, crypto_hash_BYTES = 64;
      nacl2.lowlevel = {
        crypto_core_hsalsa20,
        crypto_stream_xor,
        crypto_stream,
        crypto_stream_salsa20_xor,
        crypto_stream_salsa20,
        crypto_onetimeauth,
        crypto_onetimeauth_verify,
        crypto_verify_16,
        crypto_verify_32,
        crypto_secretbox,
        crypto_secretbox_open,
        crypto_scalarmult,
        crypto_scalarmult_base,
        crypto_box_beforenm,
        crypto_box_afternm,
        crypto_box,
        crypto_box_open,
        crypto_box_keypair,
        crypto_hash,
        crypto_sign,
        crypto_sign_keypair,
        crypto_sign_open,
        crypto_secretbox_KEYBYTES,
        crypto_secretbox_NONCEBYTES,
        crypto_secretbox_ZEROBYTES,
        crypto_secretbox_BOXZEROBYTES,
        crypto_scalarmult_BYTES,
        crypto_scalarmult_SCALARBYTES,
        crypto_box_PUBLICKEYBYTES,
        crypto_box_SECRETKEYBYTES,
        crypto_box_BEFORENMBYTES,
        crypto_box_NONCEBYTES,
        crypto_box_ZEROBYTES,
        crypto_box_BOXZEROBYTES,
        crypto_sign_BYTES,
        crypto_sign_PUBLICKEYBYTES,
        crypto_sign_SECRETKEYBYTES,
        crypto_sign_SEEDBYTES,
        crypto_hash_BYTES,
        gf,
        D,
        L,
        pack25519,
        unpack25519,
        M,
        A,
        S,
        Z,
        pow2523,
        add,
        set25519,
        modL,
        scalarmult,
        scalarbase
      };
      function checkLengths(k, n) {
        if (k.length !== crypto_secretbox_KEYBYTES) throw new Error("bad key size");
        if (n.length !== crypto_secretbox_NONCEBYTES) throw new Error("bad nonce size");
      }
      function checkBoxLengths(pk, sk) {
        if (pk.length !== crypto_box_PUBLICKEYBYTES) throw new Error("bad public key size");
        if (sk.length !== crypto_box_SECRETKEYBYTES) throw new Error("bad secret key size");
      }
      function checkArrayTypes() {
        for (var i = 0; i < arguments.length; i++) {
          if (!(arguments[i] instanceof Uint8Array))
            throw new TypeError("unexpected type, use Uint8Array");
        }
      }
      function cleanup(arr) {
        for (var i = 0; i < arr.length; i++) arr[i] = 0;
      }
      nacl2.randomBytes = function(n) {
        var b = new Uint8Array(n);
        randombytes(b, n);
        return b;
      };
      nacl2.secretbox = function(msg, nonce, key) {
        checkArrayTypes(msg, nonce, key);
        checkLengths(key, nonce);
        var m = new Uint8Array(crypto_secretbox_ZEROBYTES + msg.length);
        var c = new Uint8Array(m.length);
        for (var i = 0; i < msg.length; i++) m[i + crypto_secretbox_ZEROBYTES] = msg[i];
        crypto_secretbox(c, m, m.length, nonce, key);
        return c.subarray(crypto_secretbox_BOXZEROBYTES);
      };
      nacl2.secretbox.open = function(box, nonce, key) {
        checkArrayTypes(box, nonce, key);
        checkLengths(key, nonce);
        var c = new Uint8Array(crypto_secretbox_BOXZEROBYTES + box.length);
        var m = new Uint8Array(c.length);
        for (var i = 0; i < box.length; i++) c[i + crypto_secretbox_BOXZEROBYTES] = box[i];
        if (c.length < 32) return null;
        if (crypto_secretbox_open(m, c, c.length, nonce, key) !== 0) return null;
        return m.subarray(crypto_secretbox_ZEROBYTES);
      };
      nacl2.secretbox.keyLength = crypto_secretbox_KEYBYTES;
      nacl2.secretbox.nonceLength = crypto_secretbox_NONCEBYTES;
      nacl2.secretbox.overheadLength = crypto_secretbox_BOXZEROBYTES;
      nacl2.scalarMult = function(n, p) {
        checkArrayTypes(n, p);
        if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error("bad n size");
        if (p.length !== crypto_scalarmult_BYTES) throw new Error("bad p size");
        var q2 = new Uint8Array(crypto_scalarmult_BYTES);
        crypto_scalarmult(q2, n, p);
        return q2;
      };
      nacl2.scalarMult.base = function(n) {
        checkArrayTypes(n);
        if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error("bad n size");
        var q2 = new Uint8Array(crypto_scalarmult_BYTES);
        crypto_scalarmult_base(q2, n);
        return q2;
      };
      nacl2.scalarMult.scalarLength = crypto_scalarmult_SCALARBYTES;
      nacl2.scalarMult.groupElementLength = crypto_scalarmult_BYTES;
      nacl2.box = function(msg, nonce, publicKey, secretKey) {
        var k = nacl2.box.before(publicKey, secretKey);
        return nacl2.secretbox(msg, nonce, k);
      };
      nacl2.box.before = function(publicKey, secretKey) {
        checkArrayTypes(publicKey, secretKey);
        checkBoxLengths(publicKey, secretKey);
        var k = new Uint8Array(crypto_box_BEFORENMBYTES);
        crypto_box_beforenm(k, publicKey, secretKey);
        return k;
      };
      nacl2.box.after = nacl2.secretbox;
      nacl2.box.open = function(msg, nonce, publicKey, secretKey) {
        var k = nacl2.box.before(publicKey, secretKey);
        return nacl2.secretbox.open(msg, nonce, k);
      };
      nacl2.box.open.after = nacl2.secretbox.open;
      nacl2.box.keyPair = function() {
        var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_box_SECRETKEYBYTES);
        crypto_box_keypair(pk, sk);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.box.keyPair.fromSecretKey = function(secretKey) {
        checkArrayTypes(secretKey);
        if (secretKey.length !== crypto_box_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
        crypto_scalarmult_base(pk, secretKey);
        return { publicKey: pk, secretKey: new Uint8Array(secretKey) };
      };
      nacl2.box.publicKeyLength = crypto_box_PUBLICKEYBYTES;
      nacl2.box.secretKeyLength = crypto_box_SECRETKEYBYTES;
      nacl2.box.sharedKeyLength = crypto_box_BEFORENMBYTES;
      nacl2.box.nonceLength = crypto_box_NONCEBYTES;
      nacl2.box.overheadLength = nacl2.secretbox.overheadLength;
      nacl2.sign = function(msg, secretKey) {
        checkArrayTypes(msg, secretKey);
        if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var signedMsg = new Uint8Array(crypto_sign_BYTES + msg.length);
        crypto_sign(signedMsg, msg, msg.length, secretKey);
        return signedMsg;
      };
      nacl2.sign.open = function(signedMsg, publicKey) {
        checkArrayTypes(signedMsg, publicKey);
        if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
          throw new Error("bad public key size");
        var tmp = new Uint8Array(signedMsg.length);
        var mlen = crypto_sign_open(tmp, signedMsg, signedMsg.length, publicKey);
        if (mlen < 0) return null;
        var m = new Uint8Array(mlen);
        for (var i = 0; i < m.length; i++) m[i] = tmp[i];
        return m;
      };
      nacl2.sign.detached = function(msg, secretKey) {
        var signedMsg = nacl2.sign(msg, secretKey);
        var sig = new Uint8Array(crypto_sign_BYTES);
        for (var i = 0; i < sig.length; i++) sig[i] = signedMsg[i];
        return sig;
      };
      nacl2.sign.detached.verify = function(msg, sig, publicKey) {
        checkArrayTypes(msg, sig, publicKey);
        if (sig.length !== crypto_sign_BYTES)
          throw new Error("bad signature size");
        if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
          throw new Error("bad public key size");
        var sm = new Uint8Array(crypto_sign_BYTES + msg.length);
        var m = new Uint8Array(crypto_sign_BYTES + msg.length);
        var i;
        for (i = 0; i < crypto_sign_BYTES; i++) sm[i] = sig[i];
        for (i = 0; i < msg.length; i++) sm[i + crypto_sign_BYTES] = msg[i];
        return crypto_sign_open(m, sm, sm.length, publicKey) >= 0;
      };
      nacl2.sign.keyPair = function() {
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
        crypto_sign_keypair(pk, sk);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.sign.keyPair.fromSecretKey = function(secretKey) {
        checkArrayTypes(secretKey);
        if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        for (var i = 0; i < pk.length; i++) pk[i] = secretKey[32 + i];
        return { publicKey: pk, secretKey: new Uint8Array(secretKey) };
      };
      nacl2.sign.keyPair.fromSeed = function(seed) {
        checkArrayTypes(seed);
        if (seed.length !== crypto_sign_SEEDBYTES)
          throw new Error("bad seed size");
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
        for (var i = 0; i < 32; i++) sk[i] = seed[i];
        crypto_sign_keypair(pk, sk, true);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.sign.publicKeyLength = crypto_sign_PUBLICKEYBYTES;
      nacl2.sign.secretKeyLength = crypto_sign_SECRETKEYBYTES;
      nacl2.sign.seedLength = crypto_sign_SEEDBYTES;
      nacl2.sign.signatureLength = crypto_sign_BYTES;
      nacl2.hash = function(msg) {
        checkArrayTypes(msg);
        var h = new Uint8Array(crypto_hash_BYTES);
        crypto_hash(h, msg, msg.length);
        return h;
      };
      nacl2.hash.hashLength = crypto_hash_BYTES;
      nacl2.verify = function(x, y) {
        checkArrayTypes(x, y);
        if (x.length === 0 || y.length === 0) return false;
        if (x.length !== y.length) return false;
        return vn(x, 0, y, 0, x.length) === 0 ? true : false;
      };
      nacl2.setPRNG = function(fn) {
        randombytes = fn;
      };
      (function() {
        var crypto2 = typeof self !== "undefined" ? self.crypto || self.msCrypto : null;
        if (crypto2 && crypto2.getRandomValues) {
          var QUOTA = 65536;
          nacl2.setPRNG(function(x, n) {
            var i, v = new Uint8Array(n);
            for (i = 0; i < n; i += QUOTA) {
              crypto2.getRandomValues(v.subarray(i, i + Math.min(n - i, QUOTA)));
            }
            for (i = 0; i < n; i++) x[i] = v[i];
            cleanup(v);
          });
        } else if (typeof require !== "undefined") {
          crypto2 = require_crypto();
          if (crypto2 && crypto2.randomBytes) {
            nacl2.setPRNG(function(x, n) {
              var i, v = crypto2.randomBytes(n);
              for (i = 0; i < n; i++) x[i] = v[i];
              cleanup(v);
            });
          }
        }
      })();
    })(typeof module2 !== "undefined" && module2.exports ? module2.exports : self.nacl = self.nacl || {});
  }
});

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => CalderaPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian6 = require("obsidian");

// ../core/src/index.ts
var import_tweetnacl = __toESM(require_nacl_fast(), 1);

// ../core/src/agent-prompt.ts
var PRIVACY_RULES = `Everything public is on the open internet, can be copied forever, and can affect other people. Be very cautious. Never write any of these into anything public:
- Other people: no names, initials, handles, photos or descriptions that identify anyone I meet, work with, hire, date, advise or invest with. Say "a founder", "the team", "a friend" only when it adds nothing identifying - usually leave it out.
- Meetings: no meetings, calls, lunches, dinners, interviews or events - not their titles, times, dates, attendees, or that they happened with someone specific.
- Times and places: no times of day, schedules, travel, cities, venues, addresses, offices, home or "where I am".
- Secret or sensitive work: no unannounced, stealth, confidential or NDA projects, codenames, deals, fundraising, investors, acquisitions, valuations, hiring, firing or anything said in confidence.
- Things that can get someone in trouble: legal, medical, health, HR, money, salaries, debts, relationships, family, children, politics, religion.
- Proprietary methods: no trading strategies, signals, indicators, thresholds, regime or risk rules, entry/exit logic, win rates, model weights, prompts, data sources or other trade secrets - in the journal, the garden or anywhere public. Name the theme only ("worked on the trading system").
- Contact details and links: no emails, phone numbers or links to private documents. No money amounts at all.
Describe work only by its public theme ("shipped a release", "wrote about design") and only name things I have already made public on my page (my own public projects, topics and links). If you are unsure, leave it out - an empty field is fine. Caldera also drops any journal line that looks sensitive before publishing.`;
function agentPrompt(o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, "");
  const vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  const activity = o.activityFile || "Caldera/activity.json";
  const zip = o.zipUrl || hub + "/download/caldera-latest.zip";
  const topics = o.publicTopics?.length ? o.publicTopics.map((t) => "#" + t).join(", ") : "the tags I allow-listed in Settings -> Caldera -> Public topics";
  const page2 = o.handle ? `${hub}/@${o.handle}/` : `${hub}/@<my handle>/`;
  const plugin = `1. Download ${zip} and unzip it into "<vault>/.obsidian/plugins/caldera/" so that folder contains main.js, manifest.json and styles.css (create the folders if needed).
2. Add "caldera" to the JSON array in "<vault>/.obsidian/community-plugins.json" (create the file as ["caldera"] if it does not exist). Do not remove other entries.`;
  const welcome = `Caldera opens a Welcome window where I type my name and pick a handle; it creates my identity on this device, publishes my profile and opens it in my browser. Do NOT create the identity, read the plugin's data.json, or handle my keys yourself - that file holds my private key. Wait until I tell you my profile is live, then continue with step 2.`;
  const install = o.installed ? `## 1. Install
Caldera is already installed and enabled in this vault. Skip to step 2.
` : `## 0. Obsidian itself (if I'm new - many people are - this step sets everything up; skip it only if I already use Obsidian)
1. Check whether Obsidian is installed (macOS: /Applications/Obsidian.app or ~/Applications/Obsidian.app; Windows: %LOCALAPPDATA%\\Programs\\Obsidian\\Obsidian.exe; Linux: the obsidian command, Flatpak md.obsidian.Obsidian, or an Obsidian AppImage).
2. If it is not installed, tell me you are about to install Obsidian (the free official app from https://obsidian.md), then install it:
   - macOS: brew install --cask obsidian  (no Homebrew? download https://obsidian.md/download , open the .dmg and copy Obsidian.app into /Applications)
   - Windows: winget install --id Obsidian.Obsidian -e  (or run the installer from https://obsidian.md/download)
   - Linux: flatpak install -y flathub md.obsidian.Obsidian  (or the AppImage / .deb from https://obsidian.md/download)
   If you cannot install software here, give me the download link and wait until I tell you it's installed. Do not open Obsidian yet.
3. If I don't have a vault yet, make one for me, completely, BEFORE Obsidian opens it:
   a. Ask where I'd like my notes; if I don't care, use ~/Documents/Notes (Windows: %USERPROFILE%\\Documents\\Notes). Create the folder, a "Welcome.md" note in it ("# Welcome" and one line saying this is my vault), and an empty ".obsidian" folder inside it. That folder is now my vault; use its absolute path below.
   b. Install the plugin into it now (exactly as in step 1 below), so it is ready on first launch.
   c. Make Obsidian quit if it is running (it rewrites its vault list on exit). Then register the vault in Obsidian's vault list, a JSON file at:
      macOS ~/Library/Application Support/obsidian/obsidian.json - Windows %APPDATA%\\obsidian\\obsidian.json - Linux ~/.config/obsidian/obsidian.json (Flatpak: ~/.var/app/md.obsidian.Obsidian/config/obsidian/obsidian.json).
      Create the folder and file if missing. The file looks like {"vaults":{"<id>":{"path":"<absolute vault path>","ts":<now in ms>,"open":true}}}. Add my vault under a new random 16-character lowercase hex id, keep every other key and vault already in the file, and write valid JSON.
   d. Open it: macOS  open "obsidian://open?path=<url-encoded absolute vault path>"  - Windows  start "" "obsidian://open?path=..."  - Linux  xdg-open "obsidian://open?path=..." . If Obsidian instead shows its vault picker, tell me to click "Open folder as vault" and choose that folder.
   e. Tell me, in plain words: in Obsidian, open Settings (the gear, bottom left) -> Community plugins -> click "Turn on community plugins". (If Obsidian shows a "Trust author and enable plugins" prompt instead, click that.) Caldera is already switched on, so its Welcome window appears right away. ${welcome}
   Steps a-e replace step 1 - after e, go straight to step 2.

## 1. Install the plugin (when I already have a vault)
${plugin.replace(/<vault>/g, vault)}
3. Tell me to restart Obsidian (quit fully, then open it). If Obsidian asks, I turn off Restricted mode (Settings -> Community plugins -> Turn on community plugins) and make sure Caldera is switched on. ${welcome}
`;
  return `You are helping me run Caldera, the social layer for my Obsidian vault (${hub}). Caldera builds a public profile page from my vault. Follow these instructions exactly.

Vault: ${vault}${o.vaultPath ? "" : "\n(If I did not fill this in, find my vault yourself: it is the folder that contains a .obsidian folder. If there is more than one, ask me which. If there is none, I probably don't have Obsidian yet - many people don't - so start with step 0.)"}
My public page: ${page2}

${install}
## 2. Routine (4 times per workday: 9am, 12pm, 3pm and 6pm my local time, Monday to Friday)
Schedule this as a job on my computer (cron, launchd, Task Scheduler, or your own scheduler) at those four times. Nothing overnight and nothing on weekends; Monday's first run catches up the weekend. Keep it light on AI tokens: compute counts with code that reads logs, not with an AI call; read a calendar connector at most once a day and cache the result; and never rewrite a journal entry that already exists.
A. Journal entry (first run of each workday only, for YESTERDAY; on Monday also Saturday and Sunday if they had activity; skip any day that already has caldera_headline). Open (or create) that day's daily note, named YYYY-MM-DD.md, wherever my daily notes live. Add these frontmatter properties, keeping everything already in the note:
   caldera_headline: one sentence, the shape of the day
   caldera_focus: 2-4 short items, what I worked on
   caldera_wins: 1-3 short items, what got done
   caldera_themes: 1-3 single words
   Write them from my notes, calendar, sent email, commits and AI sessions for that day - whatever you can access.
   Name my projects the way they appear in Caldera/profile.md "projects" when they come up: Caldera grows a garden page for each project (and each distinctive theme) from these journal lines, adding a dated entry whenever it comes up.

B. Activity counts (every run, for today and yesterday). Update "${vault}/${activity}" (create it if missing). Format:
   { "days": [ { "date": "YYYY-MM-DD", "meetings": 0, "emails": 0, "prompts": 0, "commits": 0, "docs": 0, "tokens": 0 } ],
     "ai": { "total": 0, "window_days": 45, "models": [["Claude Opus 5.5", 0]], "providers": [["Anthropic", 0]] },
     "code": { "commits": 0, "repos": 0, "languages": ["Python"], "weekly": [0], "url": "https://github.com/<me>", "start": "Mon YYYY" } }
   One object per date: replace that date's object if it exists, keep the last 60 days, and only include counts you can actually measure (omit the rest - never guess). meetings = calendar events attended, emails = emails I sent, prompts = AI prompts I sent, commits = git commits I authored, docs = documents/attachments I produced or filed, tokens = AI tokens processed for me that day. Notes are counted by the plugin itself.
   AI usage ("tokens" per day and the "ai" block, last 45 days): read the usage logs of the AI tools on this computer - Claude Code (~/.claude/projects/**/*.jsonl: assistant messages have message.model and message.usage; count each message.id once; tokens = input + output + cache read + cache write) and Codex (~/.codex/sessions/**/*.jsonl: event_msg token_count -> last_token_usage.total_tokens, model from turn_context). Add other tools only if they keep local usage logs. Group by model (readable names) and by provider. Never include prompts, file names or costs.
   Code ("code" block, optional): if I use GitHub, count my commits in the last 52 weeks per week across my repositories (the gh CLI or the GitHub API), number of repos, and top 4 languages. Counts only - never repository names that are private.

C. Publish. If Caldera auto-publish is on (Settings -> Caldera -> Auto-publish every N hours), you are done. Otherwise ask me to run "Caldera: Publish my profile" from the command palette.

## 3. Privacy rules (these override everything above)
${PRIVACY_RULES}
Themes and topics: only use topics among ${topics}.
Also: never write to any other part of the vault, never change notes' privacy markings (caldera: public / garden / friends / private) or move notes into or out of the Garden folder, never touch .obsidian/plugins/caldera/data.json.

## 4. Check your work
After each run, tell me in two lines what you wrote for that day, and anything you skipped because it looked private.

## 5. When I ask you to change my page
My name, headline, photo, banner, links, properties, topics, which sections show and whether I'm listed in the directory all live in the frontmatter of "${vault}/Caldera/profile.md". Edit that file (keep its format; the same privacy rules apply) and the page republishes itself within about a minute. Guide: ${hub}/guide.html

## 6. My garden home
Once I have planted notes, my garden home is ${hub}/@<my handle>/garden.html: it shows live my notes, links from other gardens, gravity (goodwill friends give), help credits (100 to start; ask bounties are held until awarded, returned after 30 days, no cash value), my open asks and offers, friends and weekly rank. After the first publish, tell me that link and offer to draft 2 asks and 2 offers (I post them with "Caldera: Post an ask" / "Caldera: Post an offer").

## 7. My profile inside Obsidian
The ribbon icon "My Caldera profile" (or the command "Caldera: Open my profile in Obsidian") opens my page as a tab. "My view" is built from my vault right now and adds private sections only I see: since I last looked (visits, gravity, new friends, links in), today as it happens, on this day a week/month/year ago, a note brought back, patterns, and goals from "${vault}/Caldera/Goals.md" (checkboxes under ## headings). Nothing in those sections is published. "Public view" shows the live page exactly as visitors see it. If I want, create Caldera/Goals.md with my current goals, and switch on "Open my profile when Obsidian starts" in Caldera settings.

## 8. My city (GitHub as a city)
If I use GitHub, write "${vault}/Caldera/city.json" and refresh it every few hours (schedule it): {"generated": "<ISO time>", "repos": [{"name", "project", "public", "language", "commits", "weeks", "week", "today", "pushed", "url", "description"}]} with one row per repo I own: project = which of my projects it belongs to (group repos into districts), public = true only for public repos, commits = commits in the last 52 weeks, weeks = the last 12 weekly commit counts, week = commits in the last 7 days, today = commits today, pushed = last push time, url and description only for public repos. Use the GitHub CLI (gh api user/repos and repos/<owner>/<repo>/stats/commit_activity). Caldera turns it into a little city: districts are projects, buildings are repos. Visitors only see public repos and projects already listed on my profile; private repos appear only in my own My view.`;
}
function richerPrompt(o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, "");
  const vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  const activity = o.activityFile || "Caldera/activity.json";
  return `Help me make my Caldera profile richer. Caldera (${hub}) builds a public profile page from my Obsidian vault.

Vault: ${vault}${o.vaultPath ? "" : "\n(If I did not fill this in, find my vault yourself: it is the folder that contains a .obsidian folder. If there is more than one, ask me which.)"}

Work through these one at a time. Anything that would become PUBLIC needs my explicit yes first: show me exactly what you propose, wait for my answer, then make only the approved changes.

1. My garden (public notes). Find 3-8 notes that would be good to grow in public: evergreen essays, how-tos, reading notes, overviews of work that is already public. Skip anything about people, clients, deals, money, health, family or unannounced work. List them with one line each on why, and a suggested stage (seedling = rough, budding = taking shape, evergreen = worked through). After I approve, add to the frontmatter of the approved notes only: "caldera: garden", "stage: <stage>" and "license: all-rights" (ask me if I want "cc-by" instead). The WHOLE note becomes a public page, so read every line and point out anything private first. Email addresses and phone numbers are removed automatically; links to notes that are not in the garden show as plain text. Then tell me to run "Caldera: Preview my garden".

2. Notes friends can receive. Suggest notes I might want to share with friends as encrypted cards (frameworks, checklists, templates). After I approve, add "caldera: friends" to their frontmatter. These are not public; only friends I pick receive them.

3. Public topics. List my 10 most-used tags that are safe to show publicly (no client, company or people tags), with a short label for each. I will add them myself in Settings -> Caldera -> Public topics. Do not edit plugin settings.

4. Activity sources. Set up a scheduled job (cron, launchd, Task Scheduler, or your own scheduler) that runs 4 times per workday - 9am, 12pm, 3pm and 6pm local, Monday to Friday, nothing overnight or on weekends - and writes COUNTS ONLY for today and yesterday into "${vault}/${activity}" in this format, replacing that date's entry and keeping 60 days:
   { "days": [ { "date": "YYYY-MM-DD", "meetings": 0, "emails": 0, "prompts": 0, "commits": 0, "docs": 0 } ] }
   Use the sources I actually have: calendar events attended, emails I sent, AI prompts I sent, git commits I authored, documents I produced. Only numbers - never titles, subjects, names or contents. Tell me which sources you connected and which you could not. If a daily journal routine already writes this file, extend it instead of adding a second writer.

5. My page text. Draft, for Caldera/profile.md: "headline" (one line), "summary" (2 sentences, links as [[Label|https://...]]), "now" (3 lines on what I'm doing now), "timeline" (only things already public: "Year | milestone | one-line detail", grouped into chapters with "era | Name | 2015-2020" lines), "projects" (Name | status | https://link, only public projects) and "links" (Label | https://url - include my GitHub profile if I have one: that turns on the Code section). Offer to set a profile photo: save an image I choose into "Caldera/img/" and set "photo" to that path. Also suggest "sidebar" groups (Group | item, item), up to 14 "graph" note names (people/companies/projects I'm comfortable showing - the page shows how many notes link to each), and 6 "backlinks" (Title | short context). Show me everything first; write only what I approve.

6. Daily journal. If nothing writes my journal yet, extend the job from step 4 so that on its first run each workday it also opens yesterday's daily note (on Monday, also the weekend days with activity; skip days already written) (YYYY-MM-DD.md) and adds caldera_headline (one line), caldera_focus (up to 3), caldera_wins (up to 3) and caldera_themes (1-3 words), written from what I did that day, following the privacy rules below. Then backfill: For each of the last 14 days that has activity, add caldera_headline, caldera_focus, caldera_wins and caldera_themes to that day's daily note (YYYY-MM-DD.md), following the privacy rules below. Show me the 14 entries before writing them.

7. Asks, offers and my garden home. Draft 2 asks ("I could use help with...") and 2 offers ("I can help with...") that fit what I work on. I will post the ones I like with the commands "Caldera: Post an ask" and "Caldera: Post an offer". Then set up my garden home - the hub page at ${hub}/@<my handle>/garden.html that shows, live: notes planted, links from other gardens, gravity, help credits, my open asks and offers, friends and my weekly rank, with a plain explanation of each. Check that "sections" in Caldera/profile.md turns on garden, asks and social (ask me before changing it). Explain the economy to me in 3 short lines: gravity = goodwill friends give with the "+ gravity" button in the Caldera panel (positive only, fades over a 30-day half-life, worth a bit more from people who have more of it); help credits = everyone starts with 100, an ask's bounty is held until I award it to whoever helped and returns after 30 days if nobody does, no cash value; links = other gardens can link my notes with [[@<my handle>/note-slug]]. Suggest 2-3 people I could invite as friends (by role, not by name, unless I name them).

8. Finish. Tell me to run "Caldera: Preview my public profile", check it, then "Caldera: Publish my profile".

Privacy rules (these override everything above):
${PRIVACY_RULES}
- Never read or edit .obsidian/plugins/caldera/data.json - it holds my private key.
- Never remove or change an existing "caldera:" marking without asking me.`;
}
function editPrompt(o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, "");
  const vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  return `Help me change my Caldera profile (${hub}/@${o.handle || "<my handle>"}/). Caldera builds that public page from my Obsidian vault.

Vault: ${vault}${o.vaultPath ? "" : "\n(If I did not fill this in, find my vault yourself: it is the folder that contains a .obsidian folder. If there is more than one, ask me which.)"}

Where things live:
- Name, headline, photo, banner, links, properties, topics, which sections show, and directory listing: the frontmatter of "Caldera/profile.md". Keep its format. Photo and banner are paths to images inside the vault.
- A note on my page: add "caldera: public" to that note's frontmatter (title and first paragraph are shown). Remove it to take the note down.
- My daily journal: caldera_headline / caldera_focus / caldera_wins / caldera_themes in daily notes named YYYY-MM-DD.md.
- Activity counts: "Caldera/activity.json".
The page republishes automatically about a minute after Caldera/profile.md changes. For anything else, tell me to run "Caldera: Publish my profile".

Rules:
- Show me the exact change before you make it, and only make what I approve.
${PRIVACY_RULES}
- Never read or edit .obsidian/plugins/caldera/data.json - it holds my private key. My handle can only be changed in Settings -> Caldera.

What I want to change: <DESCRIBE THE CHANGE>`;
}

// ../core/src/privacy.ts
var RULES = [
  ["time", /\b\d{1,2}(:\d{2})?\s?(a\.?m\.?|p\.?m\.?)\b|\b\d{1,2}:\d{2}\b|\b(noon|midnight|o'clock|this morning|this afternoon|tonight|tomorrow|tmrw)\b/i],
  ["meeting", /\b(meeting|meetings|met with|meet with|meets with|call with|calls with|called|zoom|lunch|dinner|breakfast|coffee|drinks|catch[- ]?up|1[:-]1|one[- ]on[- ]one|interview(ed)?|pitched|pitch meeting|sync with|session with|appointment|attendee|agenda|board meeting|offsite|hosted|visited|visit to|trip|flight|flew|travel(l?ed|ing)?)\b/i],
  ["location", /\b(?:in|at|from|to|near|around)\s+(?:the\s+)?[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*/],
  // case-sensitive: "in Santa Monica", not "in the category"
  ["place", /\b(street|st\.|avenue|ave\.|boulevard|blvd|road|rd\.|lane|suite|ste\.|hotel|restaurant|airport|hq|headquarters|downtown|neighborhood|zip code|address|office in|offices in)\b/i],
  ["secret", /\b(secret|confidential|stealth|unannounced|under wraps|nda|non[- ]disclosure|private beta|embargo(ed)?|off the record|internal only|not public|leak(ed)?|rumou?r|codename|code name)\b/i],
  ["trouble", /\b(lawsuit|sue[ds]?|legal|lawyer|attorney|court|settlement|investigation|fired|firing|layoffs?|laid off|resign(ed|ation)?|hr\b|complaint|harass\w*|divorce|custody|diagnos\w*|therapy|therapist|doctor|hospital|surgery|medical|health|pregnan\w*|arrest\w*|police|debt|bankrupt\w*|salary|raise|bonus|equity|valuation|term sheet|acquisition|acquire[ds]?|merger|investor|investors|fundrais\w*|round|due diligence|diligence|cap table)\b/i],
  ["money", /[$€£¥]\s?\d|\b\d[\d,.]*\s?(k|m|mm|bn|million|billion|thousand|usd|dollars?|euros?)\b/i],
  ["contact", /[\w.+-]+@[\w-]+\.[\w.]+|(?<!\d)(\+?\d[\d .()-]{7,}\d)(?!\d)|https?:\/\/|www\./i],
  ["family", /\b(wife|husband|partner|girlfriend|boyfriend|ex-wife|ex-husband|son|daughter|kids?|children|mom|dad|mother|father|brother|sister|family)\b/i]
];
var BASE_ALLOW = [
  "Obsidian",
  "Caldera",
  "Claude",
  "Claude Code",
  "ChatGPT",
  "OpenAI",
  "Codex",
  "Cursor",
  "GitHub",
  "Git",
  "Google",
  "Gmail",
  "Apple",
  "iOS",
  "Android",
  "Mac",
  "macOS",
  "Windows",
  "Linux",
  "Notion",
  "Slack",
  "Discord",
  "Figma",
  "Python",
  "JavaScript",
  "TypeScript",
  "React",
  "Node",
  "AI",
  "API",
  "LLM",
  "MCP",
  "SQL",
  "CSS",
  "HTML",
  "PDF",
  "CRM",
  "SEO",
  "UX",
  "UI",
  "Markdown",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
  "Building",
  "Operations",
  "Research",
  "Writing",
  "Design",
  "Shipping",
  "Learning"
];
function publicTextFilter(allowed = []) {
  const allow = new Set([...BASE_ALLOW, ...allowed].flatMap((a) => [a.toLowerCase(), ...a.toLowerCase().split(/\s+/)]).filter(Boolean));
  const why = (line) => {
    const t = String(line ?? "").trim();
    if (!t) return null;
    for (const [name, rx] of RULES) {
      const m = t.match(rx);
      if (!m) continue;
      if (name === "location") {
        const words2 = m[0].match(/[A-Z][a-z]+/g) || [];
        if (words2.length && words2.every((w) => allow.has(w.toLowerCase()))) continue;
      }
      return name;
    }
    const words = t.split(/\s+/);
    for (let i = 1; i < words.length; i++) {
      const w = words[i].replace(/[^A-Za-z'-]/g, "");
      if (!/^[A-Z][a-z]{1,}/.test(w)) continue;
      if (/[.!?:]$/.test(words[i - 1])) continue;
      if (allow.has(w.toLowerCase()) || allow.has(w.toLowerCase().replace(/'s$/, ""))) continue;
      return "name";
    }
    return null;
  };
  const f = (line) => why(line) === null;
  f.why = why;
  return f;
}

// ../core/src/index.ts
var PROTOCOL_VERSION = 1;
var B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function b58encode(bytes) {
  let n = 0n;
  for (const b of bytes) n = (n << 8n) + BigInt(b);
  let out = "";
  while (n > 0n) {
    out = B58[Number(n % 58n)] + out;
    n /= 58n;
  }
  for (const b of bytes) {
    if (b === 0) out = "1" + out;
    else break;
  }
  return out;
}
function b58decode(s) {
  let n = 0n;
  for (const c of s) {
    const i = B58.indexOf(c);
    if (i < 0) throw new Error("bad base58");
    n = n * 58n + BigInt(i);
  }
  const bytes = [];
  while (n > 0n) {
    bytes.unshift(Number(n & 255n));
    n >>= 8n;
  }
  for (const c of s) {
    if (c === "1") bytes.unshift(0);
    else break;
  }
  return new Uint8Array(bytes);
}
var b64 = {
  enc(u) {
    let s = "";
    for (const b of u) s += String.fromCharCode(b);
    return btoa(s);
  },
  dec(s) {
    const bin = atob(s);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
};
var utf8 = (s) => new TextEncoder().encode(s);
var fromUtf8 = (u) => new TextDecoder().decode(u);
function canonical(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  const obj = value;
  return "{" + Object.keys(obj).filter((k) => obj[k] !== void 0).sort().map((k) => JSON.stringify(k) + ":" + canonical(obj[k])).join(",") + "}";
}
function newIdentity() {
  const sign2 = import_tweetnacl.default.sign.keyPair();
  const box = import_tweetnacl.default.box.keyPair();
  return {
    id: idFromPublicKey(sign2.publicKey),
    signPublic: b64.enc(sign2.publicKey),
    signSecret: b64.enc(sign2.secretKey),
    boxPublic: b64.enc(box.publicKey),
    boxSecret: b64.enc(box.secretKey)
  };
}
function idFromPublicKey(pk) {
  return "cal:" + b58encode(pk);
}
function publicKeyFromId(id) {
  if (!id.startsWith("cal:")) throw new Error("not a caldera id");
  const pk = b58decode(id.slice(4));
  if (pk.length !== 32) throw new Error("bad id length");
  return pk;
}
function signingBytes(e) {
  return utf8(canonical({ v: e.v, type: e.type, from: e.from, ts: e.ts, body: e.body }));
}
function sign(identity, type, body, ts = (/* @__PURE__ */ new Date()).toISOString()) {
  const unsigned = { v: PROTOCOL_VERSION, type, from: identity.id, ts, body };
  const sig = import_tweetnacl.default.sign.detached(signingBytes(unsigned), b64.dec(identity.signSecret));
  return { ...unsigned, sig: b64.enc(sig) };
}
function verify(e) {
  try {
    if (!e || e.v !== PROTOCOL_VERSION || typeof e.sig !== "string") return false;
    return import_tweetnacl.default.sign.detached.verify(signingBytes(e), b64.dec(e.sig), publicKeyFromId(e.from));
  } catch {
    return false;
  }
}
function envelopeHash(e) {
  return b64.enc(import_tweetnacl.default.hash(utf8(canonical(e)))).slice(0, 43);
}
function seal(plaintext, recipientBoxPublic, sender) {
  const nonce = import_tweetnacl.default.randomBytes(import_tweetnacl.default.box.nonceLength);
  const box = import_tweetnacl.default.box(utf8(plaintext), nonce, b64.dec(recipientBoxPublic), b64.dec(sender.boxSecret));
  return { nonce: b64.enc(nonce), box: b64.enc(box) };
}
function open(sealed, senderBoxPublic, recipient) {
  const out = import_tweetnacl.default.box.open(b64.dec(sealed.box), b64.dec(sealed.nonce), b64.dec(senderBoxPublic), b64.dec(recipient.boxSecret));
  return out ? fromUtf8(out) : null;
}
var ACTIVITY_WEIGHTS = { meetings: 6, emails: 2, prompts: 1, commits: 0.5, notes: 0.25, docs: 1 };
var ACTIVITY_CAPS = { notes: 60, docs: 40, commits: 200 };
function activityScore(c) {
  let s = 0;
  for (const [k, w] of Object.entries(ACTIVITY_WEIGHTS)) {
    s += w * Math.min(c[k] ?? 0, ACTIVITY_CAPS[k] ?? Infinity);
  }
  return Math.round(s);
}
function newId(prefix) {
  return prefix + "_" + b58encode(import_tweetnacl.default.randomBytes(12));
}

// src/settings.ts
var import_obsidian = require("obsidian");
var DEFAULT_SETTINGS = {
  hubUrl: "https://caldera.social",
  identity: null,
  handle: "",
  name: "",
  headline: "",
  theme: "dark",
  avatarPath: "",
  bannerPath: "",
  links: [],
  properties: [],
  sections: { journal: true, scoreboard: true, properties: true, numbers: true, topics: true, notes: true, asks: true, social: true, links: true, sidebar: true, rail: true },
  publicTopics: [["ai", "AI"], ["design", "Design"], ["startups", "Startups"], ["investing", "Investing"], ["writing", "Writing"]],
  activityFile: "Caldera/activity.json",
  historyDays: 45,
  inboxFolder: "Caldera/Inbox",
  lastInboxSync: "1970-01-01T00:00:00.000Z",
  asks: [],
  offers: [],
  autoPublishHours: 6,
  welcomed: false,
  listed: true,
  lastSeenRelease: "",
  lastPublished: 0,
  tree: [],
  graph: [],
  backlinks: [],
  summary: "",
  now: [],
  timeline: [],
  projects: [],
  knows: [],
  tabs: [],
  gardenFolder: "Garden",
  gardenUrl: "",
  gardenJournal: true
};
var SECTION_LABELS = {
  journal: "Daily journal (flip through days)",
  scoreboard: "Scoreboard (streak, rank, 30-day bars)",
  properties: "Properties",
  numbers: "Vault numbers (notes, words, links, active days)",
  topics: "Topics (allow-listed tags only)",
  notes: "Notes marked caldera: public",
  asks: "Help exchange (asks and offers)",
  social: "Friends, gravity and credits",
  links: "Links elsewhere",
  garden: "Garden (full pages for notes you plant: Garden folder or caldera: garden)",
  city: "City (your GitHub as a little city, from Caldera/city.json; private repos only in your private views)"
};
var CalderaSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    containerEl.empty();
    containerEl.createEl("p", { text: "Your vault stays private. Only the sections you switch on below, notes you mark caldera: public, and counts are published. Use 'Preview profile' before publishing.", cls: "setting-item-description" });
    new import_obsidian.Setting(containerEl).setName("Identity").setHeading();
    new import_obsidian.Setting(containerEl).setName("Your Caldera ID").setDesc(s.identity ? s.identity.id : "Not created yet").addButton((b) => b.setButtonText(s.identity ? "Copy ID" : "Create identity").onClick(async () => {
      if (!s.identity) {
        await this.plugin.ensureIdentity();
        this.display();
      } else {
        await navigator.clipboard.writeText(s.identity.id);
        new import_obsidian.Notice("ID copied");
      }
    })).addButton((b) => b.setButtonText("Export recovery key").setDisabled(!s.identity).onClick(async () => {
      await navigator.clipboard.writeText(btoa(JSON.stringify(s.identity)));
      new import_obsidian.Notice("Recovery key copied. Store it somewhere safe; anyone with it can act as you.");
    }));
    this.text("Handle", "Your address on the hub: hub/@handle", "handle", (v) => v.toLowerCase().replace(/[^a-z0-9-]/g, ""));
    this.text("Hub", "Where your profile is hosted and friends connect. Self-hosters can point this at their own hub.", "hubUrl");
    new import_obsidian.Setting(containerEl).setName("List me in the directory").setDesc("Show your profile card on the public People page. Off: your page still works for anyone with the link, but isn't browsable.").addToggle((t) => t.setValue(s.listed !== false).onChange(async (v) => {
      s.listed = v;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("Profile").setHeading();
    new import_obsidian.Setting(containerEl).setName("Edit your page as a note").setDesc("Name, headline, photo, links, topics and sections also live in Caldera/profile.md. Edit it (or ask your AI agent to) and the page republishes itself. Values there win over the fields below.").addButton((b) => b.setButtonText("Open profile file").onClick(() => this.plugin.openProfileFile()));
    this.text("Name", "", "name");
    this.text("Headline", "One line under your name", "headline");
    this.text("Avatar image", "Path in your vault, e.g. Attachments/me.jpg", "avatarPath");
    this.text("Banner image", "Path in your vault", "bannerPath");
    new import_obsidian.Setting(containerEl).setName("Theme").addDropdown((d) => d.addOptions({ dark: "Dark", light: "Light" }).setValue(s.theme).onChange(async (v) => {
      s.theme = v;
      await this.plugin.saveSettings();
    }));
    this.pairs("Links", "One per line: Label | https://url", "links");
    this.pairs("Properties", "One per line: key | value (shown as a properties block)", "properties");
    new import_obsidian.Setting(containerEl).setName("What is public").setHeading();
    for (const [k, label] of Object.entries(SECTION_LABELS)) {
      new import_obsidian.Setting(containerEl).setName(label).addToggle((t) => t.setValue(s.sections[k] !== void 0 ? !!s.sections[k] : k === "garden" || k === "city").onChange(async (v) => {
        s.sections[k] = v;
        await this.plugin.saveSettings();
      }));
    }
    this.text("Garden folder", "Notes in this folder are published as full pages, with stage and license from their properties. Empty = only notes marked caldera: garden.", "gardenFolder", (v) => v.replace(/^\/+|\/+$/g, ""));
    new import_obsidian.Setting(containerEl).setName("Grow my garden from my journal").setDesc("Each public project and recurring theme in your daily journal gets a garden page that adds a dated entry whenever it comes up. Uses only journal text that is already public.").addToggle((t) => t.setValue(s.gardenJournal !== false).onChange(async (v) => {
      s.gardenJournal = v;
      await this.plugin.saveSettings();
    }));
    this.text("Existing garden URL", "Optional: a garden you already publish elsewhere (Quartz, Obsidian Publish...). Linked from your page.", "gardenUrl", (v) => /^https:\/\//.test(v) ? v : "");
    this.pairs("Public topics", "Only these tags are counted. One per line: tag | Label", "publicTopics");
    this.text("Activity file", "Optional JSON of daily counts from outside tools (calendar, email, git)", "activityFile");
    new import_obsidian.Setting(containerEl).setName("My profile tab").setHeading();
    new import_obsidian.Setting(containerEl).setName("Open my profile when Obsidian starts").setDesc("The My profile tab shows your page built from your vault, plus private sections only you can see (visits, today, on this day, patterns, goals). Switch to Public view to see the live page.").addToggle((t) => t.setValue(!!s.openProfileOnStartup).onChange(async (v) => {
      s.openProfileOnStartup = v;
      await this.plugin.saveSettings();
    })).addButton((b) => b.setButtonText("Open now").onClick(() => this.plugin.openProfileTab()));
    new import_obsidian.Setting(containerEl).setName("Private web address (Tailscale)").setDesc(createFragment((f) => {
      f.appendText("See your private sections in a browser, on any of your Tailscale devices. Every 10 minutes Obsidian pushes them to your hub, which stores them encrypted and shows them only to your own Tailscale account, never on your public page. Needs a hub with a private address set up for you (self-hosted, or the operator's own profile).");
      if (s.privateUrl) {
        f.createEl("br");
        f.appendText("Your private address: ");
        f.createEl("a", { text: s.privateUrl, href: s.privateUrl });
      }
    })).addToggle((t) => t.setValue(!!s.privateWeb).onChange(async (v) => {
      s.privateWeb = v;
      await this.plugin.saveSettings();
      this.plugin.schedulePrivatePush();
      if (v && !await this.plugin.pushPrivate(true)) {
        s.privateWeb = false;
        await this.plugin.saveSettings();
        this.plugin.schedulePrivatePush();
      }
      this.display();
    }));
    new import_obsidian.Setting(containerEl).setName("Publishing").setHeading();
    new import_obsidian.Setting(containerEl).setName("Auto-publish interval (hours)").setDesc("0 = only when you publish manually").addText((t) => t.setValue(String(s.autoPublishHours)).onChange(async (v) => {
      s.autoPublishHours = Math.max(0, Number(v) || 0);
      await this.plugin.saveSettings();
      this.plugin.scheduleAutoPublish();
    }));
  }
  text(name, desc, key, clean = (v) => v) {
    new import_obsidian.Setting(this.containerEl).setName(name).setDesc(desc).addText((t) => t.setValue(String(this.plugin.settings[key] ?? "")).onChange(async (v) => {
      this.plugin.settings[key] = clean(v.trim());
      await this.plugin.saveSettings();
    }));
  }
  pairs(name, desc, key) {
    new import_obsidian.Setting(this.containerEl).setName(name).setDesc(desc).addTextArea((t) => {
      t.setValue(this.plugin.settings[key].map((p) => p.join(" | ")).join("\n"));
      t.inputEl.rows = 4;
      t.onChange(async (v) => {
        this.plugin.settings[key] = v.split("\n").map((l) => l.split("|").map((x) => x.trim())).filter((p) => p[0] && p[1]).map((p) => [p[0], p.slice(1).join("|")]);
        await this.plugin.saveSettings();
      });
    });
  }
};

// src/collect.ts
var import_obsidian3 = require("obsidian");

// src/assets/theme.css
var theme_default = `/* ============================================================================
   LIVING PROFILE - DESIGN TOKENS
   This is the ONLY file you need to edit to restyle the whole page.
   Every color, font, size, radius and spacing used anywhere comes from here.
   profile.css uses these variables only; it never hard-codes a color.

   Quick recipes:
   - Switch to the light theme:  <html data-theme="light"> in index template,
     or set "theme": "light" in config/profile.json.
   - New accent color:           change --accent (and --accent-soft).
   - Different fonts:            change --font-body / --font-display / --font-mono
                                 (and the Google Fonts link in the template).
   - Tighter / looser layout:    change --space-unit.
   ========================================================================== */

:root {
  /* --- Typography ------------------------------------------------------- */
  --font-body: 'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif;
  --font-display: 'Source Serif 4', Georgia, serif;
  --font-mono: 'IBM Plex Mono', ui-monospace, Menlo, monospace;

  --text-xs: 11.5px;
  --text-sm: 13.5px;
  --text-md: 15px;
  --text-lg: 18px;
  --text-h2: 26px;
  --text-h1: clamp(34px, 5vw, 46px);
  --leading: 1.65;

  /* --- Spacing & shape -------------------------------------------------- */
  --space-unit: 8px;                       /* everything scales off this */
  --space-1: calc(var(--space-unit) * 0.5);
  --space-2: var(--space-unit);
  --space-3: calc(var(--space-unit) * 1.5);
  --space-4: calc(var(--space-unit) * 2);
  --space-6: calc(var(--space-unit) * 3);
  --space-8: calc(var(--space-unit) * 4);
  --radius-sm: 6px;
  --radius-md: 8px;
  --radius-lg: 14px;
  --radius-round: 999px;

  /* --- Layout ----------------------------------------------------------- */
  --sidebar-width: 250px;
  --rail-width: 300px;
  --content-width: 760px;
  --banner-height: 260px;
  --avatar-size: 112px;
  --banner-focus: 62% 14%;   /* which part of the banner photo stays in view (x y) */

  /* --- Color: dark theme (default) -------------------------------------- */
  --bg: #1C1C1F;           /* page */
  --bg-sunken: #17171A;    /* sidebars */
  --bg-raised: #232327;    /* cards, buttons */
  --bg-tab: #141416;       /* top tab bar */
  --line: #2A2A2E;         /* hairlines */
  --line-strong: #3A3A40;
  --text: #DADADF;
  --text-strong: #F2F2F5;
  --text-muted: #8A8A93;
  --accent: #8B6CF6;       /* links, highlights, graph center */
  --accent-text: #B39DFA;  /* link text on dark */
  --accent-soft: rgba(139, 108, 246, .10);
  --accent-2: #4FB89A;     /* secondary accent (help exchange, gravity) */
  --on-accent: #FFFFFF;
  --chart-bar: var(--accent);
  --chart-bar-quiet: rgba(139, 108, 246, .55);
  --graph-node: #6E6E78;
  --graph-node-hot: var(--accent-text);
  --graph-edge: var(--line-strong);
  /* activity heatmap, empty -> busiest */
  --heat-0: #232327;
  --heat-1: #3A2F66;
  --heat-2: #5B47B0;
  --heat-3: #8B6CF6;
  --heat-4: #C7B8FF;
  --chart-alt: var(--accent-2);  /* second chart color */
}

/* --- Color: light theme ------------------------------------------------- */
:root[data-theme="light"] {
  --bg: #FFFFFF;
  --bg-sunken: #F6F6F7;
  --bg-raised: #F0F0F2;
  --bg-tab: #EDEDF0;
  --line: #E4E4E7;
  --line-strong: #D0D0D6;
  --text: #2B2B30;
  --text-strong: #0D0D10;
  --text-muted: #6E6E78;
  --accent: #6D4AE8;
  --accent-text: #5A38D6;
  --accent-soft: rgba(109, 74, 232, .08);
  --accent-2: #138A6A;
  --graph-node: #A8A8B3;
  --heat-0: #EDEDF0;
  --heat-1: #D9D0FB;
  --heat-2: #B3A1F6;
  --heat-3: #8B6CF6;
  --heat-4: #5A38D6;
}
`;

// src/profile.css.ts
var PROFILE_CSS = '/* ============================================================================\n   LIVING PROFILE - COMPONENTS\n   Layout and components only. No raw colors, fonts or sizes here:\n   everything comes from theme.css. To restyle, edit theme.css.\n   ========================================================================== */\n\n* { box-sizing: border-box; }\nhtml, body { margin: 0; }\nbody {\n  background: var(--bg);\n  color: var(--text);\n  font-family: var(--font-body);\n  font-size: var(--text-md);\n  line-height: var(--leading);\n  -webkit-font-smoothing: antialiased;\n}\na { color: var(--accent-text); text-decoration: none; }\na:hover { text-decoration: underline; }\n.mono { font-family: var(--font-mono); }\n.muted { color: var(--text-muted); }\n\n/* --- Top tab bar ------------------------------------------------------- */\n.tabs {\n  display: flex; align-items: center; gap: var(--space-1);\n  background: var(--bg-tab); border-bottom: 1px solid var(--line);\n  padding: 0 var(--space-3); overflow-x: auto;\n}\n.tab { padding: 10px 14px; font-size: var(--text-sm); color: var(--text-muted); white-space: nowrap; }\n.tab.is-active {\n  color: var(--text); background: var(--bg);\n  border: 1px solid var(--line); border-bottom: 0;\n  border-radius: var(--radius-md) var(--radius-md) 0 0;\n}\n.tabs .spacer { flex: 1; }\n.sync { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); white-space: nowrap; padding-right: var(--space-2); }\n.sync .dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: var(--accent-2); margin-right: 6px; animation: pulse 2.4s ease-in-out infinite; }\n\n/* --- Three-column shell ------------------------------------------------ */\n.shell { display: flex; flex-wrap: wrap; align-items: stretch; }\n.sidebar {\n  flex: 0 1 var(--sidebar-width); min-width: 200px;\n  background: var(--bg-sunken); border-right: 1px solid var(--line);\n  padding: var(--space-3) var(--space-2); font-size: var(--text-sm);\n}\n.note { flex: 999 1 560px; min-width: 0; padding-bottom: var(--space-8); }\n.rail {\n  flex: 0 1 var(--rail-width); min-width: 240px;\n  background: var(--bg-sunken); border-left: 1px solid var(--line);\n  padding: var(--space-3); display: flex; flex-direction: column; gap: var(--space-4);\n}\n@media (max-width: 900px) {\n  .sidebar { display: none; }\n  .rail { border-left: 0; border-top: 1px solid var(--line); flex-basis: 100%; }\n}\n\n/* --- File tree --------------------------------------------------------- */\n.label { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); letter-spacing: .04em; text-transform: uppercase; }\n.tree .label { padding: 0 var(--space-2) var(--space-2); display: block; }\n.side-inner { position: sticky; top: 0; max-height: 100vh; overflow-y: auto; padding-bottom: var(--space-4); scrollbar-width: thin; }\n.tree .label + .toc, .tree .label + .tree-group, .tree .label + .tree-row { margin-top: 0; }\n.toc { margin-bottom: var(--space-4); border-left: 1px solid var(--line); margin-left: var(--space-2); }\n.tree-row { display: flex; align-items: center; gap: 6px; padding: 4px var(--space-2); border-radius: var(--radius-sm); color: var(--text); line-height: 1.35; }\na.tree-row { text-decoration: none; }\na.tree-row:hover, summary.tree-row:hover { background: var(--bg-raised); color: var(--text-strong); text-decoration: none; }\n.tree-row.child { padding-left: calc(var(--space-2) + 18px); color: var(--text-muted); }\n.tree-row.child.is-link { color: var(--text); }\n.tree-row.is-current { background: var(--bg-raised); color: var(--text-strong); box-shadow: inset 2px 0 0 var(--accent); }\n.tree-row > span:first-child { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.tree-row .ext { flex: 0 0 auto; font-size: 11px; color: var(--text-muted); opacity: 0; transition: opacity .15s; }\n.tree-row:hover .ext, .tree-row:focus-visible .ext { opacity: 1; }\n.tree-row .count { flex: 0 0 auto; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); font-variant-numeric: tabular-nums; }\n.tree-row:focus-visible { outline: 2px solid var(--accent); outline-offset: -2px; }\n.toc-row { margin-left: -1px; border-left: 2px solid transparent; border-radius: 0 var(--radius-sm) var(--radius-sm) 0; color: var(--text-muted); padding-left: var(--space-3); }\n.toc-row.is-active { color: var(--text-strong); border-left-color: var(--accent); background: var(--accent-soft); }\n.tree-group > summary { list-style: none; cursor: pointer; user-select: none; }\n.tree-group > summary::-webkit-details-marker { display: none; }\n.tree-row.group .g-name { flex: 1; font-weight: 500; }\n.tree-row.group .caret { flex: 0 0 12px; width: 12px; height: 12px; display: inline-block; }\n.tree-group > summary .caret::before { content: ""; display: block; width: 0; height: 0; margin: 2px 0 0 2px; border-left: 4px solid transparent; border-right: 4px solid transparent; border-top: 6px solid var(--text-muted); transform: rotate(-90deg); transition: transform .15s; }\n.tree-group[open] > summary .caret::before { transform: none; }\n.tree-row.group.leaf .caret::before { content: ""; display: block; width: 5px; height: 5px; margin: 3px 0 0 3px; border-radius: 50%; background: var(--line-strong); }\nhtml { scroll-behavior: smooth; } h2[id], section[id], .pnote[id] { scroll-margin-top: var(--space-4); }\n@media (prefers-reduced-motion: reduce) { html { scroll-behavior: auto; } }\n@media (max-width: 900px) {\n  .sidebar.tree { display: block; flex-basis: 100%; min-width: 0; position: sticky; top: 0; z-index: 5; padding: 0; border-right: 0; border-bottom: 1px solid var(--line); }\n  .side-inner { position: static; max-height: none; overflow: visible; padding: 0; }\n  .side-inner > .label, .side-inner > .tree-group, .side-inner > .tree-row { display: none; }\n  .toc { display: flex; overflow-x: auto; gap: 2px; margin: 0; border: 0; padding: 6px var(--space-3); scrollbar-width: none; }\n  .toc-row { white-space: nowrap; border: 0; border-radius: var(--radius-round); padding: 4px 12px; margin: 0; }\n  .side-inner:not(:has(.toc)) { display: none; }\n}\n\n/* --- Banner & title ---------------------------------------------------- */\n.banner { position: relative; height: var(--banner-height); }   /* no overflow:hidden, so the avatar can hang below */\n.banner::after { z-index: 1; }\n.banner img.cover { width: 100%; height: 100%; object-fit: cover; object-position: var(--banner-focus); opacity: .92; display: block; }\n.banner::after { content: ""; position: absolute; inset: 0; background: linear-gradient(180deg, transparent 40%, var(--bg) 100%); }\n.banner img.avatar {\n  position: absolute; left: 48px; bottom: calc(var(--avatar-size) * -0.32); z-index: 2;\n  width: var(--avatar-size); height: var(--avatar-size); border-radius: 50%;\n  object-fit: cover; object-position: center 25%; border: 4px solid var(--bg);\n}\n.page { max-width: var(--content-width); margin: 0 auto; padding: calc(var(--space-8) + var(--space-4)) var(--space-8) 0; }\n.crumb { font-family: var(--font-mono); font-size: 12px; color: var(--text-muted); }\nh1.title { margin: 6px 0 var(--space-4); font-family: var(--font-display); font-weight: 600; font-size: var(--text-h1); color: var(--text-strong); line-height: 1.1; }\nh1.title .caret { color: var(--accent); animation: blink 1s step-end infinite; }\nh2 { font-family: var(--font-display); font-weight: 600; font-size: var(--text-h2); color: var(--text-strong); margin: var(--space-8) 0 var(--space-2); }\n\n/* --- Properties -------------------------------------------------------- */\n.props {\n  display: grid; grid-template-columns: 150px 1fr; gap: 6px 14px;\n  border-top: 1px solid var(--line); border-bottom: 1px solid var(--line);\n  padding: 10px 0; margin-bottom: var(--space-6); font-size: var(--text-sm);\n}\n.props dt { font-family: var(--font-mono); font-size: 12.5px; color: var(--text-muted); margin: 0; }\n.props dd { margin: 0; }\n@media (max-width: 560px) { .props { grid-template-columns: 1fr; } .props dd { margin-bottom: 6px; } }\n\n/* --- Callout ----------------------------------------------------------- */\n.callout { border-left: 3px solid var(--accent); background: var(--accent-soft); border-radius: 0 var(--radius-md) var(--radius-md) 0; padding: 12px 16px; margin-bottom: var(--space-6); }\n.callout-title { font-weight: 600; color: var(--accent-text); font-size: var(--text-sm); }\n\n/* --- Lists, tables ----------------------------------------------------- */\nul.bullets { margin: 0; padding-left: 20px; }\nul.bullets li { margin: 4px 0; }\n.query { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); margin-bottom: 6px; }\n.table-wrap { overflow-x: auto; }\ntable.data { width: 100%; border-collapse: collapse; font-size: 14px; }\ntable.data th { text-align: left; padding: 8px; border-bottom: 1px solid var(--line-strong); color: var(--text-muted); font-weight: 500; }\ntable.data td { padding: 8px; border-bottom: 1px solid var(--line); }\ntable.data .num { text-align: right; font-family: var(--font-mono); }\n\n/* --- Commit chart ------------------------------------------------------ */\n.bars { height: 110px; display: flex; gap: 3px; align-items: flex-end; border-bottom: 1px solid var(--line-strong); }\n.bars span { flex: 1; background: var(--chart-bar); border-radius: 2px 2px 0 0; transform-origin: bottom; animation: rise 1.1s cubic-bezier(.2,.8,.2,1) both; }\n.bars span.quiet { background: var(--chart-bar-quiet); }\n.bars-legend { display: flex; justify-content: space-between; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); margin-top: 4px; }\n\n/* --- Timeline ---------------------------------------------------------- */\n.timeline { position: relative; }\n.timeline .row { display: grid; grid-template-columns: 64px 14px 1fr; gap: 0 12px; padding: 7px 0; position: relative; }\n.timeline .row::before { content: ""; position: absolute; left: calc(64px + 12px + 6px); top: 0; bottom: 0; width: 2px; background: var(--line); }\n.timeline .year { font-family: var(--font-mono); font-size: var(--text-sm); color: var(--text-muted); padding-top: 2px; font-variant-numeric: tabular-nums; }\n.timeline .dot { position: relative; z-index: 1; width: 10px; height: 10px; margin: 7px 0 0 2px; border-radius: 50%; background: var(--bg); border: 2px solid var(--accent); }\n.timeline .row.same .dot { width: 6px; height: 6px; margin: 9px 0 0 4px; border: 0; background: var(--line-strong); }\n.timeline .what { min-width: 0; }\n.timeline .detail { color: var(--text-muted); font-size: var(--text-sm); margin-top: 2px; }\n.timeline .era { display: flex; align-items: baseline; gap: 10px; margin: var(--space-4) 0 2px; padding-left: calc(64px + 12px + 14px + 12px); }\n.timeline .era:first-child { margin-top: 0; }\n.timeline .era-name { font-family: var(--font-mono); font-size: var(--text-xs); letter-spacing: .06em; text-transform: uppercase; color: var(--accent-text); }\n.timeline .era-range { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n@media (max-width: 560px) { .timeline .row { grid-template-columns: 44px 14px 1fr; gap: 0 8px; } .timeline .row::before { left: calc(44px + 8px + 6px); } .timeline .era { padding-left: calc(44px + 8px + 14px + 8px); } }\n\n/* --- Right rail -------------------------------------------------------- */\n.graph svg { width: 100%; height: 240px; display: block; }\n.graph .edge { stroke: var(--graph-edge); stroke-width: 1; }\n.graph .node { fill: var(--graph-node); }\n.graph .node.hot { fill: var(--graph-node-hot); }\n.graph .center { fill: var(--accent); }\n.graph text { fill: var(--text-muted); font-family: var(--font-body); font-size: 8.5px; }\n.graph .float { animation: float 4s ease-in-out infinite; }\n.backlink { padding: 6px 0; border-bottom: 1px solid var(--line); font-size: var(--text-sm); }\n.backlink .ctx { color: var(--text-muted); font-size: 12px; }\n.pulse-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: var(--space-2); }\n.pulse-cell { background: var(--bg-raised); border-radius: var(--radius-sm); padding: var(--space-2); }\n.pulse-cell .v { font-size: 20px; color: var(--text-strong); }\n.pulse-cell .l { font-size: var(--text-xs); color: var(--text-muted); }\n\n/* --- Help exchange (off by default in config) -------------------------- */\n.hx-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: var(--space-3); }\n.hx-card { background: var(--bg-raised); border: 1px solid var(--line); border-radius: var(--radius-md); padding: var(--space-4); }\n.hx-row { display: flex; justify-content: space-between; gap: var(--space-2); padding: 6px 0; border-bottom: 1px solid var(--line); font-size: var(--text-sm); }\n.hx-row .bounty { color: var(--accent-2); font-family: var(--font-mono); }\n\n\n/* --- Stat strip -------------------------------------------------------- */\n.stat-strip { display: grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr)); gap: 1px; background: var(--line); border: 1px solid var(--line); border-radius: var(--radius-md); overflow: hidden; margin-bottom: var(--space-6); }\n.stat { background: var(--bg); padding: var(--space-3) var(--space-2); }\n.stat .v { font-size: 22px; color: var(--text-strong); font-variant-numeric: tabular-nums; }\n.stat .l { font-size: var(--text-xs); color: var(--text-muted); }\n.small { font-size: var(--text-sm); margin: 0 0 var(--space-2); }\n\n/* --- Activity heatmap -------------------------------------------------- */\n.heat-box { position: relative; }\n.heat-frame { display: flex; gap: 6px; }\n.heat-days { display: grid; grid-template-rows: repeat(7, 12px); gap: 3px; padding-top: 18px; font-family: var(--font-mono); font-size: 10px; line-height: 12px; color: var(--text-muted); }\n.heat-wrap { overflow-x: auto; min-width: 0; }\n.heat-months { position: relative; height: 18px; font-family: var(--font-mono); font-size: 10px; color: var(--text-muted); }\n.heat-months span { position: absolute; top: 0; white-space: nowrap; }\n.heat { outline: none; border-radius: 3px; width: max-content; }\n.heat:focus-visible { box-shadow: 0 0 0 2px var(--accent); }\n.heat i[data-d] { cursor: pointer; transition: transform .12s ease; }\n.heat i[data-d]:hover, .heat i.is-sel { transform: scale(1.25); box-shadow: 0 0 0 1.5px var(--text-strong); position: relative; z-index: 1; }\n.heat i.is-today { box-shadow: inset 0 0 0 1.5px var(--accent-2); }\n.heat i.is-pin { box-shadow: 0 0 0 1.5px var(--accent); }\n.heat-tip { position: absolute; z-index: 5; transform: translate(-50%, calc(-100% - 8px)); pointer-events: none; white-space: nowrap; background: var(--text-strong); color: var(--bg); font-size: var(--text-xs); font-family: var(--font-mono); padding: 4px 8px; border-radius: var(--radius-sm); box-shadow: 0 4px 14px rgba(0,0,0,.25); }\n.heat-tip::after { content: ""; position: absolute; left: calc(50% + var(--ax, 0px)); bottom: -4px; margin-left: -4px; border: 4px solid transparent; border-bottom: 0; border-top-color: var(--text-strong); }\n.heat-foot { display: flex; flex-wrap: wrap; gap: 6px 16px; justify-content: space-between; align-items: center; margin-top: 8px; }\n.heat-read { font-size: var(--text-sm); color: var(--text-muted); min-height: 1.4em; font-variant-numeric: tabular-nums; }\n.heat-read b { color: var(--text-strong); font-weight: 500; }\n.heat-foot .heat-legend { margin-top: 0; }\n@media (prefers-reduced-motion: reduce) { .heat i[data-d] { transition: none; } }\n.heat { display: grid; grid-template-rows: repeat(7, 12px); grid-auto-flow: column; grid-auto-columns: 12px; gap: 3px; }\n.heat i, .heat-legend i { width: 12px; height: 12px; border-radius: 2px; display: block; background: var(--heat-0); }\n.heat i.l1, .heat-legend i.l1 { background: var(--heat-1); }\n.heat i.l2, .heat-legend i.l2 { background: var(--heat-2); }\n.heat i.l3, .heat-legend i.l3 { background: var(--heat-3); }\n.heat i.l4, .heat-legend i.l4 { background: var(--heat-4); }\n.heat-legend { display: flex; gap: 4px; align-items: center; justify-content: flex-end; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); margin-top: 6px; }\n\n/* --- Two columns, growth line, horizontal bars ------------------------- */\n.two-col { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: var(--space-6); }\n.growth { width: 100%; height: auto; display: block; }\n.growth .axis { stroke: var(--line-strong); }\n.growth .area { fill: var(--accent-soft); }\n.growth .line { fill: none; stroke: var(--accent); stroke-width: 2.5; stroke-linejoin: round; stroke-dasharray: 2000; animation: draw 2.6s ease-out both; }\n.growth .now { fill: var(--accent); animation: pulse 2s ease-in-out infinite; }\n.growth text { fill: var(--text-muted); font-family: var(--font-mono); font-size: 11px; }\n.hbar { display: grid; grid-template-columns: 130px 1fr 52px; gap: 10px; align-items: center; font-size: var(--text-sm); padding: 4px 0; }\n.hbar .track { height: 8px; background: var(--bg-raised); border-radius: 4px; overflow: hidden; }\n.hbar .fill { display: block; height: 100%; background: var(--accent); border-radius: 4px; transform-origin: left; animation: grow 1.2s cubic-bezier(.2,.8,.2,1) both; }\n.hbar .fill.alt { background: var(--chart-alt); }\n.hbar .num { text-align: right; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n.cols { height: 120px; display: flex; gap: 4px; align-items: flex-end; border-bottom: 1px solid var(--line-strong); margin-top: var(--space-2); }\n.cols span { flex: 1; height: 100%; display: flex; flex-direction: column-reverse; align-items: center; }\n.cols b { display: block; width: 100%; background: var(--chart-alt); border-radius: 2px 2px 0 0; transform-origin: bottom; animation: rise 1s cubic-bezier(.2,.8,.2,1) both; }\n.cols em { font-style: normal; font-family: var(--font-mono); font-size: 10px; color: var(--text-muted); }\n\n/* --- Topic cloud ------------------------------------------------------- */\n.cloud { display: flex; flex-wrap: wrap; gap: 6px 16px; align-items: baseline; }\n.cloud span { color: var(--text-strong); line-height: 1.3; }\n.cloud sup { font-family: var(--font-mono); font-size: 10px; color: var(--text-muted); margin-left: 2px; }\n\n@keyframes draw { from { stroke-dashoffset: 2000; } to { stroke-dashoffset: 0; } }\n@keyframes grow { from { transform: scaleX(0); } to { transform: scaleX(1); } }\n\n\n/* --- Daily journal ----------------------------------------------------- */\n.journal { background: var(--bg-raised); border: 1px solid var(--line); border-radius: var(--radius-lg); padding: var(--space-4); margin-bottom: var(--space-6); overflow: hidden; }\n.j-head { display: flex; align-items: center; gap: var(--space-3); margin-bottom: var(--space-3); }\n.j-title { flex: 1; text-align: center; }\n.j-date { font-family: var(--font-display); font-size: 22px; color: var(--text-strong); }\n.j-nav { width: 44px; height: 44px; border-radius: 50%; border: 1px solid var(--line-strong); background: var(--bg); color: var(--text); font-size: 22px; cursor: pointer; }\n.j-nav:disabled { opacity: .3; cursor: default; }\n.j-top { display: flex; flex-wrap: wrap; gap: var(--space-4); align-items: center; }\n.ring-wrap { position: relative; width: 96px; height: 96px; flex: 0 0 96px; }\n.ring { width: 96px; height: 96px; transform: rotate(-90deg); display: block; }\n.ring .trk { fill: none; stroke: var(--line); stroke-width: 9; }\n.ring .val { fill: none; stroke: var(--accent); stroke-width: 9; stroke-linecap: round; transition: stroke-dashoffset .8s cubic-bezier(.2,.8,.2,1); }\n.j-score { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; }\n.j-score .v { font-size: 26px; color: var(--text-strong); line-height: 1; }\n.j-score .l { font-size: 10px; color: var(--text-muted); }\n.j-delta { font-family: var(--font-mono); font-size: var(--text-xs); margin-bottom: 4px; }\n.j-headline { flex: 1 1 260px; font-family: var(--font-display); font-size: 21px; color: var(--text-strong); line-height: 1.3; }\n.j-themes { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 8px; font-family: var(--font-body); }\n.j-themes span { font-size: var(--text-xs); color: var(--accent-text); background: var(--accent-soft); border-radius: var(--radius-round); padding: 2px 10px; }\n.j-chips { display: grid; grid-template-columns: repeat(auto-fit, minmax(96px, 1fr)); gap: 1px; background: var(--line); border: 1px solid var(--line); border-radius: var(--radius-md); overflow: hidden; margin: var(--space-4) 0; }\n.chip { background: var(--bg); padding: var(--space-2); }\n.chip .v { font-size: 20px; color: var(--text-strong); font-variant-numeric: tabular-nums; }\n.chip .l { font-size: var(--text-xs); color: var(--text-muted); }\n.chip .dd { font-family: var(--font-mono); font-size: var(--text-xs); min-height: 1em; }\n.up { color: var(--accent-2); } .down { color: var(--text-muted); } .flat { color: var(--text-muted); }\n.j-lists ul { margin-top: 4px; }\n.flip-l { animation: flipL .45s ease both; } .flip-r { animation: flipR .45s ease both; }\n@keyframes flipL { from { opacity: 0; transform: translateX(-24px) rotateY(8deg); } to { opacity: 1; transform: none; } }\n@keyframes flipR { from { opacity: 0; transform: translateX(24px) rotateY(-8deg); } to { opacity: 1; transform: none; } }\n\n/* --- Scoreboard -------------------------------------------------------- */\n.scoreboard { margin-bottom: var(--space-6); }\n.sb-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: var(--space-3); margin-bottom: var(--space-3); }\n.sb-stat .v { font-size: 30px; color: var(--text-strong); line-height: 1.1; }\n.sb-stat .v small { font-size: 14px; color: var(--text-muted); }\n.sb-stat .l { font-size: var(--text-xs); color: var(--text-muted); }\n.sb-bars { height: 90px; display: flex; gap: 3px; align-items: flex-end; border-bottom: 1px solid var(--line-strong); }\n.sb-bars span { flex: 1; background: var(--chart-bar-quiet); border-radius: 2px 2px 0 0; transform-origin: bottom; animation: rise 1s cubic-bezier(.2,.8,.2,1) both; }\n.sb-bars span.yday { background: var(--accent); }\n.sb-bars span.today { background: repeating-linear-gradient(45deg, var(--chart-bar-quiet), var(--chart-bar-quiet) 3px, transparent 3px, transparent 6px); }\n.sb-lower { margin-top: var(--space-4); }\n.lb-row { display: grid; grid-template-columns: 26px 1fr auto; gap: 10px; align-items: center; padding: 7px 0; border-bottom: 1px solid var(--line); font-size: var(--text-sm); }\n.lb-row .rank { font-family: var(--font-mono); color: var(--text-muted); }\n.lb-row .num { font-family: var(--font-mono); }\n.lb-row.me .who { color: var(--text-strong); font-weight: 600; }\n.lb-row.empty .who { color: var(--text-muted); border: 1px dashed var(--line-strong); border-radius: var(--radius-sm); padding: 2px 8px; justify-self: start; }\n.sb-how { margin-top: var(--space-3); font-size: var(--text-sm); color: var(--text-muted); }\n.sb-how summary { cursor: pointer; color: var(--accent-text); }\n\n/* --- Footer ------------------------------------------------------------ */\n.foot { margin-top: var(--space-8); padding-top: var(--space-3); border-top: 1px solid var(--line); font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n\n/* --- Motion (respects reduced-motion) ---------------------------------- */\n@keyframes pulse { 0%,100% { opacity: .35; } 50% { opacity: 1; } }\n@keyframes blink { 50% { opacity: 0; } }\n@keyframes rise { from { transform: scaleY(0); } to { transform: scaleY(1); } }\n@keyframes float { 0%,100% { transform: translate(0,0); } 50% { transform: translate(3px,-4px); } }\n@media (prefers-reduced-motion: reduce) { * { animation: none !important; } }\n\n.note { max-width: 100%; }\n.lede { font-size: var(--text-lg); color: var(--text-muted); margin: -8px 0 var(--space-6); }\n.pnote { padding: var(--space-3) 0; border-bottom: 1px solid var(--line); }\n.pn-title { font-family: var(--font-display); font-size: 19px; color: var(--text-strong); }\n.pn-ex { color: var(--text); font-size: var(--text-sm); }\n.pn-date { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n\n.lb-wrap { position: relative; }\n.lb-row.empty .invite-btn { font: inherit; font-size: var(--text-sm); cursor: pointer; background: transparent; color: var(--accent-text); border: 1px dashed var(--accent); border-radius: var(--radius-sm); padding: 2px 10px; justify-self: start; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; }\n.lb-row.empty .invite-btn::before { content: "+"; font-family: var(--font-mono); }\n.lb-row.empty .invite-btn:hover, .lb-row.empty .invite-btn[aria-expanded="true"] { background: var(--accent-soft); border-style: solid; text-decoration: none; }\n.lb-row.empty .invite-btn:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }\n.invite-pop { position: absolute; z-index: 20; width: min(340px, 100%); background: var(--bg-raised); border: 1px solid var(--line-strong); border-radius: var(--radius-md); padding: 14px; box-shadow: 0 12px 32px rgba(0,0,0,.35); }\n.invite-pop .inv-head { display: flex; justify-content: space-between; align-items: start; gap: 8px; }\n.invite-pop .inv-title { font-weight: 600; color: var(--text-strong); font-size: var(--text-sm); }\n.invite-pop .inv-sub { color: var(--text-muted); font-size: var(--text-xs); margin: 2px 0 10px; line-height: 1.45; }\n.invite-pop .inv-close { background: none; border: 0; color: var(--text-muted); font-size: 18px; line-height: 1; cursor: pointer; padding: 0 2px; }\n.invite-pop .inv-link { display: flex; gap: 6px; }\n.invite-pop .inv-url { flex: 1; min-width: 0; font-family: var(--font-mono); font-size: 12px; color: var(--text); background: var(--bg); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 6px 8px; }\n.invite-pop button.inv-copy { background: var(--accent); color: var(--bg); border: 0; border-radius: var(--radius-sm); padding: 6px 12px; font: inherit; font-size: var(--text-sm); font-weight: 600; cursor: pointer; }\n.invite-pop .inv-ways { display: flex; gap: 6px; margin-top: 8px; }\n.invite-pop .inv-ways a, .invite-pop .inv-ways button { flex: 1; text-align: center; font: inherit; font-size: var(--text-sm); color: var(--text); background: var(--bg); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 6px 0; cursor: pointer; text-decoration: none; }\n.invite-pop .inv-ways a:hover, .invite-pop .inv-ways button:hover { border-color: var(--accent); color: var(--text-strong); text-decoration: none; }\n.invite-pop .inv-status { min-height: 1.2em; margin-top: 6px; font-size: var(--text-xs); color: var(--accent-2); }\n.invite-pop button:focus-visible, .invite-pop a:focus-visible, .invite-pop input:focus-visible { outline: 2px solid var(--accent); outline-offset: 1px; }\n\n/* Heatmap sizing (2026-10-12): cells grow with the column (11-18px), room for the hover zoom, no stray scrollbar */\n.heat-box { container-type: inline-size; }\n.heat-frame { --gap: 3px; --cell: clamp(8px, calc((100cqw - 46px - 25 * var(--gap)) / 26), 18px); }\n@container (max-width: 460px) { .heat-frame { --gap: 2px; } }\n.heat, .heat-days { gap: var(--gap, 3px); }\n.heat-days { grid-template-rows: repeat(7, var(--cell, 12px)); line-height: var(--cell, 12px); }\n.heat-wrap { overflow-x: auto; overflow-y: hidden; padding: 4px; margin: -4px; scrollbar-width: none; }\n.heat-wrap::-webkit-scrollbar { display: none; }\n.heat { grid-template-rows: repeat(7, var(--cell, 12px)); grid-auto-columns: var(--cell, 12px); }\n.heat i { width: var(--cell, 12px); height: var(--cell, 12px); border-radius: 3px; }\n.heat i[data-d]:hover, .heat i.is-sel { transform: scale(1.18); }\n\n/* --- Standard nav: pages block + add-friend --------------------------- */\n.toc.pages .friend-row { color: var(--accent); }\n.toc.pages .friend-row:hover { color: var(--accent); background: var(--accent-soft); }\n.tree-row.group .g-link { color: inherit; text-decoration: none; }\n.tree-row.group .g-link:hover { color: var(--accent); text-decoration: underline; }\n';

// src/garden.ts
var STAGES = ["seedling", "budding", "evergreen"];
var LICENSES = {
  "all-rights": { label: "All rights reserved. Not licensed for AI training.", short: "All rights reserved", ai: false },
  "cc-by": { label: "Creative Commons Attribution 4.0. Reuse with credit.", short: "CC BY 4.0", ai: true, url: "https://creativecommons.org/licenses/by/4.0/" },
  "cc-by-nc": { label: "Creative Commons Attribution-NonCommercial 4.0. Reuse with credit, not commercially.", short: "CC BY-NC 4.0", ai: false, url: "https://creativecommons.org/licenses/by-nc/4.0/" },
  "cc0": { label: "Public domain (CC0). No rights reserved.", short: "CC0", ai: true, url: "https://creativecommons.org/publicdomain/zero/1.0/" },
  "ai-licensable": { label: "Available to license for AI training, with the author's permission and payment. Not free to use.", short: "AI-licensable", ai: false }
};
var STAGE_ICON = { seedling: "&#127793;", budding: "&#127807;", evergreen: "&#127795;" };
var STAGE_TIP = { seedling: "Seedling: a rough, early idea", budding: "Budding: taking shape", evergreen: "Evergreen: worked through and stable" };
var normStage = (v) => {
  const s = String(v ?? "").toLowerCase().trim();
  return STAGES.includes(s) ? s : "seedling";
};
var normLicense = (v) => {
  const s = String(v ?? "").toLowerCase().trim();
  return LICENSES[s] ? s : "all-rights";
};
function redact(md) {
  let removed = 0;
  const text = md.replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, () => {
    removed++;
    return "[email removed]";
  }).replace(/(?<![\w/.=-])(\+?\d[\d .()-]{8,}\d)(?![\w/])/g, (m) => {
    if ((m.match(/\d/g) || []).length < 10) return m;
    removed++;
    return "[phone removed]";
  });
  return { text, removed };
}
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
function parseXLink(target) {
  const m = target.match(/^@([a-z0-9][a-z0-9-]{1,30})\/(.+)$/i);
  return m ? { handle: m[1].toLowerCase(), title: m[2].trim(), slug: slug(m[2]) } : null;
}
function mdToHtml(md, link, image = () => null) {
  const lines = md.replace(/\r\n?/g, "\n").split("\n");
  const out = [];
  let para = [];
  let list = null;
  let quote = [];
  const flushPara = () => {
    if (para.length) {
      out.push(`<p>${inl(para.join(" "))}</p>`);
      para = [];
    }
  };
  const flushList = () => {
    if (list) {
      out.push(`<${list.tag}>${list.items.map((i) => `<li>${i}</li>`).join("")}</${list.tag}>`);
      list = null;
    }
  };
  const flushQuote = () => {
    if (quote.length) {
      out.push(`<blockquote>${mdToHtml(quote.join("\n"), link, image)}</blockquote>`);
      quote = [];
    }
  };
  const flush = () => {
    flushPara();
    flushList();
    flushQuote();
  };
  function inl(t) {
    const tokens = [];
    const keep = (html) => {
      tokens.push(html);
      return `\uE000${tokens.length - 1}\uE000`;
    };
    t = t.replace(/`([^`]+)`/g, (_m, c) => keep(`<code>${esc(c)}</code>`));
    t = t.replace(/!\[\[([^\]|]+)(\|[^\]]*)?\]\]/g, (_m, tgt) => {
      const src = image(tgt.trim());
      return src ? keep(`<img src="${esc(src)}" alt="${esc(tgt.trim())}" loading="lazy">`) : "";
    });
    t = t.replace(/\[\[([^\]|#]+)(#[^\]|]*)?(\|([^\]]+))?\]\]/g, (_m, tgt, _h, _p, label) => {
      const text = (label || tgt).trim(), x = parseXLink(tgt.trim());
      const href = link(tgt.trim());
      if (href) return keep(`<a class="${x ? "xlink" : "internal"}" href="${esc(href)}">${esc(text.replace(/^@[^/]+\//, ""))}${x ? `<span class="xl-who">@${esc(x.handle)}</span>` : ""}</a>`);
      return keep(`<span class="unlinked">${esc(text)}</span>`);
    });
    t = t.replace(/!\[([^\]]*)\]\((https:\/\/[^)\s]+)\)/g, (_m, alt, u) => keep(`<a href="${esc(u)}" rel="noopener nofollow" target="_blank">${esc(alt || "image")}</a>`));
    t = t.replace(/\[([^\]]+)\]\(((?:https?:\/\/|mailto:)[^)\s]+)\)/g, (_m, label, u) => keep(`<a href="${esc(u)}" rel="noopener nofollow" target="_blank">${esc(label)}</a>`));
    t = t.replace(/(^|[\s(])(https?:\/\/[^\s)<]+)/g, (_m, pre, u) => pre + keep(`<a href="${esc(u)}" rel="noopener nofollow" target="_blank">${esc(u)}</a>`));
    let h = esc(t);
    h = h.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>").replace(/__([^_]+)__/g, "<strong>$1</strong>").replace(/(^|[^*\w])\*([^*\s][^*]*)\*/g, "$1<em>$2</em>").replace(/(^|[^_\w])_([^_\s][^_]*)_/g, "$1<em>$2</em>").replace(/~~([^~]+)~~/g, "<del>$1</del>").replace(/==([^=]+)==/g, "<mark>$1</mark>");
    return h.replace(/\uE000(\d+)\uE000/g, (_m, i) => tokens[Number(i)]);
  }
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const fence = line.match(/^\s*(```|~~~)(.*)$/);
    if (fence) {
      flush();
      const body = [];
      for (i++; i < lines.length && !lines[i].trim().startsWith(fence[1]); i++) body.push(lines[i]);
      out.push(`<pre><code>${esc(body.join("\n"))}</code></pre>`);
      continue;
    }
    if (/^\s*%%/.test(line)) {
      flush();
      if (!/%%.*%%/.test(line)) for (i++; i < lines.length && !lines[i].includes("%%"); i++) ;
      continue;
    }
    const q2 = line.match(/^\s*>\s?(.*)$/);
    if (q2) {
      flushPara();
      flushList();
      quote.push(q2[1].replace(/^\[!(\w+)\][+-]?\s*/, (_m, k) => `**${k.charAt(0).toUpperCase() + k.slice(1)}:** `));
      continue;
    } else flushQuote();
    const h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      flush();
      const lvl = Math.min(6, h[1].length + 1);
      out.push(`<h${lvl}>${inl(h[2])}</h${lvl}>`);
      continue;
    }
    if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) {
      flush();
      out.push("<hr>");
      continue;
    }
    const li = line.match(/^\s*([-*+]|\d+[.)])\s+(\[( |x|X)\]\s+)?(.*)$/);
    if (li) {
      flushPara();
      const tag = /\d/.test(li[1]) ? "ol" : "ul";
      if (!list || list.tag !== tag) {
        flushList();
        list = { tag, items: [] };
      }
      const box = li[2] ? `<input type="checkbox" disabled${/x/i.test(li[3]) ? " checked" : ""}> ` : "";
      list.items.push(box + inl(li[4]));
      continue;
    }
    if (!line.trim()) {
      flush();
      continue;
    }
    flushList();
    para.push(line.trim());
  }
  flush();
  return out.join("\n");
}
function excerptOf(md, n = 200) {
  const para = md.replace(/```[\s\S]*?```/g, "").split(/\n\s*\n/).map((x) => x.replace(/^#+\s.*$/gm, "").replace(/^\s*>\s?/gm, "").trim()).find((x) => x.length > 20) || "";
  return clip(para.replace(/!\[\[[^\]]*\]\]/g, "").replace(/\[\[(?:@[^/\]]+\/)?([^\]|]+)(\|([^\]]+))?\]\]/g, (_m, t, _p, l) => l || t).replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/[*_`=~]/g, "").replace(/\s+/g, " ").trim(), n);
}
function page(site, title, body, depth, extraHead = "") {
  const up = depth ? "../".repeat(depth) : "";
  const icon = site.icon ? `<link rel="icon" href="${up}${esc(site.icon)}" type="image/png">` : `<link rel="icon" href="${up}assets/favicon.svg" type="image/svg+xml">`;
  return `<!doctype html><html lang="en"${site.theme === "light" ? ' data-theme="light"' : ""}><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(title)}</title>
<meta name="robots" content="noindex, nofollow"><meta name="generator" content="Caldera for Obsidian">${extraHead}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400&display=swap">
${icon}<link rel="stylesheet" href="${up}assets/theme.css"><link rel="stylesheet" href="${up}assets/profile.css"><link rel="stylesheet" href="${up}assets/garden.css"></head><body>
${body}</body></html>`;
}
var clip = (t, n) => t.length <= n ? t : t.slice(0, n).replace(/\s+\S*$/, "").replace(/[,;:.\s]+$/, "") + "\u2026";
var fmtDate = (iso2) => new Date(iso2).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
var stageBadge = (s) => `<span class="g-stage g-${s}" title="${STAGE_TIP[s]}">${STAGE_ICON[s]} ${s}</span>`;
var licenseLine = (key) => {
  const L = LICENSES[key] || LICENSES["all-rights"];
  return L.url ? `<a href="${L.url}" rel="license noopener" target="_blank">${esc(L.short)}</a>` : esc(L.short);
};
function renderGarden(site, notes, images = {}) {
  if (!notes.length) return {};
  const hub = (site.hub || "https://caldera.social").replace(/\/$/, "");
  const bySlug = new Map(notes.map((n) => [n.slug, n]));
  const byTitle = new Map(notes.map((n) => [n.title.toLowerCase(), n]));
  const back = /* @__PURE__ */ new Map();
  for (const n of notes) for (const o of n.out) if (o !== n.slug && bySlug.has(o)) back.set(o, [...back.get(o) || [], n]);
  const who = site.handle ? `@${site.handle}` : site.name;
  const files = {};
  const tabs = (active) => `<div class="tabs"><a class="tab" href="${active === "index" ? "" : "../"}index.html">${esc(site.name)}.md</a><a class="tab${active === "garden" ? " is-active" : ""}" href="${active === "note" ? "../" : ""}garden.html">Garden</a>${active === "note" ? `<span class="tab is-active">%%TITLE%%</span>` : ""}<span class="spacer"></span></div>`;
  for (const n of notes) {
    const link = (target) => {
      const x = parseXLink(target);
      if (x) return `${hub}/@${x.handle}/n/${x.slug}.html`;
      const hit = byTitle.get(target.split("/").pop().replace(/\.md$/i, "").toLowerCase());
      return hit ? `${hit.slug}.html` : null;
    };
    const img = (target) => images[target] ? `../${images[target]}` : null;
    const body = mdToHtml(n.markdown, link, img);
    const bl = back.get(n.slug) || [];
    const L = LICENSES[n.license] || LICENSES["all-rights"];
    const html = `${tabs("note").replace("%%TITLE%%", esc(n.title))}
<div class="shell">${site.nav ? site.nav(1, `n/${n.slug}.html`) : ""}<main class="note"><div class="g-main"><article class="g-note">
<div class="g-crumbs"><a href="../index.html">${esc(who)}</a> / <a href="../garden.html">Garden</a></div>
<h1 class="g-title">${esc(n.title)}</h1>
<div class="g-meta">${stageBadge(n.stage)}<span>Planted ${fmtDate(n.created)}</span><span>Tended ${fmtDate(n.updated)}</span><span>${n.words.toLocaleString("en-US")} words</span></div>
<div class="g-body">${body}</div>
${bl.length ? `<section class="g-links"><h2>Links to this note</h2>${bl.map((b) => `<a class="g-card" href="${b.slug}.html"><span class="g-card-t">${esc(b.title)}</span><span class="g-card-x">${esc(clip(b.excerpt, 120))}</span></a>`).join("")}</section>` : ""}
<!--caldera:xlinks-->
<footer class="g-foot"><div><b>License:</b> ${licenseLine(n.license)}. ${esc(L.label)}</div>
<div class="g-prov"><b>Provenance:</b> sha256 <code title="${n.sha256}">${n.sha256.slice(0, 16)}</code> of <a href="${n.slug}.md">the published text</a>, listed in <a href="../caldera.json">${esc(who)}'s signed manifest</a>${site.id ? ` (key <code>${esc(site.id.slice(0, 14))}&hellip;</code>)` : ""}. Anyone can check the author and date.</div></footer>
</article></div></main></div>`;
    files[`n/${n.slug}.html`] = page(
      site,
      `${n.title} - ${site.name}`,
      html,
      1,
      `
<meta name="description" content="${esc(n.excerpt)}">${L.ai ? "" : `
<meta name="robots" content="noai, noimageai">`}${L.url ? `
<link rel="license" href="${L.url}">` : ""}`
    );
    files[`n/${n.slug}.md`] = n.markdown;
  }
  const counts = STAGES.map((s) => [s, notes.filter((n) => n.stage === s).length]);
  const sorted = [...notes].sort((a, b) => b.updated.localeCompare(a.updated));
  const idx = `${tabs("garden")}
<div class="shell">${site.nav ? site.nav(0, "garden.html") : ""}<main class="note"><div class="g-main"><div class="g-index">
<div class="g-crumbs"><a href="index.html">${esc(who)}</a> / Garden</div>
<h1 class="g-title">${esc(site.name)}'s garden</h1>
<p class="g-lede">Notes grown in public from an Obsidian vault. Some are seedlings, some are evergreen; all of them keep changing.${site.external ? ` More at <a href="${esc(site.external)}" rel="noopener" target="_blank">${esc(site.external.replace(/^https?:\/\//, "").replace(/\/$/, ""))}</a>.` : ""}</p>
<!--caldera:gardenhome--><div class="g-filter" role="toolbar" aria-label="Filter by stage"><button class="is-on" data-stage="all">All <span>${notes.length}</span></button>${counts.filter(([, c]) => c).map(([s, c]) => `<button data-stage="${s}">${STAGE_ICON[s]} ${s} <span>${c}</span></button>`).join("")}</div>
<div class="g-list">${sorted.map((n) => `<a class="g-card" data-stage="${n.stage}" href="n/${n.slug}.html"><span class="g-card-t">${esc(n.title)}</span><span class="g-card-x">${esc(n.excerpt)}</span><span class="g-card-m">${stageBadge(n.stage)}<span>Tended ${fmtDate(n.updated)}</span>${n.xlinks.length ? `<span>${n.xlinks.length} link${n.xlinks.length === 1 ? "" : "s"} to other gardens</span>` : ""}</span></a>`).join("")}</div>
</div></div></main></div>
<script>(function(){var b=[].slice.call(document.querySelectorAll('.g-filter button')),c=[].slice.call(document.querySelectorAll('.g-list .g-card'));b.forEach(function(x){x.onclick=function(){b.forEach(function(y){y.classList.toggle('is-on',y===x)});var s=x.getAttribute('data-stage');c.forEach(function(k){k.hidden=s!=='all'&&k.getAttribute('data-stage')!==s})}})})();<\/script>`;
  files["garden.html"] = page(site, `${site.name}'s garden`, idx, 0);
  files["garden.json"] = JSON.stringify({
    name: site.name,
    handle: site.handle,
    external: site.external,
    notes: sorted.map((n) => ({ slug: n.slug, title: n.title, stage: n.stage, license: n.license, created: n.created, updated: n.updated, sha256: n.sha256, words: n.words, xlinks: n.xlinks }))
  }, null, 1);
  files["assets/garden.css"] = GARDEN_CSS;
  return files;
}
function gardenManifest(notes) {
  return notes.map((n) => ({
    slug: n.slug,
    title: n.title,
    stage: n.stage,
    license: n.license,
    created: n.created,
    updated: n.updated,
    sha256: n.sha256,
    words: n.words,
    excerpt: n.excerpt.slice(0, 200),
    xlinks: n.xlinks.map((x) => `${x.handle}/${x.slug}`)
  }));
}
function gardenSection(notes, external) {
  if (!notes.length && !external) return "";
  const sorted = [...notes].sort((a, b) => b.updated.localeCompare(a.updated)).slice(0, 6);
  const counts = STAGES.map((s) => [s, notes.filter((n) => n.stage === s).length]).filter(([, c]) => c);
  return `<h2>Garden</h2><p class="small">${notes.length ? `${notes.length} note${notes.length === 1 ? "" : "s"} grown in public: ${counts.map(([s, c]) => `${STAGE_ICON[s]} ${c} ${s}`).join(" &middot; ")}. ` : ""}${notes.length ? `<a href="garden.html">Garden home: notes, gravity, help credits, asks and offers &rarr;</a>` : ""}${external ? ` ${notes.length ? "Also at" : "My garden:"} <a href="${esc(external)}" rel="noopener" target="_blank">${esc(external.replace(/^https?:\/\//, "").replace(/\/$/, ""))}</a>` : ""}</p>${sorted.length ? `<div class="g-list g-list-profile">${sorted.map((n) => `<a class="g-card" href="n/${n.slug}.html"><span class="g-card-t">${esc(n.title)}</span><span class="g-card-x">${esc(clip(n.excerpt, 140))}</span><span class="g-card-m">${stageBadge(n.stage)}<span>Tended ${fmtDate(n.updated)}</span></span></a>`).join("")}</div>` : ""}`;
}
var GARDEN_CSS = `/* Caldera garden: note pages + index. Tokens come from theme.css. */
.tabs a.tab { color: var(--text-muted); text-decoration: none; }
.tabs a.tab:hover { color: var(--text); }
.tree-row.group .g-link { color: inherit; text-decoration: none; }
.tree-row.group .g-link:hover { color: var(--accent); text-decoration: underline; }
.shell > .note > .g-main { width: 100%; }
.g-main { max-width: 760px; margin: 0 auto; padding: 32px 20px 64px; }
.g-crumbs { font-size: var(--text-sm); color: var(--text-muted); margin-bottom: 10px; }
.g-crumbs a { color: var(--text-muted); }
.g-title { font-family: var(--font-display); font-size: 2.1rem; line-height: 1.15; font-weight: 600; margin: 0 0 12px; color: var(--text-strong); }
.g-lede { color: var(--text-muted); margin: 0 0 18px; }
.g-meta { display: flex; flex-wrap: wrap; gap: 8px 16px; align-items: center; font-size: var(--text-sm); color: var(--text-muted); padding-bottom: 18px; border-bottom: 1px solid var(--line); margin-bottom: 22px; }
.g-stage { display: inline-flex; align-items: center; gap: 5px; padding: 2px 10px; border-radius: 999px; border: 1px solid var(--line-strong); font-size: var(--text-xs); text-transform: capitalize; color: var(--text); background: var(--bg-raised); white-space: nowrap; }
.g-evergreen { border-color: var(--accent); }
.g-body { font-family: var(--font-display); font-size: 1.12rem; line-height: 1.7; color: var(--text); overflow-wrap: anywhere; }
.g-body h2, .g-body h3, .g-body h4 { font-family: var(--font-display); color: var(--text-strong); margin: 1.6em 0 .5em; line-height: 1.25; }
.g-body p, .g-body ul, .g-body ol, .g-body blockquote, .g-body pre { margin: 0 0 1em; }
.g-body ul, .g-body ol { padding-left: 1.3em; }
.g-body blockquote { border-left: 3px solid var(--accent); padding: 2px 0 2px 16px; color: var(--text-muted); }
.g-body code { font-family: var(--font-mono); font-size: .85em; background: var(--bg-sunken); padding: 1px 5px; border-radius: 4px; }
.g-body pre { background: var(--bg-sunken); padding: 14px; border-radius: var(--radius-md); overflow-x: auto; }
.g-body pre code { background: none; padding: 0; }
.g-body img { max-width: 100%; height: auto; border-radius: var(--radius-md); }
.g-body a.internal { border-bottom: 1px dashed var(--accent-text); text-decoration: none; }
.g-body a.xlink { border-bottom: 1px dashed var(--accent-text); text-decoration: none; }
.g-body .xl-who { font-family: var(--font-body); font-size: .7em; margin-left: 4px; padding: 0 6px; border-radius: 999px; background: var(--accent-soft); color: var(--accent-text); vertical-align: 2px; }
.g-body .unlinked { color: var(--text); }
.g-body mark { background: var(--accent-soft); color: inherit; }
.g-body hr { border: 0; border-top: 1px solid var(--line); margin: 2em 0; }
.g-links, .g-xlinks { margin-top: 36px; }
.g-links h2, .g-xlinks h2 { font-size: var(--text-sm); text-transform: uppercase; letter-spacing: .06em; color: var(--text-muted); font-weight: 600; margin: 0 0 10px; }
.g-list { display: grid; gap: 10px; }
.g-list-profile { grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); margin-bottom: 8px; }
.g-card { display: flex; flex-direction: column; gap: 6px; padding: 14px 16px; border: 1px solid var(--line); border-radius: var(--radius-md); background: var(--bg-raised); color: var(--text); text-decoration: none; }
.g-card:hover { border-color: var(--accent); text-decoration: none; }
.g-card-t { font-family: var(--font-display); font-weight: 600; font-size: 1.05rem; color: var(--text-strong); }
.g-card-x { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.5; }
.g-card-m { display: flex; flex-wrap: wrap; gap: 6px 12px; align-items: center; font-size: var(--text-xs); color: var(--text-muted); }
.g-card .g-who { color: var(--accent-text); }
.g-filter { display: flex; flex-wrap: wrap; gap: 8px; margin: 0 0 18px; }
.g-filter button { font: inherit; font-size: var(--text-sm); color: var(--text-muted); background: var(--bg-raised); border: 1px solid var(--line); border-radius: 999px; padding: 5px 12px; cursor: pointer; text-transform: capitalize; }
.g-filter button span { opacity: .7; margin-left: 2px; }
.g-filter button.is-on { color: var(--text); border-color: var(--accent); }
.g-foot { margin-top: 40px; padding-top: 16px; border-top: 1px solid var(--line); font-size: var(--text-xs); color: var(--text-muted); display: grid; gap: 6px; line-height: 1.5; }
.g-foot code { font-family: var(--font-mono); }
@media (max-width: 600px) { .g-main { padding: 22px 16px 48px; } .g-title { font-size: 1.7rem; } .g-body { font-size: 1.04rem; } }
`;
function journalGarden(days, projects, o = {}) {
  const minP = o.minProjectDays ?? 2, minT = o.minThemeDays ?? 5;
  const sorted = [...days].filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d.date)).sort((a, b) => b.date.localeCompare(a.date));
  const names = projects.map((p) => p.trim()).filter((p) => p.length >= 3);
  const rx = (n) => new RegExp(`(^|[^\\w])${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?![\\w])`, "i");
  const linkify = (line, self2) => {
    let out2 = line;
    for (const n of names) {
      if (n.toLowerCase() === self2.toLowerCase()) continue;
      const m = out2.match(rx(n));
      if (!m || out2.includes("[[")) continue;
      const i = (m.index || 0) + m[1].length;
      out2 = out2.slice(0, i) + `[[${n}]]` + out2.slice(i + n.length);
    }
    return out2;
  };
  const label = (d) => (/* @__PURE__ */ new Date(d + "T12:00:00")).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
  const page2 = (title, hits) => {
    const body = hits.map((h) => `## ${label(h.date)}
${h.lines.map(([k, t]) => `- ${k ? `**${k}:** ` : ""}${linkify(t, title)}`).join("\n")}`).join("\n\n");
    const n = hits.length, stage = n >= 20 ? "evergreen" : n >= 5 ? "budding" : "seedling";
    return {
      title,
      days: n,
      stage,
      created: hits[n - 1].date + "T12:00:00.000Z",
      updated: hits[0].date + "T12:00:00.000Z",
      markdown: `*Grown automatically from my daily journal: each day ${title} comes up, it gets a new entry. Newest first.*

${body}
`
    };
  };
  const out = [];
  for (const p of names) {
    const r = rx(p), hits = [];
    for (const d of sorted) {
      const lines = [];
      if (d.headline && r.test(d.headline)) lines.push(["", d.headline]);
      for (const f of d.focus || []) if (r.test(f)) lines.push(["Focus", f]);
      for (const w of d.wins || []) if (r.test(w)) lines.push(["Win", w]);
      if (lines.length) hits.push({ date: d.date, lines });
    }
    if (hits.length >= minP) out.push(page2(p, hits));
  }
  const themes = /* @__PURE__ */ new Map();
  for (const d of sorted) for (const t of d.themes || []) {
    const k = String(t).trim();
    if (k) themes.set(k, [...themes.get(k) || [], d]);
  }
  const total = sorted.filter((d) => d.headline || d.focus?.length || d.wins?.length).length;
  const picked = [];
  for (const [t, ds] of [...themes].sort((a, b) => b[1].length - a[1].length)) {
    if (names.some((n) => n.toLowerCase() === t.toLowerCase())) continue;
    if (total >= 10 && ds.length > total * 0.7) continue;
    const set = new Set(ds.map((d) => d.date));
    if (picked.some((p) => {
      let both = 0;
      for (const x of set) if (p.has(x)) both++;
      return both / (set.size + p.size - both) >= 0.8;
    })) continue;
    const hits = ds.map((d) => ({ date: d.date, lines: [["", d.headline || ""], ...(d.wins || []).slice(0, 2).map((w) => ["Win", w])].filter(([, x]) => x) })).filter((h) => h.lines.length);
    if (hits.length >= minT) {
      out.push(page2(t, hits));
      picked.push(set);
    }
  }
  return out;
}

// src/city.ts
var esc2 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var num = (v) => Math.max(0, Math.floor(Number(v) || 0));
function parseCityRepos(raw) {
  const rows = Array.isArray(raw?.repos) ? raw.repos : [];
  return rows.filter((r) => r && typeof r.name === "string" && r.name.trim()).slice(0, 300).map((r) => ({
    name: String(r.name).slice(0, 80),
    project: String(r.project || "Other").slice(0, 60),
    public: r.public === true,
    language: String(r.language || "Other").slice(0, 30),
    commits: num(r.commits),
    week: num(r.week),
    today: num(r.today),
    weeks: (Array.isArray(r.weeks) ? r.weeks : []).slice(-12).map(num),
    pushed: typeof r.pushed === "string" ? r.pushed.slice(0, 40) : void 0,
    created: typeof r.created === "string" ? r.created.slice(0, 40) : void 0,
    size: num(r.size),
    url: r.public === true && /^https:\/\//.test(String(r.url || "")) ? String(r.url) : void 0,
    description: r.public === true && r.description ? String(r.description).slice(0, 200) : void 0
  }));
}
function cityData(repos, notes, generated) {
  const by = /* @__PURE__ */ new Map();
  for (const r of repos) by.set(r.project, [...by.get(r.project) || [], r]);
  const districts = [...by.entries()].map(([name, rs]) => {
    const nn = notes(name);
    return { name, notes: nn.n, notePaths: nn.paths.slice(0, 6), repos: rs.sort((a, b) => b.commits - a.commits) };
  }).sort((a, b) => b.repos.reduce((s, r) => s + r.commits, 0) - a.repos.reduce((s, r) => s + r.commits, 0));
  return { generated, districts, private: true };
}
var LOCKED_STEPS = [1, 10, 25, 50, 100, 250, 500, 1e3, 2500, 5e3];
var coarse = (n) => n <= 0 ? 0 : LOCKED_STEPS.reduce((b, s) => n >= s ? s : b, 1);
var locked = (r, project) => ({ name: "", project, public: false, locked: true, language: "Private", commits: coarse(r.commits), weeks: [], week: r.week > 0 ? 1 : 0, today: 0 });
function publicCity(c, publicProjects) {
  const pub = new Set(publicProjects.map((p) => p.toLowerCase()));
  const districts = [], hidden = [];
  for (const d of c.districts) {
    const listed = pub.has(d.name.toLowerCase()) || d.repos.some((r) => r.public);
    if (!listed) {
      hidden.push(...d.repos.map((r) => locked(r, "Private")));
      continue;
    }
    districts.push({ name: d.name, notes: pub.has(d.name.toLowerCase()) ? d.notes : 0, repos: d.repos.map((r) => r.public ? r : locked(r, d.name)) });
  }
  if (hidden.length) districts.push({ name: "Private", notes: 0, repos: hidden.sort((a, b) => b.commits - a.commits) });
  const all = c.districts.flatMap((d) => d.repos);
  return { generated: c.generated, districts, private: false, totals: { commits: all.reduce((s, r) => s + r.commits, 0), active: all.filter((r) => r.week > 0).length } };
}
function renderCity(site, city) {
  const repos = city.districts.flatMap((d) => d.repos);
  const total = city.totals?.commits ?? repos.reduce((s, r) => s + r.commits, 0), active = city.totals?.active ?? repos.filter((r) => r.week > 0).length, notes = city.districts.reduce((s, d) => s + d.notes, 0);
  const json = JSON.stringify({ ...city, openBase: site.openBase || "" }).replace(/</g, "\\u003c");
  const icon = site.icon ? `<link rel="icon" href="${esc2(site.icon)}" type="image/png">` : `<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">`;
  const rows = city.districts.map((d) => `<tr><td>${esc2(d.name)}</td><td>${d.repos.length}</td><td>${d.repos.reduce((s, r) => s + r.commits, 0).toLocaleString("en-US")}</td><td>${d.repos.reduce((s, r) => s + r.week, 0)}</td><td>${d.notes}</td></tr>`).join("");
  return `<!doctype html><html lang="en"${site.theme === "light" ? ' data-theme="light"' : ""}><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc2(site.name)}'s city</title>
<meta name="robots" content="noindex, nofollow"><meta name="generator" content="Caldera for Obsidian">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400&display=swap">
${icon}<link rel="stylesheet" href="assets/theme.css"><link rel="stylesheet" href="assets/profile.css"><style>${CITY_CSS}</style></head><body>
<div class="tabs"><a class="tab" href="index.html">${esc2(site.name)}.md</a><span class="tab is-active">City</span><span class="spacer"></span></div>
<div class="shell">${site.nav ? site.nav(0, "city.html") : ""}<main class="note"><div class="c-main">
<div class="g-crumbs c-crumbs"><a href="index.html">${esc2(site.handle ? "@" + site.handle : site.name)}</a> / City</div>
<h1 class="c-title">${esc2(site.name)}'s city</h1>
<p class="c-lede">Every project is a district and every GitHub repo a building: taller means more commits this year, lit windows mean commits this week, a crane means it's being built right now. The houses around each district are the Obsidian notes about that project.${city.private ? " <b>Private view:</b> every repo, including private ones." : repos.some((r) => r.locked) ? " Glass buildings with a padlock are private repos: you can see the city grow, not what's inside." : ""}</p>
<div class="c-stats"><div><b>${repos.length}</b><span>buildings</span></div><div><b>${total.toLocaleString("en-US")}</b><span>commits this year</span></div><div><b>${active}</b><span>busy this week</span></div><div><b>${notes.toLocaleString("en-US")}</b><span>notes in town</span></div></div>
<div class="c-stage" id="stage"><canvas id="city" aria-label="Isometric city of ${repos.length} projects"></canvas>
<div class="c-tools"><button id="t-labels" aria-pressed="true">Labels</button><button id="t-sky">Night</button><button id="t-reset">Reset</button></div>
<div class="c-card" id="card" hidden></div><div class="c-hint">Drag to move &middot; scroll or pinch to zoom &middot; tap a building</div></div>
<div class="c-legend"><span><i style="background:#3178C6"></i>TypeScript</span><span><i style="background:#E8C547"></i>JavaScript</span><span><i style="background:#4FB89A"></i>Python</span><span><i style="background:#E07A4F"></i>HTML</span><span><i style="background:#F05138"></i>Swift</span><span><i style="background:#8A8A93"></i>Other</span>${repos.some((r) => r.locked) ? '<span><i style="background:#5C6B86"></i>&#128274; Private</span>' : ""}<span>&#127959; built this week</span><span>&#127968; notes about the project</span></div>
<div class="c-table-wrap"><table class="c-table"><thead><tr><th>District</th><th>Buildings</th><th>Commits this year</th><th>This week</th><th>Notes</th></tr></thead><tbody>${rows}</tbody></table></div>
${city.generated ? `<p class="c-foot">GitHub counts from ${esc2(new Date(city.generated).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }))}.</p>` : ""}
</div></main></div>
<script type="application/json" id="city-data">${json}<\/script>
<script>${CITY_JS}<\/script></body></html>`;
}
var CITY_CSS = `
.c-main{max-width:1100px;margin:0 auto;padding:28px 20px 64px}
.c-crumbs{font-size:var(--text-sm);color:var(--text-muted);margin-bottom:6px}.c-crumbs a{color:var(--text-muted)}
.c-title{font-family:var(--font-serif,'Source Serif 4',Georgia,serif);font-size:2.1rem;margin:0 0 8px;color:var(--text-strong)}
.c-lede{color:var(--text-muted);max-width:70ch;margin:0 0 16px}
.c-stats{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:14px}
.c-stats div{flex:1 1 120px;background:var(--bg-raised);border:1px solid var(--line);border-radius:var(--radius-md,10px);padding:10px 14px;display:flex;flex-direction:column}
.c-stats b{font-size:1.5rem;font-variant-numeric:tabular-nums;color:var(--text-strong)}.c-stats span{font-size:var(--text-xs,12px);color:var(--text-muted)}
.c-stage{position:relative;height:min(72vh,720px);min-height:420px;border-radius:var(--radius-md,10px);overflow:hidden;border:1px solid var(--line);background:#0E1320;touch-action:none}
.c-stage canvas{width:100%;height:100%;display:block;cursor:grab}.c-stage canvas.drag{cursor:grabbing}
.c-tools{position:absolute;top:10px;right:10px;display:flex;gap:6px}
.c-tools button{font:500 12px var(--font-sans,'IBM Plex Sans',sans-serif);padding:5px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.18);background:rgba(14,19,32,.72);color:#E8E8EE;cursor:pointer}
.c-tools button[aria-pressed="false"]{opacity:.6}
.c-hint{position:absolute;left:10px;bottom:10px;font:12px var(--font-sans,sans-serif);color:rgba(232,232,238,.75);background:rgba(14,19,32,.6);padding:4px 8px;border-radius:6px;pointer-events:none}
.c-card{position:absolute;left:10px;top:10px;width:min(300px,calc(100% - 20px));max-height:calc(100% - 60px);overflow:auto;background:rgba(18,22,34,.94);border:1px solid rgba(255,255,255,.14);border-radius:10px;padding:12px 14px;color:#E8E8EE;font:13px/1.45 var(--font-sans,'IBM Plex Sans',sans-serif);box-shadow:0 10px 30px rgba(0,0,0,.35)}
.c-card h3{margin:0 0 2px;font-size:15px;color:#fff}.c-card .k{color:#9A9AA6;font-size:12px}.c-card a{color:#B9A6FF}
.c-card .row{display:flex;justify-content:space-between;gap:8px;margin-top:4px}.c-card .x{position:absolute;top:6px;right:8px;background:none;border:0;color:#9A9AA6;font-size:16px;cursor:pointer}
.c-card .sp{display:flex;align-items:flex-end;gap:2px;height:28px;margin:8px 0 2px}.c-card .sp i{flex:1;background:#8B6CF6;border-radius:2px 2px 0 0;min-height:2px}
.c-legend{display:flex;flex-wrap:wrap;gap:6px 14px;margin:10px 0 18px;font-size:var(--text-sm);color:var(--text-muted)}
.c-legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:-1px}
.c-table-wrap{overflow-x:auto}.c-table{width:100%;border-collapse:collapse;font-size:var(--text-sm);font-variant-numeric:tabular-nums}
.c-table th,.c-table td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--line)}.c-table th{color:var(--text-muted);font-weight:500}
.c-foot{font-size:var(--text-xs,12px);color:var(--text-muted);margin-top:12px}
@media (max-width:600px){.c-main{padding:20px 16px 48px}.c-title{font-size:1.7rem}.c-stage{height:62vh;min-height:360px}}
`;
var CITY_JS = String.raw`(function(){
var D=JSON.parse(document.getElementById('city-data').textContent);
var cv=document.getElementById('city'),st=document.getElementById('stage'),cx=cv.getContext('2d'),card=document.getElementById('card');
var TW=64,TH=32,LANG={TypeScript:'#3178C6',JavaScript:'#E8C547',Python:'#4FB89A',HTML:'#E07A4F',Swift:'#F05138',CSS:'#6E5BD0',Shell:'#7FB24A',Go:'#2FB5D6',Rust:'#C9744A'};
var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
var hr=new Date().getHours(),night=hr<6||hr>=19,labels=true;
function rnd(s){var x=Math.sin(s)*10000;return x-Math.floor(x)}
function hash(t){var h=0;for(var i=0;i<t.length;i++)h=(h*31+t.charCodeAt(i))|0;return Math.abs(h)}
function shade(hex,f){var n=parseInt(hex.slice(1),16),r=n>>16,g=n>>8&255,b=n&255;r=Math.round(Math.min(255,r*f));g=Math.round(Math.min(255,g*f));b=Math.round(Math.min(255,b*f));return 'rgb('+r+','+g+','+b+')'}
var now=Date.now(),DAY=864e5;
// ---- layout: districts are square blocks packed in rows with 1-tile roads between them
var blocks=[],tiles={},W=0,H=0,x=1,y=1,rowH=0;
var area=D.districts.reduce(function(s,d){var n=d.repos.length+Math.ceil(Math.min(d.notes,40)/4);var k=Math.max(2,Math.ceil(Math.sqrt(n)));return s+(k+1)*(k+1)},0);
var maxW=Math.max(8,Math.ceil(Math.sqrt(area)*1.25));
D.districts.forEach(function(d){
  var houses=Math.min(d.notes,40),need=d.repos.length+Math.ceil(houses/4),k=Math.max(2,Math.ceil(Math.sqrt(need)));
  if(x+k>maxW&&x>1){x=1;y+=rowH+1;rowH=0}
  var b={d:d,x:x,y:y,k:k};blocks.push(b);
  var cells=[];for(var j=0;j<k;j++)for(var i=0;i<k;i++)cells.push([x+i,y+j]);
  cells.sort(function(a,c){return (a[0]+a[1])-(c[0]+c[1])});   // biggest towers at the back
  d.repos.forEach(function(r,i){var c=cells[i];tiles[c[0]+','+c[1]]={t:'b',r:r,d:d}});
  var hi=d.repos.length,left=houses;
  while(left>0&&hi<cells.length){var c=cells[hi++];var n=Math.min(4,left);left-=n;tiles[c[0]+','+c[1]]={t:'h',n:n,d:d}}
  for(;hi<cells.length;hi++){var c2=cells[hi];tiles[c2[0]+','+c2[1]]={t:'p',d:d}}
  x+=k+1;rowH=Math.max(rowH,k);W=Math.max(W,x);H=Math.max(H,y+rowH+1);
});
W=Math.max(W,maxW)+1;H+=1;
for(var j=0;j<=H;j++)for(var i=0;i<=W;i++){var key=i+','+j;if(!tiles[key])tiles[key]={t:(i===0||j===0||i===W||j===H)?'g':'r'}}
// ---- buildings
var maxC=1;D.districts.forEach(function(d){d.repos.forEach(function(r){maxC=Math.max(maxC,r.commits)})});
function bh(r){return 16+Math.min(230,Math.round(34*Math.log2(1+r.commits/8)))}
var maxH=0,ranked=[];D.districts.forEach(function(d){d.repos.forEach(function(r){maxH=Math.max(maxH,bh(r));ranked.push(r)})});
ranked.sort(function(a,b){return (b.week*20+b.commits)-(a.week*20+a.commits)});var topSet=ranked.slice(0,12);
function dormant(r){return r.pushed&&now-Date.parse(r.pushed)>60*DAY&&!r.week}
// ---- view
var dpr=1,vw=0,vh=0,cam={x:0,y:0,z:1};
function iso(i,j){return {x:(i-j)*TW/2,y:(i+j)*TH/2}}
function fit(){var r=st.getBoundingClientRect();dpr=window.devicePixelRatio||1;vw=r.width;vh=r.height;cv.width=vw*dpr;cv.height=vh*dpr;
  var spanX=(W+H)*TW/2+TW,spanY=(W+H)*TH/2+maxH+40;cam.z=Math.min(1.6,Math.max(.3,Math.min(vw/spanX,vh/spanY)*.98));
  var c=iso(W/2,H/2);cam.x=vw/2-c.x*cam.z;cam.y=vh/2-c.y*cam.z+(maxH/2)*cam.z}
// ---- cars wander the roads
var roads=[];for(var k in tiles)if(tiles[k].t==='r'){var p=k.split(',');roads.push([+p[0],+p[1]])}
var traffic=D.districts.reduce(function(s,d){return s+d.repos.reduce(function(a,r){return a+r.week},0)},0);
var cars=[];for(var c=0;c<Math.min(70,4+Math.round(traffic/6))&&roads.length;c++){var s=roads[Math.floor(rnd(c+1)*roads.length)];cars.push({i:s[0],j:s[1],ti:s[0],tj:s[1],t:1,col:['#F2F2F5','#E85D75','#4FB89A','#E8C547','#7AA7FF'][c%5]})}
function step(car){var o=[[1,0],[-1,0],[0,1],[0,-1]].map(function(d){return [car.ti+d[0],car.tj+d[1]]}).filter(function(n){var t=tiles[n[0]+','+n[1]];return t&&t.t==='r'&&!(n[0]===car.i&&n[1]===car.j)});
  if(!o.length)o=[[car.i,car.j]];var n=o[Math.floor(Math.random()*o.length)];car.i=car.ti;car.j=car.tj;car.ti=n[0];car.tj=n[1];car.t=0}
// ---- drawing
function diamond(px,py,fill,stroke){cx.beginPath();cx.moveTo(px,py-TH/2);cx.lineTo(px+TW/2,py);cx.lineTo(px,py+TH/2);cx.lineTo(px-TW/2,py);cx.closePath();cx.fillStyle=fill;cx.fill();if(stroke){cx.strokeStyle=stroke;cx.lineWidth=1;cx.stroke()}}
function box(px,py,w,h,col,lit,seed,win){var hw=TW/2*w,hh=TH/2*w;
  cx.beginPath();cx.moveTo(px-hw,py);cx.lineTo(px,py+hh);cx.lineTo(px,py+hh-h);cx.lineTo(px-hw,py-h);cx.closePath();cx.fillStyle=shade(col,night?.42:.62);cx.fill();
  cx.beginPath();cx.moveTo(px,py+hh);cx.lineTo(px+hw,py);cx.lineTo(px+hw,py-h);cx.lineTo(px,py+hh-h);cx.closePath();cx.fillStyle=shade(col,night?.55:.82);cx.fill();
  cx.beginPath();cx.moveTo(px,py-hh-h);cx.lineTo(px+hw,py-h);cx.lineTo(px,py+hh-h);cx.lineTo(px-hw,py-h);cx.closePath();cx.fillStyle=shade(col,night?.75:1.08);cx.fill();
  if(!win)return;var rows=Math.floor((h-8)/9);for(var rr=0;rr<rows;rr++)for(var cc=0;cc<3;cc++)for(var side=0;side<2;side++){
    var on=rnd(seed+rr*7+cc*13+side*31)<lit;var fx=(cc+.6)/3.4,ox=side?px+hw*fx:px-hw*(1-fx)-0,oy=(side?py+hh*(1-fx):py+hh*fx)-12-rr*9;
    if(side===0){ox=px-hw+hw*fx;oy=py+hh*fx-12-rr*9}
    cx.fillStyle=on?(night?'rgba(255,214,120,.95)':'rgba(255,240,190,.9)'):(night?'rgba(20,24,40,.65)':'rgba(40,60,90,.35)');cx.fillRect(ox-2,oy-3,4,4)}}
function crane(px,py,h,t){cx.strokeStyle='#F2B33D';cx.lineWidth=1.5;cx.beginPath();cx.moveTo(px+6,py-h);cx.lineTo(px+6,py-h-34);cx.lineTo(px-22,py-h-34);cx.moveTo(px+6,py-h-34);cx.lineTo(px+16,py-h-34);cx.stroke();
  var sw=Math.sin(t/600)*4;cx.beginPath();cx.moveTo(px-14+sw,py-h-34);cx.lineTo(px-14+sw,py-h-18);cx.stroke();cx.fillStyle='#F2B33D';cx.fillRect(px-17+sw,py-h-18,6,4)}
function house(px,py,n,seed){var spots=[[-12,-2],[12,-2],[0,-8],[0,5]];for(var q=0;q<n;q++){var s=spots[q],hx=px+s[0],hy=py+s[1],col=['#C9A27A','#B9C4D6','#D9B38C','#A7C4A0'][(seed+q)%4];
  box(hx,hy,.28,8,col,0,0,false);cx.beginPath();cx.moveTo(hx-9,hy-8);cx.lineTo(hx,hy-17);cx.lineTo(hx+9,hy-8);cx.lineTo(hx,hy-4+0);cx.closePath();cx.fillStyle=night?'#6B3B3B':'#B4554F';cx.fill();
  if(night){cx.fillStyle='rgba(255,214,120,.9)';cx.fillRect(hx-1,hy-5,2,2)}}}
function tree(px,py,s){cx.fillStyle=night?'#1E3B2C':'#3E8E5A';cx.beginPath();cx.arc(px,py-10*s,7*s,0,7);cx.fill();cx.fillStyle=night?'#163024':'#2F7247';cx.beginPath();cx.arc(px+3*s,py-7*s,5*s,0,7);cx.fill()}
var hits=[],sel=null,T=0;
function draw(){T=performance.now();cx.setTransform(dpr,0,0,dpr,0,0);
  var g=cx.createLinearGradient(0,0,0,vh);if(night){g.addColorStop(0,'#070A14');g.addColorStop(1,'#141B2E')}else{g.addColorStop(0,'#8EC5F2');g.addColorStop(1,'#DCEFFB')}cx.fillStyle=g;cx.fillRect(0,0,vw,vh);
  if(night){for(var s=0;s<70;s++){cx.fillStyle='rgba(255,255,255,'+(.3+rnd(s)*.6)+')';cx.fillRect(rnd(s*3)*vw,rnd(s*7)*vh*.45,1.2,1.2)}}
  cx.setTransform(dpr*cam.z,0,0,dpr*cam.z,dpr*cam.x,dpr*cam.y);hits=[];
  for(var sum=0;sum<=W+H;sum++)for(var i=0;i<=W;i++){var j=sum-i;if(j<0||j>H)continue;var t=tiles[i+','+j],p=iso(i,j);
    if(t.t==='r'){diamond(p.x,p.y,night?'#252A36':'#5B6270');if((i+j)%2===0){cx.fillStyle=night?'rgba(242,200,90,.35)':'rgba(255,255,255,.55)';cx.fillRect(p.x-1.5,p.y-1,3,2)}}
    else if(t.t==='g'){diamond(p.x,p.y,night?'#14261C':'#6FB36F')}
    else{diamond(p.x,p.y,night?'#1B2E22':'#86C27E',night?'rgba(0,0,0,.25)':'rgba(0,0,0,.08)')}
    if(t.t==='p'){tree(p.x-8,p.y+2,1);tree(p.x+10,p.y-3,.8)}
    if(t.t==='h')house(p.x,p.y,t.n,hash(t.d.name));
    if(t.t==='b'){var r=t.r,h=bh(r),dm=dormant(r),col=dm?'#7C7F88':(LANG[r.language]||'#8A8A93');
      var wk=r.weeks&&r.weeks.length?Math.max.apply(null,r.weeks):0,lit=dm?0:Math.min(.95,.12+(r.week/(Math.max(wk,1)))*.8);
      if(r.locked){col='#5C6B86';lit=r.week?.35:.05}
      box(p.x,p.y+4,.82,h,col,lit,hash(r.name||(i+'_'+j)),true);
      if(r.locked){cx.fillStyle=night?'#C9D2E6':'#2B3346';cx.font='11px sans-serif';cx.textAlign='center';cx.fillText('\uD83D\uDD12',p.x,p.y+4-h-TH/2-2)}if(r.week>0&&!dm)crane(p.x,p.y+4,h,T+hash(r.name));
      if(sel===r){cx.strokeStyle='#B9A6FF';cx.lineWidth=2/cam.z;cx.strokeRect(p.x-TW*.45,p.y-h-TH*.5,TW*.9,h+TH)}
      hits.push({r:r,d:t.d,x0:p.x-TW*.42,x1:p.x+TW*.42,y0:p.y-h-TH*.45,y1:p.y+TH*.45});
      if(labels&&!r.locked&&(cam.z>1.05||sel===r||topSet.indexOf(r)>=0)){var lb=r.name.length>18?r.name.slice(0,17)+'…':r.name;cx.font='600 11px IBM Plex Sans,Arial,sans-serif';var tw=cx.measureText(lb).width;
        cx.fillStyle='rgba(14,19,32,.78)';cx.fillRect(p.x-tw/2-5,p.y-h-30,tw+10,16);cx.fillStyle='#F2F2F5';cx.textAlign='center';cx.fillText(lb,p.x,p.y-h-18)}}}
  // district signs
  if(labels)blocks.forEach(function(b){var p=iso(b.x+b.k,b.y+b.k);cx.font='700 12px IBM Plex Sans,Arial,sans-serif';var lb=b.d.name,tw=cx.measureText(lb).width;cx.fillStyle='rgba(139,108,246,.92)';cx.fillRect(p.x-tw/2-7,p.y+4,tw+14,18);cx.fillStyle='#fff';cx.textAlign='center';cx.fillText(lb,p.x,p.y+17)});
  // cars
  cars.forEach(function(c){var a=iso(c.i,c.j),b=iso(c.ti,c.tj),px=a.x+(b.x-a.x)*c.t,py=a.y+(b.y-a.y)*c.t;cx.fillStyle=c.col;cx.fillRect(px-3,py-2,6,4);if(night){cx.fillStyle='rgba(255,240,180,.7)';cx.fillRect(px+2,py-1,2,2)}});
}
function tick(){cars.forEach(function(c){c.t+=0.012;if(c.t>=1)step(c)});draw();if(!reduce)requestAnimationFrame(tick)}
// ---- interaction
function ago(iso){if(!iso)return '';var d=Math.round((now-Date.parse(iso))/DAY);return d<=0?'today':d===1?'yesterday':d+' days ago'}
function e(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function show(h){sel=h?h.r:null;if(!h){card.hidden=true;draw();return}var r=h.r,d=h.d,mx=Math.max.apply(null,(r.weeks||[0]).concat([1]));
  var notes=(d.notePaths||[]).map(function(p){var n=p.split('/').pop().replace(/\.md$/,'');return D.openBase?'<a href="'+e(D.openBase+encodeURIComponent(p))+'" target="_blank" rel="noopener">'+e(n)+'</a>':'<a href="#" data-open="'+e(p)+'">'+e(n)+'</a>'}).join(', ');
  if(r.locked){card.innerHTML='<button class="x" aria-label="Close">&times;</button><h3>&#128274; Private repo</h3><div class="k">'+e(d.name)+' district</div><p style="margin:8px 0 0">The details of this building are private. Its size and lights show roughly how much work goes on inside.</p>';card.hidden=false;card.querySelector('.x').onclick=function(){show(null)};draw();return}
  card.innerHTML='<button class="x" aria-label="Close">&times;</button><h3>'+e(r.name)+'</h3><div class="k">'+e(d.name)+' district &middot; '+e(r.language)+(r.public?' &middot; public':'')+'</div>'
   +(r.description?'<p style="margin:6px 0 0">'+e(r.description)+'</p>':'')
   +'<div class="sp" title="Commits, last 12 weeks">'+(r.weeks||[]).map(function(w){return '<i style="height:'+Math.max(4,Math.round(w/mx*100))+'%"></i>'}).join('')+'</div><div class="k">Commits, last 12 weeks</div>'
   +'<div class="row"><span>Commits this year</span><b>'+r.commits.toLocaleString('en-US')+'</b></div><div class="row"><span>This week</span><b>'+r.week+'</b></div>'
   +(r.pushed?'<div class="row"><span>Last push</span><b>'+ago(r.pushed)+'</b></div>':'')
   +'<div class="row"><span>Notes about '+e(d.name)+'</span><b>'+d.notes+'</b></div>'+(notes?'<div class="k" style="margin-top:6px">'+notes+'</div>':'')
   +(r.url?'<p style="margin:8px 0 0"><a href="'+e(r.url)+'" target="_blank" rel="noopener">Open on GitHub &#8599;</a></p>':'');
  card.hidden=false;card.querySelector('.x').onclick=function(){show(null)};draw()}
function at(px,py){var wx=(px-cam.x)/cam.z,wy=(py-cam.y)/cam.z;for(var i=hits.length-1;i>=0;i--){var h=hits[i];if(wx>=h.x0&&wx<=h.x1&&wy>=h.y0&&wy<=h.y1)return h}return null}
var ptr={},moved=false,pinch=0;
cv.addEventListener('pointerdown',function(ev){cv.setPointerCapture(ev.pointerId);ptr[ev.pointerId]={x:ev.clientX,y:ev.clientY};moved=false;cv.classList.add('drag');var ks=Object.keys(ptr);if(ks.length===2){var a=ptr[ks[0]],b=ptr[ks[1]];pinch=Math.hypot(a.x-b.x,a.y-b.y)}});
cv.addEventListener('pointermove',function(ev){var p=ptr[ev.pointerId];if(!p)return;var ks=Object.keys(ptr);
  if(ks.length===2){var o=ptr[ks[0]===String(ev.pointerId)?ks[1]:ks[0]];var dist=Math.hypot(ev.clientX-o.x,ev.clientY-o.y);if(pinch){var r=st.getBoundingClientRect();zoom(dist/pinch,(ev.clientX+o.x)/2-r.left,(ev.clientY+o.y)/2-r.top)}pinch=dist;moved=true}
  else{var dx=ev.clientX-p.x,dy=ev.clientY-p.y;if(Math.abs(dx)+Math.abs(dy)>3)moved=true;cam.x+=dx;cam.y+=dy}
  p.x=ev.clientX;p.y=ev.clientY;if(reduce)draw()});
function up(ev){var was=ptr[ev.pointerId];delete ptr[ev.pointerId];cv.classList.remove('drag');pinch=0;if(was&&!moved){var r=st.getBoundingClientRect();show(at(ev.clientX-r.left,ev.clientY-r.top))}}
cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
function zoom(f,ox,oy){var z=Math.min(3,Math.max(.25,cam.z*f));f=z/cam.z;cam.x=ox-(ox-cam.x)*f;cam.y=oy-(oy-cam.y)*f;cam.z=z;if(reduce)draw()}
cv.addEventListener('wheel',function(ev){ev.preventDefault();var r=st.getBoundingClientRect();zoom(Math.exp(-ev.deltaY*0.0015),ev.clientX-r.left,ev.clientY-r.top)},{passive:false});
var bl=document.getElementById('t-labels'),bs=document.getElementById('t-sky');
bl.onclick=function(){labels=!labels;bl.setAttribute('aria-pressed',String(labels));draw()};
function skyLabel(){bs.textContent=night?'Day':'Night'}skyLabel();bs.onclick=function(){night=!night;skyLabel();draw()};
document.getElementById('t-reset').onclick=function(){fit();show(null)};
window.addEventListener('resize',function(){fit();draw()});
fit();if(reduce)draw();else requestAnimationFrame(tick);
})();`;

// src/render.ts
function inviteHref(p) {
  const hub = (p.hub || "https://caldera.social").replace(/\/$/, "");
  const who = p.handle ? `@${p.handle}` : p.name;
  const join = `${hub}/${p.handle ? `?invite=${encodeURIComponent(p.handle)}` : ""}#install`;
  const subject = `Join me on Caldera`;
  const body = `Hey,

I'm using Caldera, the social layer for Obsidian. It turns your notes into a living profile that updates itself, and lets our vaults connect: share notes, ask for help, and compare our daily scores.

My page: ${hub}/@${p.handle || ""}/

Set up takes about 5 minutes - copy one prompt into your AI and it installs everything:
${join}

Then add me as a friend (${who}) from the Caldera panel in Obsidian.

${p.name}`;
  return `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
var INVITE_MSG = "I'm using Caldera, the social layer for Obsidian. It turns your notes into a living page that updates itself, and our vaults can connect and compare daily scores. Setup takes about 5 minutes: copy one prompt into your AI.";
function inviteUrl(p) {
  const hub = (p.hub || "https://caldera.social").replace(/\/$/, "");
  return `${hub}/${p.handle ? `?invite=${encodeURIComponent(p.handle)}` : ""}#install`;
}
function invitePop(p) {
  return `<div class="invite-pop" hidden role="dialog" aria-label="Invite a friend" data-url="${esc3(inviteUrl(p))}" data-msg="${esc3(INVITE_MSG)}" data-subject="Join me on Caldera"><div class="inv-head"><div><div class="inv-title">Invite a friend</div><div class="inv-sub">They get their own living page in about 5 minutes, and you compare daily scores here.</div></div><button class="inv-close" type="button" aria-label="Close">&times;</button></div><div class="inv-link"><input class="inv-url" readonly aria-label="Invite link" value="${esc3(inviteUrl(p))}"><button class="inv-copy" type="button">Copy link</button></div><div class="inv-ways"><a class="inv-email" href="#">Email</a><a class="inv-text" href="#">Text</a><button class="inv-share" type="button">Share</button></div><div class="inv-status" role="status" aria-live="polite"></div></div>`;
}
function slug(t) {
  return t.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "s";
}
var big = (n) => n >= 1e9 ? (n / 1e9).toFixed(2).replace(/\.?0+$/, "") + "B" : n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M" : n >= 1e3 ? Math.round(n / 1e3) + "K" : String(n);
function inline(t) {
  const parts = [];
  let last = 0;
  const rx = /\[\[([^|\]]+)\|(https?:\/\/[^\]\s]+)\]\]|\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)|\*\*([^*]+)\*\*/g;
  for (let m; m = rx.exec(t); ) {
    parts.push(esc3(t.slice(last, m.index)));
    if (m[5]) parts.push(`<b>${esc3(m[5])}</b>`);
    else parts.push(`<a href="${esc3(m[2] || m[4])}" rel="noopener">${esc3(m[1] || m[3])}</a>`);
    last = m.index + m[0].length;
  }
  return parts.join("") + esc3(t.slice(last));
}
function graphSvg(nodes, name) {
  if (!nodes.length) return "";
  const top = Math.max(1, ...nodes.map((x) => x.n)), order = [...nodes].sort((a, b) => b.n - a.n);
  const out = order.map((nd, i) => {
    const a = i / order.length * Math.PI * 2, r = i % 2 === 0 ? 64 : 96;
    const x = 130 + Math.cos(a) * r, y = 120 + Math.sin(a) * r * 0.85, size = 2.5 + 6.5 * Math.sqrt(nd.n / top);
    return { ...nd, x: x.toFixed(1), y: y.toFixed(1), ty: (y + size + 9).toFixed(1), r: size.toFixed(1), hot: nd.n >= top * 0.35, d: (-i * 0.3).toFixed(1) };
  });
  return `<svg viewBox="0 0 260 240" role="img" aria-label="Notes connected to ${esc3(name)}">${out.map((n) => `<line class="edge" x1="130" y1="120" x2="${n.x}" y2="${n.y}"></line>`).join("")}${out.map((n) => `<g class="float" style="animation-delay:${n.d}s"><circle class="node${n.hot ? " hot" : ""}" cx="${n.x}" cy="${n.y}" r="${n.r}"><title>${esc3(n.t)}: ${n.n}</title></circle><text x="${n.x}" y="${n.ty}" text-anchor="middle">${esc3(n.t)}</text></g>`).join("")}<circle class="center" cx="130" cy="120" r="9"></circle></svg>`;
}
var esc3 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var fmt = (n) => n.toLocaleString("en-US");
function scored(daily) {
  return daily.map((d, i) => {
    const score = activityScore(d.counts);
    const prev = i ? activityScore(daily[i - 1].counts) : null;
    return { ...d, score, delta: prev ? Math.round((score - prev) / prev * 100) : null };
  });
}
function renderProfile(p) {
  const s = p.sections;
  const days = scored(p.daily);
  const labels = { meetings: "Meetings", emails: "Emails sent", prompts: "AI sessions", commits: "Commits", notes: "Notes", docs: "Docs filed" };
  const present = Object.keys(labels).filter((k) => days.some((d) => d.counts[k]));
  const journal = days.map((d, i) => ({
    date: d.date,
    label: (/* @__PURE__ */ new Date(d.date + "T12:00:00")).toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" }),
    score: d.score,
    delta: d.delta,
    headline: d.headline || "",
    focus: d.focus || [],
    wins: d.wins || [],
    themes: d.themes || [],
    chips: present.map((k) => ({ k: labels[k], v: d.counts[k] || 0, d: i ? (d.counts[k] || 0) - (days[i - 1].counts[k] || 0) : null }))
  }));
  const scores = days.map((d) => d.score);
  const yday = days.length > 1 ? days[days.length - 2] : days[days.length - 1];
  let streak = 0;
  const thresh = Math.max(20, (scores.slice().sort((a, b) => a - b)[Math.floor(scores.length / 2)] || 0) * 0.6);
  for (const sc of scores.slice(0, -1).reverse()) {
    if (sc >= thresh) streak++;
    else break;
  }
  const ranked = days.slice(0, -1).slice().sort((a, b) => b.score - a.score);
  const yrank = yday ? ranked.findIndex((d) => d.date === yday.date) + 1 : 0;
  const smax = Math.max(1, ...scores);
  const last7 = scores.slice(-8, -1), prev7 = scores.slice(-15, -8);
  const avg = (a) => a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) : 0;
  const trend = avg(prev7) ? Math.round((avg(last7) - avg(prev7)) / avg(prev7) * 100) : 0;
  const tmax = Math.max(1, ...p.topics.map((t) => t[1]));
  const parts = [];
  parts.push(`<!doctype html><html lang="en"${p.theme === "light" ? ' data-theme="light"' : ""}><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc3(p.name)}</title>
<meta name="robots" content="noindex, nofollow"><meta name="generator" content="Caldera for Obsidian">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400&display=swap">
${p.icon ? `<link rel="icon" href="${esc3(p.icon)}" type="image/png"><link rel="apple-touch-icon" href="${esc3(p.icon)}">` : `<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">`}
<link rel="stylesheet" href="assets/theme.css"><link rel="stylesheet" href="assets/profile.css">${s.garden !== false && p.garden?.length ? '<link rel="stylesheet" href="assets/garden.css">' : ""}</head><body>
<div class="tabs"><span class="tab is-active">${esc3(p.name)}.md</span>${(p.tabs || []).map((t) => `<span class="tab">${esc3(t)}</span>`).join("")}<span class="spacer"></span><span class="sync"><span class="dot"></span>synced from vault <span id="ago" data-ts="${esc3(p.updated)}">just now</span></span></div>
<div class="shell">`);
  const sideOn = s.sidebar !== false && !!p.tree?.length, railOn = s.rail !== false && (!!p.graph?.length || !!p.backlinks?.length);
  const gardenOn = s.garden !== false && !!p.garden?.length;
  const nav = (depth, current, toc2 = "") => s.sidebar === false ? "" : navSidebar(p, sideOn, gardenOn, depth, current, toc2);
  parts.push(nav(0, "index.html", "%%TOC%%"));
  parts.push(`<main class="note">`);
  if (p.banner || p.avatar) parts.push(`<div class="banner">${p.banner ? `<img class="cover" src="${esc3(p.banner)}" alt="">` : ""}${p.avatar ? `<img class="avatar" src="${esc3(p.avatar)}" alt="${esc3(p.name)}">` : ""}</div>`);
  parts.push(`<div class="page"><div class="crumb">People / ${esc3(p.name)}.md${p.handle ? " / @" + esc3(p.handle) : ""}</div>
<h1 class="title">${esc3(p.name)}<span class="caret">|</span></h1>${p.headline ? `<p class="lede">${esc3(p.headline)}</p>` : ""}<!--caldera:owner-->`);
  if (s.journal && journal.length) parts.push(`<section class="journal" id="journal" aria-label="Daily journal"><div class="j-head"><button class="j-nav" id="jprev" aria-label="Previous day">&#8249;</button>
<div class="j-title"><div class="label">Daily journal</div><div class="j-date" id="jdate"></div></div><button class="j-nav" id="jnext" aria-label="Next day">&#8250;</button></div>
<div class="j-body" id="jbody" aria-live="polite"></div></section><script id="journal-data" type="application/json">${JSON.stringify(journal).replace(/</g, "\\u003c")}<\/script>`);
  if (s.scoreboard && days.length > 2) parts.push(`<section class="scoreboard" id="scoreboard"><div class="sb-stats">
<div class="sb-stat"><div class="v">${streak}<small> days</small></div><div class="l">active streak</div></div>
<div class="sb-stat"><div class="v">#${yrank}</div><div class="l">yesterday's rank of ${days.length - 1} days</div></div>
<div class="sb-stat"><div class="v">${avg(last7)}</div><div class="l">7-day average, ${trend >= 0 ? `<span class="up">&#9650; ${trend}%</span>` : `<span class="down">&#9660; ${-trend}%</span>`} vs prior week</div></div></div>
<div class="sb-bars" role="img" aria-label="Daily activity score">${days.slice(-30).map((d, i, a) => `<span class="${i === a.length - 2 ? "yday" : i === a.length - 1 ? "today" : ""}" style="height:${Math.max(2, Math.round(d.score / smax * 100))}%" title="${d.date}: ${d.score}"></span>`).join("")}</div><div class="bars-legend"><span>${Math.min(30, days.length)} days ago</span><span>yesterday highlighted / today in progress</span></div>
${(() => {
    const best = days.slice(0, -2).map((d, i) => ({ d, i })).sort((a, b) => b.d.score - a.d.score).slice(0, 5);
    const lb = [`<div class="lb-row me"><span class="rank">1</span><span class="who">You</span><span class="num">${fmt(days.slice(-8, -1).reduce((x, d) => x + d.score, 0))}</span></div>`].concat([2, 3, 4].map((r) => `<div class="lb-row empty"><span class="rank">${r}</span><a class="who invite-btn" data-invite href="${esc3(inviteHref(p))}" target="_blank" rel="noopener">Invite a friend</a><span class="num">-</span></div>`));
    return `<div class="two-col sb-lower"><div class="lb-wrap"><div class="label">Leaderboard / points this week</div>${lb.join("")}${invitePop(p)}</div><div><div class="label">Your best other days</div>${best.map((b, k) => `<div class="lb-row"><span class="rank">${k + 1}</span><span class="who">${esc3((/* @__PURE__ */ new Date(b.d.date + "T12:00:00Z")).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", timeZone: "UTC" }))}</span><span class="num">${b.d.score}</span></div>`).join("")}</div></div>`;
  })()}
<details class="sb-how"><summary>How the score works</summary>Weighted daily counts: ${Object.entries(ACTIVITY_WEIGHTS).map(([k, w]) => `${labels[k] || k} x${w}`).join(", ")}. Bulk imports are capped. Counts only.</details></section>`);
  if (s.properties && p.properties.length) parts.push(`<dl class="props">${p.properties.map(([k, v]) => `<dt>${esc3(k)}</dt><dd>${esc3(v)}</dd>`).join("")}</dl>`);
  if (s.numbers) parts.push(`<div class="stat-strip">${[[fmt(p.stats.notes), "notes"], [(p.stats.words / 1e6).toFixed(2) + "M", "words"], [fmt(p.stats.links), "links between notes"], [String(p.stats.activeDays), "active days, 26 weeks"], ...p.extraNumbers || []].map(([v, l]) => `<div class="stat"><div class="v">${v}</div><div class="l">${l}</div></div>`).join("")}</div>`);
  if (s.summary !== false && p.summary) parts.push(`<div class="callout"><div class="callout-title">Summary</div>${inline(p.summary)}</div>`);
  if (s.now !== false && p.now?.length) parts.push(`<h2>Now</h2><ul class="bullets">${p.now.map((x) => `<li>${inline(x)}</li>`).join("")}</ul>`);
  if (s.activity !== false && p.heat?.length) {
    const lvl = (n) => n === 0 ? 0 : n < 5 ? 1 : n < 30 ? 2 : n < 200 ? 3 : 4;
    const pad = ((/* @__PURE__ */ new Date(p.heat[0].date + "T12:00:00Z")).getUTCDay() + 6) % 7;
    parts.push(`<h2>Activity</h2><p class="small muted">Every day the vault learned something in the last 26 weeks: notes written and changed${p.extraNumbers?.length ? ", documents filed" : ""}.</p><div class="heat-box" data-unit="updates"><div class="heat-frame"><div class="heat-days" aria-hidden="true"><span>Mon</span><span></span><span>Wed</span><span></span><span>Fri</span><span></span><span></span></div><div class="heat-wrap"><div class="heat-months" aria-hidden="true"></div><div class="heat" tabindex="0" aria-label="Activity, last 26 weeks. Use arrow keys to move between days." aria-describedby="heat-read">${'<i style="visibility:hidden"></i>'.repeat(pad)}${p.heat.map((c) => `<i class="l${lvl(c.n)}" data-d="${esc3(c.date)}" data-n="${c.n}"></i>`).join("")}</div></div></div><div class="heat-tip" hidden></div><div class="heat-foot"><div class="heat-read" id="heat-read" aria-live="polite"></div><div class="heat-legend">less <i class="l1"></i><i class="l2"></i><i class="l3"></i><i class="l4"></i> more</div></div></div>`);
  }
  const growthOn = s.growth !== false && (p.growth?.length || 0) > 1, knowsOn = s.knows !== false && !!p.knows?.length;
  if (growthOn || knowsOn) {
    let g = "";
    if (growthOn) {
      const gp = p.growth, gmax = Math.max(1, gp[gp.length - 1].total), W = 600, H = 180;
      const gx = (i) => 30 + i * (W - 40) / Math.max(1, gp.length - 1), gy = (v) => 10 + (H - 30) * (1 - v / gmax);
      const line = gp.map((x, i) => `${gx(i).toFixed(1)},${gy(x.total).toFixed(1)}`).join(" ");
      const first = (/* @__PURE__ */ new Date(gp[0].week + "T12:00:00Z")).toLocaleDateString("en-US", { month: "short", year: "numeric", timeZone: "UTC" });
      g = `<div><h2>Growth</h2><svg class="growth" viewBox="0 0 ${W} ${H}" role="img" aria-label="Notes over time, ${fmt(gmax)} now"><line class="axis" x1="30" y1="${H - 20}" x2="${W - 10}" y2="${H - 20}"></line><path class="area" d="M${gx(0).toFixed(1)},${H - 20} L${line.replace(/ /g, " L")} L${gx(gp.length - 1).toFixed(1)},${H - 20} Z"></path><polyline class="line" points="${line}"></polyline><circle class="now" cx="${gx(gp.length - 1).toFixed(1)}" cy="${gy(gmax).toFixed(1)}" r="5"></circle><text x="30" y="${H - 4}">${esc3(first)}</text><text x="${W - 10}" y="${H - 4}" text-anchor="end">${fmt(gmax)} notes</text></svg></div>`;
    }
    const kmax = Math.max(1, ...(p.knows || []).map((k2) => k2[1]));
    const k = knowsOn ? `<div><h2>What it knows</h2>${p.knows.map(([l, n]) => `<div class="hbar"><span>${esc3(l)}</span><span class="track"><span class="fill" style="width:${(n / kmax * 100).toFixed(1)}%"></span></span><span class="num">${fmt(n)}</span></div>`).join("")}</div>` : "";
    parts.push(`<div class="two-col">${g}${k}</div>`);
  }
  if (s.inbox !== false && p.inbox?.kinds?.length) {
    const ib = p.inbox, kmax = Math.max(1, ...ib.kinds.map((k) => k[1])), total = ib.total ?? ib.kinds.reduce((a, k) => a + k[1], 0);
    const se = ib.series, smax2 = Math.max(1, ...(se?.weeks || []).map((w) => w[1]));
    parts.push(`<h2>Inbox to knowledge</h2><p class="small muted">${esc3(ib.note || `Every email attachment is read, summarized and linked into the vault overnight. ${fmt(total)} documents so far, by kind. Contents stay private.`)}</p><div class="two-col"><div>${ib.kinds.map(([l, n]) => `<div class="hbar"><span>${esc3(l)}</span><span class="track"><span class="fill alt" style="width:${(n / kmax * 100).toFixed(1)}%"></span></span><span class="num">${fmt(n)}</span></div>`).join("")}</div>${se?.weeks?.length ? `<div><div class="label">${esc3(se.label)} / ${fmt(se.weeks.reduce((a, w) => a + w[1], 0))} in ${se.weeks.length} weeks</div><div class="cols">${se.weeks.map(([l, n]) => `<span title="${esc3(l)}: ${n}"><b style="height:${Math.max(3, n / smax2 * 100).toFixed(1)}%"></b><em>${n || ""}</em></span>`).join("")}</div><div class="bars-legend"><span>${esc3(se.weeks[0][0])}</span><span>this week</span></div></div>` : ""}</div>`);
  }
  if (s.topics && p.topics.length) parts.push(`<h2>Topics</h2><div class="cloud">${p.topics.map(([t, n]) => `<span style="font-size:${(13 + n / tmax * 15).toFixed(1)}px">${esc3(t)}<sup>${n}</sup></span>`).join("")}</div>`);
  if (s.projects !== false && p.projects?.length) {
    const hasC = p.projects.some((x) => x.commits);
    parts.push(`<h2>Projects</h2><div class="query">TABLE status, ${hasC ? "commits, " : ""}link FROM "Projects" SORT ${hasC ? "commits DESC" : "file.name"}</div><div class="table-wrap"><table class="data"><thead><tr><th>File</th><th>status</th>${hasC ? '<th class="num">commits</th>' : ""}<th>link</th></tr></thead><tbody>${p.projects.map((x) => `<tr><td>${/^https?:\/\//.test(x.url) ? `<a href="${esc3(x.url)}" rel="noopener">${esc3(x.name)}</a>` : esc3(x.name)}</td><td>${esc3(x.status)}</td>${hasC ? `<td class="num">${x.commits ? fmt(x.commits) : ""}</td>` : ""}<td>${/^https?:\/\//.test(x.url) ? `<a href="${esc3(x.url)}" rel="noopener">${esc3(x.url.replace(/^https?:\/\//, "").replace(/\/$/, ""))}</a>` : ""}</td></tr>`).join("")}</tbody></table></div>`);
  }
  if (s.code !== false && p.code && p.code.commits > 0) {
    const c = p.code, wk = c.weekly || [], f = Math.max(0, wk.findIndex((x) => x > 0)), w2 = wk.slice(f), peak = Math.max(1, ...w2);
    parts.push(`<h2>Code</h2><p class="small"><b>${fmt(c.commits)}</b> commits across <b>${fmt(c.repos)}</b> repositories in the last year.${c.languages?.length ? ` Mostly ${esc3(c.languages.slice(0, -1).join(", "))}${c.languages.length > 1 ? " and " : ""}${esc3(c.languages[c.languages.length - 1])}.` : ""}${c.url && /^https?:\/\//.test(c.url) ? ` <a href="${esc3(c.url)}" rel="noopener">${esc3(c.url.replace(/^https?:\/\//, ""))}</a>` : ""}</p>${w2.length ? `<div class="bars" role="img" aria-label="Commits per week">${w2.map((x) => `<span class="${x >= peak * 0.5 ? "" : "quiet"}" style="height:${Math.max(2, x / peak * 100).toFixed(1)}%" title="${x}"></span>`).join("")}</div><div class="bars-legend"><span>${esc3(c.start || "")}</span><span>peak week: ${fmt(peak)}</span><span>this week</span></div>` : ""}`);
  }
  if (s.ai !== false && p.ai && p.ai.total > 0) {
    const a = p.ai, td = days.map((d) => ({ date: d.date, n: d.tokens || 0 })), tpeak = Math.max(1, ...td.map((x) => x.n));
    const share = (n) => a.total ? Math.round(n / a.total * 1e3) / 10 : 0;
    const bars = (rows, alt = false) => {
      const m = Math.max(1, ...rows.map((r) => r[1]));
      return rows.map(([l, n]) => `<div class="hbar"><span>${esc3(l)}</span><span class="track"><span class="fill${alt ? " alt" : ""}" style="width:${(n / m * 100).toFixed(1)}%"></span></span><span class="num" title="${fmt(n)} tokens">${share(n) >= 0.1 ? share(n) + "%" : "&lt;0.1%"}</span></div>`).join("");
    };
    parts.push(`<h2>AI usage</h2><p class="small"><b>${big(a.total)}</b> tokens across <b>${a.models.length}</b> model${a.models.length === 1 ? "" : "s"} in the last ${a.window_days || td.length} days.${a.note ? ` <span class="muted">${esc3(a.note)}</span>` : ""}</p>${td.some((x) => x.n) ? `<div class="bars" role="img" aria-label="AI tokens per day">${td.map((x) => `<span class="${x.n >= tpeak * 0.5 ? "" : "quiet"}" style="height:${Math.max(2, x.n / tpeak * 100).toFixed(1)}%" title="${esc3(x.date)}: ${big(x.n)} tokens"></span>`).join("")}</div><div class="bars-legend"><span>${esc3(td[0]?.date || "")}</span><span>peak day: ${big(tpeak)}</span><span>today</span></div>` : ""}<div class="two-col" style="margin-top:var(--space-4)"><div><div class="label">Models / share of tokens</div>${bars(a.models)}</div>${a.providers?.length ? `<div><div class="label">Providers</div>${bars(a.providers, true)}</div>` : ""}</div>${a.sources && a.sources.length > 1 ? `<div style="margin-top:var(--space-4)"><div class="label">Where the tokens come from</div>${bars(a.sources, true)}</div>` : ""}`);
  }
  if (s.timeline !== false && p.timeline?.length) parts.push(`<h2>Timeline</h2><div class="timeline">${timelineRows(p.timeline)}</div>`);
  if (s.garden !== false && (p.garden?.length || p.gardenExternal)) parts.push(gardenSection(p.garden || [], p.gardenExternal));
  if (s.notes && p.publicNotes.length) parts.push(`<h2>Notes</h2>${p.publicNotes.map((n) => `<div class="pnote" id="${slug("note-" + n.title)}"><div class="pn-title">${esc3(n.title)}</div><div class="pn-ex">${esc3(n.excerpt)}</div><div class="pn-date">${esc3(n.updated.slice(0, 10))}</div></div>`).join("")}`);
  if (s.asks && (p.asks.length || p.offers.length)) parts.push(`<h2>Help exchange</h2><div class="hx-grid">
<div class="hx-card"><div class="label">I could use help with</div>${p.asks.map((a) => `<div class="hx-row"><span>${esc3(a.title)}</span><span class="bounty">+${a.bounty}</span></div>`).join("") || '<div class="muted">Nothing right now</div>'}</div>
<div class="hx-card"><div class="label">I can help with</div>${p.offers.map((o) => `<div class="hx-row"><span>${esc3(o.title)}</span></div>`).join("") || '<div class="muted">Ask me</div>'}</div></div>`);
  if (s.social && p.social) parts.push(`<div class="stat-strip">${[[fmt(p.social.friends), "friends"], [String(p.social.gravity), "gravity"], [fmt(p.social.credits), "help credits"]].map(([v, l]) => `<div class="stat"><div class="v">${v}</div><div class="l">${l}</div></div>`).join("")}</div>`);
  if (s.links && p.links.length) parts.push(`<h2>Elsewhere</h2><ul class="bullets">${p.links.map(([l, u]) => `<li><a href="${esc3(u)}" rel="noopener">${esc3(l)}</a></li>`).join("")}</ul>`);
  parts.push(`<div class="foot">Grown from an Obsidian vault with Caldera. Updated ${esc3(p.updated.slice(0, 16).replace("T", " "))} UTC. <a href="${esc3((p.hub || "https://caldera.social").replace(/\/$/, ""))}/guide.html" target="_blank" rel="noopener">Your page? How to edit it</a></div></div></main>`);
  if (railOn) parts.push(`<aside class="rail">${p.graph?.length ? `<div class="graph"><div class="label">${esc3(p.graphLabel || "Graph")}</div>${graphSvg(p.graph, p.name)}</div>` : ""}${p.backlinks?.length ? `<div><div class="label">${esc3(p.backlinkLabel || "Backlinks")}</div>${p.backlinks.map(([t, c]) => `<div class="backlink"><span>${esc3(t)}</span><div class="ctx">${esc3(c)}</div></div>`).join("")}</div>` : ""}</aside>`);
  parts.push(`</div>`);
  parts.push(`<script>${CLIENT_JS}<\/script></body></html>`);
  const toc = [];
  if (s.journal && journal.length) toc.push(["journal", "Daily journal"]);
  if (s.scoreboard && days.length > 2) toc.push(["scoreboard", "Scoreboard"]);
  const seen = /* @__PURE__ */ new Set();
  let html = parts.join("\n").replace(/<h2>([^<]+)<\/h2>/g, (_m, t) => {
    let id = slug(t);
    while (seen.has(id)) id += "-2";
    seen.add(id);
    toc.push([id, t]);
    return `<h2 id="${id}">${t}</h2>`;
  });
  html = html.replace("%%TOC%%", toc.length > 2 ? `<span class="label">On this page</span><div class="toc">${toc.map(([id, t]) => `<a class="tree-row toc-row" href="#${id}">${t}</a>`).join("")}</div>` : "");
  const garden = s.garden !== false && p.garden?.length ? renderGarden({ name: p.name, handle: p.handle, hub: p.hub, icon: p.icon, theme: p.theme, id: p.id, external: p.gardenExternal, nav: (d, cur) => nav(d, cur) }, p.garden, p.gardenImages) : {};
  const city = s.city !== false && p.city?.districts.length ? { "city.html": renderCity({ name: p.name, handle: p.handle, theme: p.theme, icon: p.icon, nav: (d, cur) => nav(d, cur) }, p.city) } : {};
  return { ...garden, ...city, "index.html": html, "assets/theme.css": theme_default, "assets/profile.css": PROFILE_CSS, "assets/favicon.svg": LOGO_SVG };
}
function navSidebar(p, sideOn, gardenOn, depth, current, toc = "") {
  const up = "../".repeat(depth), onProfile = current === "index.html";
  const fix = (h) => /^https?:\/\//.test(h) ? h : h.startsWith("#") ? onProfile ? h : `${up}index.html${h}` : up + h;
  const pages = [["index.html", p.name || "Profile"]];
  if (gardenOn) pages.push(["garden.html", "Garden home"]);
  if (p.sections?.city !== false && p.city?.districts.length) pages.push(["city.html", "City"]);
  const pageRows = pages.map(([h, l]) => `<a class="tree-row toc-row page-row${h === current ? " is-active" : ""}" href="${onProfile && h === "index.html" ? "#top" : up + h}"${h === current ? ' aria-current="page"' : ""}>${esc3(l)}</a>`).join("");
  const friend = p.handle ? `<a class="tree-row toc-row page-row friend-row" href="obsidian://caldera?friend=${encodeURIComponent(p.handle)}" target="_blank" rel="noopener" title="Opens Obsidian and sends @${esc3(p.handle)} a friend request (needs the Caldera plugin)">+ Add @${esc3(p.handle)} as friend</a>` : "";
  const tree = sideOn && p.tree?.length ? `<span class="label">Vault</span>${sidebarTree(p.tree.map((r) => ({ ...r, current: r.href === "#top" && onProfile || !!r.href && r.href === current })), fix)}` : "";
  return `<nav class="sidebar tree" aria-label="Navigation"><div class="side-inner"><span class="label">Pages</span><div class="toc pages">${pageRows}${friend}</div>${toc}${tree}</div></nav>`;
}
function sidebarTree(rows, fix = (h) => h) {
  const out = [];
  let open3 = false;
  const ok = (h) => !!h && /^(https?:\/\/|#[\w-]+$|garden\.html$|n\/[a-z0-9-]+\.html$)/.test(h);
  const item = (r) => {
    const cls = `tree-row child${r.current ? " is-current" : ""}${r.href ? " is-link" : ""}`;
    if (!ok(r.href)) return `<div class="tree-row child${r.current ? " is-current" : ""}"><span>${esc3(r.name)}</span></div>`;
    const ext = /^https?:\/\//.test(r.href);
    return `<a class="${cls}" href="${esc3(fix(r.href))}"${ext ? ' target="_blank" rel="noopener"' : ""}${r.current ? ' aria-current="page"' : ""}><span>${esc3(r.name)}</span>${ext ? '<span class="ext" aria-hidden="true">&#8599;</span>' : ""}</a>`;
  };
  const gname = (r) => ok(r.href) && !/^https?:/.test(r.href) ? `<a class="g-name g-link" href="${esc3(fix(r.href))}">${esc3(r.name)}</a>` : `<span class="g-name">${esc3(r.name)}</span>`;
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    if (r.child) {
      out.push(item(r));
      continue;
    }
    if (open3) {
      out.push(`</details>`);
      open3 = false;
    }
    const kids = rows.slice(i + 1).findIndex((x) => !x.child), n = kids < 0 ? rows.length - i - 1 : kids;
    const count = r.count != null ? `<span class="count" title="${r.count} notes">${fmt(r.count)}</span>` : n ? `<span class="count">${n}</span>` : "";
    if (!n) {
      out.push(`<div class="tree-row group leaf"><span class="caret" aria-hidden="true"></span>${gname(r)}${count}</div>`);
      open3 = false;
      continue;
    }
    out.push(`<details class="tree-group" open><summary class="tree-row group"><span class="caret" aria-hidden="true"></span>${gname(r)}${count}</summary>`);
    open3 = true;
  }
  if (open3) out.push(`</details>`);
  return out.join("");
}
function splitDetail(t) {
  const masked = t.replace(/\[\[[^\]]*\]\]/g, (m) => "x".repeat(m.length)), i = masked.lastIndexOf(" | ");
  return i < 0 ? [t, ""] : [t.slice(0, i).trim(), t.slice(i + 3).trim()];
}
function timelineRows(rows) {
  let prev = "";
  return rows.map(([y, t]) => {
    const [main, detail] = splitDetail(t);
    if (y.trim().toLowerCase() === "era") {
      prev = "";
      return `<div class="era"><span class="era-name">${inline(main)}</span>${detail ? `<span class="era-range">${esc3(detail)}</span>` : ""}</div>`;
    }
    const same = y === prev;
    prev = y;
    return `<div class="row${same ? " same" : ""}"><span class="year">${same ? "" : esc3(y)}</span><span class="dot" aria-hidden="true"></span><div class="what"><div>${inline(main)}</div>${detail ? `<div class="detail">${inline(detail)}</div>` : ""}</div></div>`;
  }).join("");
}
var LOGO_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="7" fill="#1C1C1F"/><path d="M4 25 L12 10 L15 15 L18 8 L28 25 Z" fill="#8B6CF6"/><circle cx="16" cy="21" r="2.4" fill="#4FB89A"/></svg>';
var HEAT_JS = "(function(){var g=document.querySelector('.heat');if(!g)return;var box=g.closest('.heat-box');if(!box)return;\nvar tip=box.querySelector('.heat-tip'),rd=box.querySelector('.heat-read'),mo=box.querySelector('.heat-months');\nvar cells=[].slice.call(g.querySelectorAll('i[data-d]'));if(!cells.length)return;var unit=box.getAttribute('data-unit')||'updates';\nvar D=function(s){return new Date(s+'T12:00:00')};\nvar fd=function(s){return D(s).toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'})};\nvar amt=function(c){var n=+c.getAttribute('data-n');return n?n.toLocaleString('en-US')+' '+(n===1?unit.replace(/s$/,''):unit):'No activity'};\nvar today=cells[cells.length-1],cur=null,pin=null;today.classList.add('is-today');\nfunction months(){if(!mo)return;mo.innerHTML='';var last=-1,lm=-1;cells.forEach(function(c){var x=c.offsetLeft-g.offsetLeft;if(x===last)return;last=x;var m=D(c.getAttribute('data-d')).getMonth();if(m!==lm){if(x<=g.offsetWidth-26&&(lm>=0||D(c.getAttribute('data-d')).getDate()<=7)){var s=document.createElement('span');s.textContent=D(c.getAttribute('data-d')).toLocaleDateString('en-US',{month:'short'});s.style.left=x+'px';mo.appendChild(s)}lm=m}})}months();\nfunction sel(c,show){if(cur)cur.classList.remove('is-sel');cur=c;c.classList.add('is-sel');\nrd.textContent='';var b=document.createElement('b');b.textContent=(c===today?'Today, ':'')+fd(c.getAttribute('data-d'));rd.appendChild(b);rd.appendChild(document.createTextNode(' \xB7 '+amt(c)));\nif(!show){tip.hidden=true;return}tip.textContent=fd(c.getAttribute('data-d'))+' \xB7 '+amt(c);tip.hidden=false;\nvar r=c.getBoundingClientRect(),br=box.getBoundingClientRect(),w=tip.offsetWidth,x=r.left-br.left+r.width/2;var cx=x;x=Math.max(w/2,Math.min(br.width-w/2,x));tip.style.left=x+'px';tip.style.setProperty('--ax',(cx-x)+'px');tip.style.top=(r.top-br.top)+'px'}\nvar wr=g.parentNode;if(wr.scrollWidth>wr.clientWidth)wr.scrollLeft=wr.scrollWidth;\nsel(today,false);\nvar at=function(e){return e.target.closest?e.target.closest('i[data-d]'):null};\ng.addEventListener('mouseover',function(e){var c=at(e);if(c)sel(c,true)});\ng.addEventListener('mouseleave',function(){sel(pin||today,false)});\ng.addEventListener('click',function(e){var c=at(e);if(!c)return;pin=pin===c?null:c;g.querySelectorAll('.is-pin').forEach(function(x){x.classList.remove('is-pin')});if(pin)pin.classList.add('is-pin');sel(c,true)});\ng.addEventListener('keydown',function(e){var k={ArrowLeft:-7,ArrowRight:7,ArrowUp:-1,ArrowDown:1,Home:-1e6,End:1e6}[e.key];if(k==null){if(e.key==='Escape'){e.stopPropagation();pin=null;sel(today,false)}return}e.preventDefault();e.stopPropagation();var i=cells.indexOf(cur);sel(cells[Math.max(0,Math.min(cells.length-1,i+k))],true)});\ng.addEventListener('focus',function(){sel(cur||today,true)});g.addEventListener('blur',function(){tip.hidden=true});\nwindow.addEventListener('resize',function(){tip.hidden=true;months()})})();";
var INVITE_JS = "(function(){var pop=document.querySelector('.invite-pop');if(!pop)return;var btns=[].slice.call(document.querySelectorAll('[data-invite]'));if(!btns.length)return;\nvar url=pop.getAttribute('data-url'),msg=pop.getAttribute('data-msg'),subj=pop.getAttribute('data-subject')||'Join me on Caldera';\nvar inp=pop.querySelector('.inv-url'),cp=pop.querySelector('.inv-copy'),em=pop.querySelector('.inv-email'),tx=pop.querySelector('.inv-text'),sh=pop.querySelector('.inv-share'),st=pop.querySelector('.inv-status'),x=pop.querySelector('.inv-close');\ninp.value=url;var body=msg+'\\n\\n'+url;em.href='mailto:?subject='+encodeURIComponent(subj)+'&body='+encodeURIComponent(body);tx.href='sms:?&body='+encodeURIComponent(msg+' '+url);\nvar canShare=!!(navigator.share&&(!navigator.canShare||navigator.canShare({url:url})));if(!canShare)sh.hidden=true;\nvar host=pop.parentNode,from=null;\nfunction say(t){st.textContent=t;clearTimeout(say.t);say.t=setTimeout(function(){st.textContent=''},2600)}\nfunction open(b){from=b;pop.hidden=false;var hr=host.getBoundingClientRect(),r=b.getBoundingClientRect();pop.style.top=(r.bottom-hr.top+8)+'px';var l=r.left-hr.left;pop.style.left=Math.max(0,Math.min(hr.width-pop.offsetWidth,l))+'px';btns.forEach(function(x){x.setAttribute('aria-expanded',x===b?'true':'false')});cp.focus()}\nfunction close(back){if(pop.hidden)return;pop.hidden=true;btns.forEach(function(x){x.setAttribute('aria-expanded','false')});if(back&&from)from.focus()}\nbtns.forEach(function(b){b.setAttribute('aria-haspopup','dialog');b.setAttribute('aria-expanded','false');b.addEventListener('click',function(e){e.preventDefault();if(!pop.hidden&&from===b)close(true);else open(b)})});\nfunction fallback(){inp.focus();inp.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}say(ok?'Link copied':'Press Ctrl/Cmd+C to copy')}\ncp.addEventListener('click',function(){if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(url).then(function(){say('Link copied')},fallback)}else fallback()});\ninp.addEventListener('focus',function(){inp.select()});\nsh.addEventListener('click',function(){navigator.share({title:subj,text:msg,url:url}).catch(function(e){if(e&&e.name!=='AbortError'){sh.hidden=true;say('Sharing is not available here. Copy the link instead.')}})});\nx.addEventListener('click',function(){close(true)});\ndocument.addEventListener('keydown',function(e){if(e.key==='Escape'&&!pop.hidden){e.stopPropagation();close(true)}},true);\ndocument.addEventListener('click',function(e){if(!pop.hidden&&!pop.contains(e.target)&&!(e.target.closest&&e.target.closest('[data-invite]')))close(false)});\nwindow.addEventListener('resize',function(){close(false)})})();";
var CLIENT_JS = INVITE_JS + "\n" + HEAT_JS + `
(function(){var L=[].slice.call(document.querySelectorAll('.toc:not(.pages) a'));if(!L.length||!window.IntersectionObserver)return;var by={};L.forEach(function(a){by[a.getAttribute('href').slice(1)]=a});var cur;var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){if(cur)cur.classList.remove('is-active');cur=by[e.target.id];if(cur){cur.classList.add('is-active');var t=cur.parentNode;if(t.scrollWidth>t.clientWidth)t.scrollLeft=cur.offsetLeft-t.clientWidth/2+cur.offsetWidth/2}}})},{rootMargin:'0px 0px -70% 0px'});Object.keys(by).forEach(function(id){var el=document.getElementById(id);if(el)io.observe(el)})})();
(function(){var a=document.getElementById('ago');if(a){var t=Date.parse(a.dataset.ts);var f=function(){var m=Math.max(0,Math.round((Date.now()-t)/60000));a.textContent=m<60?m+'m ago':Math.floor(m/60)+'h '+(m%60)+'m ago'};f();setInterval(f,30000)}
var el=document.getElementById('journal-data');if(!el)return;var days=JSON.parse(el.textContent);if(!days.length)return;var i=Math.max(0,days.length-2);
var body=document.getElementById('jbody'),dt=document.getElementById('jdate'),pv=document.getElementById('jprev'),nx=document.getElementById('jnext');
var esc=function(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
var dl=function(d){return d==null?'':d>0?'<span class="up">&#9650; '+d+'</span>':d<0?'<span class="down">&#9660; '+(-d)+'</span>':'<span class="flat">=</span>'};
var mx=Math.max.apply(null,days.map(function(x){return x.score}).concat([1]));
function r(dir){var d=days[i],L=days.length;dt.textContent=(i===L-1?'Today so far / ':i===L-2?'Yesterday / ':'')+d.label;var C=2*Math.PI*42,p=Math.min(1,d.score/mx);
var sd=d.delta==null?'':(d.delta>=0?'<span class="up">&#9650; '+d.delta+'%</span>':'<span class="down">&#9660; '+(-d.delta)+'%</span>')+' vs day before';
var h='<div class="j-top"><div class="ring-wrap"><svg class="ring" viewBox="0 0 100 100" aria-hidden="true"><circle class="trk" cx="50" cy="50" r="42"></circle><circle class="val" cx="50" cy="50" r="42" style="stroke-dasharray:'+C+';stroke-dashoffset:'+(C*(1-p))+'"></circle></svg><div class="j-score"><div class="v">'+d.score+'</div><div class="l">score</div></div></div>'+
'<div class="j-headline">'+(sd?'<div class="j-delta">'+sd+'</div>':'')+(d.headline?esc(d.headline):'<span class="muted">No journal for this day. Activity only.</span>')+(d.themes.length?'<div class="j-themes">'+d.themes.map(function(t){return'<span>'+esc(t)+'</span>'}).join('')+'</div>':'')+'</div></div>';
if(d.chips.length)h+='<div class="j-chips">'+d.chips.map(function(c){return'<div class="chip"><div class="v">'+c.v+'</div><div class="l">'+esc(c.k)+'</div><div class="dd">'+dl(c.d)+'</div></div>'}).join('')+'</div>';
if(d.focus.length||d.wins.length){h+='<div class="two-col j-lists">';if(d.focus.length)h+='<div><div class="label">Focus</div><ul class="bullets">'+d.focus.map(function(x){return'<li>'+esc(x)+'</li>'}).join('')+'</ul></div>';if(d.wins.length)h+='<div><div class="label">Wins</div><ul class="bullets">'+d.wins.map(function(x){return'<li>'+esc(x)+'</li>'}).join('')+'</ul></div>';h+='</div>'}
body.innerHTML=h;body.classList.remove('flip-l','flip-r');void body.offsetWidth;if(dir)body.classList.add(dir<0?'flip-l':'flip-r');pv.disabled=i===0;nx.disabled=i===L-1}
pv.onclick=function(){if(i>0){i--;r(-1)}};nx.onclick=function(){if(i<days.length-1){i++;r(1)}};document.addEventListener('keydown',function(e){if(e.key==='ArrowLeft')pv.onclick();if(e.key==='ArrowRight')nx.onclick()});r(0)})();`;
function renderPrivateCity(p, city, openBase = "") {
  const q2 = { ...p, city: p.city?.districts.length ? p.city : city };
  const sideOn = p.sections.sidebar !== false && !!p.tree?.length, gardenOn = p.sections.garden !== false && !!p.garden?.length;
  return renderCity({ name: p.name, handle: p.handle, theme: p.theme, icon: p.icon, openBase, nav: (d, cur) => p.sections.sidebar === false ? "" : navSidebar(q2, sideOn, gardenOn, d, cur) }, city);
}

// src/auto.ts
var import_obsidian2 = require("obsidian");
var isoLocal = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
function prettyModel(model) {
  const m = model.trim().replace(/-\d{8}$/, "").split("/").pop().replace(/\./g, "-");
  const c = m.match(/^claude-([a-z]+)-(\d+)(?:-(\d+))?/);
  if (c) return `Claude ${c[1][0].toUpperCase()}${c[1].slice(1)} ${c[2]}${c[3] ? "." + c[3] : ""}`;
  const g = m.match(/^gpt-(\d+)(?:-(\d+))?(.*)$/);
  if (g) return `GPT-${g[1]}${g[2] ? "." + g[2] : ""}${g[3] ? " " + g[3].replace(/^-/, "").replace(/-/g, " ").replace(/\b\w/g, (x) => x.toUpperCase()) : ""}`;
  return m;
}
function providerOf(name) {
  const m = name.toLowerCase();
  if (m.includes("claude")) return "Anthropic";
  if (/^(gpt|o\d|codex)/.test(m)) return "OpenAI";
  if (m.includes("gemini")) return "Google";
  if (m.includes("deepseek")) return "DeepSeek";
  if (m.includes("grok")) return "xAI";
  if (m.includes("llama")) return "Meta";
  if (m.includes("mistral")) return "Mistral";
  return "Other";
}
async function aiUsage(cachePath, windowDays = 45) {
  if (!import_obsidian2.Platform.isDesktopApp) return void 0;
  let fs, path, os;
  try {
    fs = window.require("fs");
    path = window.require("path");
    os = window.require("os");
  } catch {
    return void 0;
  }
  const home = os.homedir(), since = Date.now() - (windowDays + 2) * 864e5;
  let cache = {};
  try {
    cache = JSON.parse(await fs.promises.readFile(cachePath, "utf8"));
  } catch {
  }
  const files = [];
  const walk = async (dir, kind, depth) => {
    let ents = [];
    try {
      ents = await fs.promises.readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory() && depth > 0) await walk(p, kind, depth - 1);
      else if (e.isFile() && e.name.endsWith(".jsonl")) files.push([p, kind]);
    }
  };
  await walk(path.join(home, ".claude", "projects"), "claude", 2);
  await walk(path.join(home, ".codex", "sessions"), "codex", 4);
  if (!files.length) return void 0;
  const next = {};
  for (const [p, kind] of files) {
    let st;
    try {
      st = await fs.promises.stat(p);
    } catch {
      continue;
    }
    if (st.mtimeMs < since) continue;
    const c = cache[p];
    if (c && c.m === st.mtimeMs && c.s === st.size) {
      next[p] = c;
      continue;
    }
    const t = {}, seen = /* @__PURE__ */ new Set();
    let text = "";
    try {
      text = await fs.promises.readFile(p, "utf8");
    } catch {
      continue;
    }
    let model = "gpt-5";
    for (const line of text.split("\n")) {
      if (kind === "claude") {
        if (!line.includes('"usage"') || !line.includes('"assistant"')) continue;
        try {
          const o = JSON.parse(line), msg = o.message || {}, u = msg.usage;
          if (!u || !msg.model || String(msg.model).startsWith("<") || !o.timestamp || seen.has(msg.id)) continue;
          seen.add(msg.id);
          const n = (u.input_tokens || 0) + (u.output_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.cache_read_input_tokens || 0);
          const d = isoLocal(Date.parse(o.timestamp));
          (t[d] || (t[d] = {}))[msg.model] = (t[d][msg.model] || 0) + n;
        } catch {
        }
      } else {
        if (!line.includes('"turn_context"') && !line.includes('"token_count"')) continue;
        try {
          const o = JSON.parse(line), pl = o.payload || {};
          if (o.type === "turn_context" && pl.model) model = pl.model;
          else if (pl.type === "token_count" && o.timestamp) {
            const n = pl.info?.last_token_usage?.total_tokens || 0;
            if (n) {
              const d = isoLocal(Date.parse(o.timestamp));
              (t[d] || (t[d] = {}))[model] = (t[d][model] || 0) + n;
            }
          }
        } catch {
        }
      }
    }
    next[p] = { m: st.mtimeMs, s: st.size, t };
    await new Promise((r) => window.setTimeout(r, 0));
  }
  try {
    await fs.promises.writeFile(cachePath, JSON.stringify(next));
  } catch {
  }
  const first = isoLocal(Date.now() - (windowDays - 1) * 864e5);
  const days = {}, models = /* @__PURE__ */ new Map();
  for (const f of Object.values(next)) for (const [d, ms] of Object.entries(f.t)) {
    if (d < first) continue;
    for (const [m, n] of Object.entries(ms)) {
      days[d] = (days[d] || 0) + n;
      const k = prettyModel(m);
      models.set(k, (models.get(k) || 0) + n);
    }
  }
  const total = Object.values(days).reduce((a, b) => a + b, 0);
  if (!total) return void 0;
  const prov = /* @__PURE__ */ new Map();
  for (const [m, n] of models) prov.set(providerOf(m), (prov.get(providerOf(m)) || 0) + n);
  return {
    total,
    window_days: windowDays,
    days,
    models: [...models].sort((a, b) => b[1] - a[1]).slice(0, 8),
    providers: [...prov].sort((a, b) => b[1] - a[1]),
    note: "Tokens processed by my AI coding agents (Claude Code, Codex) on this computer, including cached context. Counts only."
  };
}
async function githubCode(links) {
  const gh = links.map((l) => l[1]).map((u) => u.match(/^https?:\/\/(?:www\.)?github\.com\/([A-Za-z0-9-]{1,39})\/?$/)).find(Boolean);
  if (!gh) return void 0;
  const user = gh[1];
  try {
    const r = await (0, import_obsidian2.requestUrl)({ url: `https://github.com/users/${user}/contributions`, throw: false });
    if (r.status !== 200) return void 0;
    const html = r.text, byId = /* @__PURE__ */ new Map(), counts = /* @__PURE__ */ new Map();
    for (const m of html.matchAll(/data-date="(\d{4}-\d{2}-\d{2})"[^>]*id="([^"]+)"|id="([^"]+)"[^>]*data-date="(\d{4}-\d{2}-\d{2})"/g)) byId.set(m[2] || m[3], m[1] || m[4]);
    for (const m of html.matchAll(/<tool-tip[^>]*for="([^"]+)"[^>]*>\s*(No|\d[\d,]*) contributions?/g)) {
      const d = byId.get(m[1]);
      if (d) counts.set(d, m[2] === "No" ? 0 : Number(m[2].replace(/,/g, "")));
    }
    if (!counts.size) return void 0;
    const dates = [...counts.keys()].sort(), weekly = [];
    for (let i = 0; i < dates.length; i += 7) weekly.push(dates.slice(i, i + 7).reduce((a, d) => a + (counts.get(d) || 0), 0));
    const commits = [...counts.values()].reduce((a, b) => a + b, 0);
    let repos = 0;
    try {
      const u = await (0, import_obsidian2.requestUrl)({ url: `https://api.github.com/users/${user}`, throw: false });
      repos = u.json?.public_repos || 0;
    } catch {
    }
    const start = (/* @__PURE__ */ new Date(dates[0] + "T12:00:00")).toLocaleDateString("en-US", { month: "short", year: "numeric" });
    return commits ? { commits, repos, weekly, url: `https://github.com/${user}`, start } : void 0;
  } catch {
    return void 0;
  }
}
var KINDS = [
  [/^(person|people|contact|contacts)$/, "People"],
  [/^(company|companies|organization|organisation|org|orgs|organizations)$/, "Companies"],
  [/^(project|projects)$/, "Projects"],
  [/^(source|sources|article|articles|clipping|clippings|paper|papers|reference|references)$/, "Sources"],
  [/^(concept|concepts|idea|ideas|zettel|zettelkasten|permanent)$/, "Ideas & concepts"],
  [/^(book|books|reading)$/, "Books"],
  [/^(meeting|meetings)$/, "Meetings"],
  [/^(daily|dailies|journal|journals|daily-notes|daily notes|daily-digest|diary)$/, "Daily notes"],
  [/^(recipe|recipes)$/, "Recipes"],
  [/^(research)$/, "Research"],
  [/^(course|courses|class|classes|lecture|lectures)$/, "Learning"],
  [/^(podcast|podcasts|video|videos)$/, "Media notes"],
  [/^(tool|tools|software)$/, "Tools"],
  [/^(place|places|travel)$/, "Places"]
];
var kindOf = (v) => {
  const k = String(v ?? "").trim().toLowerCase();
  return (KINDS.find(([rx]) => rx.test(k)) || [])[1];
};
function vaultKinds(app, md) {
  const n = /* @__PURE__ */ new Map();
  for (const f of md) {
    if (f.path.startsWith("Caldera/")) continue;
    const fm = app.metadataCache.getFileCache(f)?.frontmatter || {};
    const label = kindOf(fm.type) || kindOf(fm.category) || (/^\d{4}-\d{2}-\d{2}$/.test(f.basename) ? "Daily notes" : void 0) || f.path.split("/").slice(0, -1).map(kindOf).find(Boolean);
    if (label) n.set(label, (n.get(label) || 0) + 1);
  }
  return [...n].filter(([, c]) => c >= 3).sort((a, b) => b[1] - a[1]).slice(0, 7);
}

// src/collect.ts
var DAY = 864e5;
var fmtN = (n) => n.toLocaleString("en-US");
var iso = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
async function collectProfile(app, s, social) {
  const md = app.vault.getMarkdownFiles();
  let words = 0, links = 0;
  const created = /* @__PURE__ */ new Map(), changed = /* @__PURE__ */ new Map();
  const tagCounts = /* @__PURE__ */ new Map();
  const allow = new Map(s.publicTopics.map(([tag, label]) => [tag.toLowerCase().replace(/^#/, ""), label]));
  const publicNotes = [];
  const journal = /* @__PURE__ */ new Map();
  for (const f of md) {
    created.set(iso(f.stat.ctime), (created.get(iso(f.stat.ctime)) || 0) + 1);
    changed.set(iso(f.stat.mtime), (changed.get(iso(f.stat.mtime)) || 0) + 1);
    const cache = app.metadataCache.getFileCache(f);
    links += (cache?.links?.length || 0) + (cache?.embeds?.length || 0) + (cache?.frontmatterLinks?.length || 0);
    words += Math.round(f.stat.size / 6);
    for (const t of cache ? (0, import_obsidian3.getAllTags)(cache) || [] : []) {
      const k = t.replace(/^#/, "").toLowerCase();
      if (allow.has(k)) tagCounts.set(allow.get(k), (tagCounts.get(allow.get(k)) || 0) + 1);
    }
    const fm = cache?.frontmatter || {};
    if (String(fm.caldera || "").toLowerCase() === "public") {
      const text = await app.vault.cachedRead(f);
      const body = text.replace(/^---[\s\S]*?---\s*/, "");
      const para = body.split(/\n\s*\n/).map((x) => x.replace(/^#+\s.*$/gm, "").trim()).find((x) => x.length > 20) || "";
      publicNotes.push({ title: f.basename, excerpt: para.replace(/\[\[([^\]|]+)(\|[^\]]+)?\]\]/g, "$1").slice(0, 280), updated: new Date(f.stat.mtime).toISOString() });
    }
    const dm = f.basename.match(/^(\d{4}-\d{2}-\d{2})$/);
    if (dm && (fm.caldera_headline || fm.caldera_focus || fm.caldera_wins)) {
      journal.set(dm[1], { headline: fm.caldera_headline, focus: asList(fm.caldera_focus), wins: asList(fm.caldera_wins), themes: asList(fm.caldera_themes) });
    }
  }
  const { garden, gardenImages, gardenFiles, gardenReport } = await collectGarden(app, s, md);
  const external = /* @__PURE__ */ new Map();
  let extra = {};
  const actFile = app.vault.getAbstractFileByPath(s.activityFile);
  if (actFile instanceof import_obsidian3.TFile) {
    try {
      extra = JSON.parse(await app.vault.cachedRead(actFile)) || {};
      for (const d of extra.days || []) external.set(d.date, d);
    } catch {
    }
  }
  if (s.sections.ai !== false && !(extra.ai && typeof extra.ai.total === "number")) {
    const base = app.vault.adapter.getBasePath?.();
    const ai = base ? await aiUsage(`${base}/${app.vault.configDir}/plugins/caldera/ai-cache.json`).catch(() => void 0) : void 0;
    if (ai) {
      extra.ai = ai;
      for (const [d, n] of Object.entries(ai.days)) {
        const e = external.get(d) || { date: d };
        if (!e.tokens) e.tokens = n;
        external.set(d, e);
      }
    }
  }
  if (s.sections.code !== false && !(extra.code && typeof extra.code.commits === "number")) {
    const code = await githubCode(s.links || []).catch(() => void 0);
    if (code) extra.code = code;
  }
  const today = Date.now();
  const daily = [];
  const ownerPublic = [
    s.name,
    s.headline,
    ...(s.links || []).map((l) => l[0]),
    ...(s.properties || []).map((p) => p[1]),
    ...(s.publicTopics || []).map((t) => t[1]),
    ...(s.projects || []).map((p) => p[0]),
    ...(s.tree || []).flatMap((t) => [t[0], ...t[1].split(",")]),
    ...s.graph || [],
    ...(s.backlinks || []).map((b) => b[0]),
    ...s.tabs || []
  ].filter(Boolean).map((x) => String(x).trim());
  const safe = publicTextFilter(ownerPublic);
  const clean = (xs) => xs.filter((x) => safe(x));
  for (let i = s.historyDays - 1; i >= 0; i--) {
    const date = iso(today - i * DAY);
    const ext = external.get(date) || {};
    const j = journal.get(date) || {};
    daily.push({
      date,
      counts: { notes: Math.max(created.get(date) || 0, changed.get(date) || 0), meetings: ext.meetings, emails: ext.emails, prompts: ext.prompts, commits: ext.commits, docs: ext.docs },
      tokens: Number(ext.tokens) || void 0,
      headline: [j.headline || ext.headline].filter((h) => h && safe(String(h)))[0],
      focus: clean(j.focus?.length ? j.focus : asList(ext.focus)),
      wins: clean(j.wins?.length ? j.wins : asList(ext.wins)),
      themes: clean(j.themes?.length ? j.themes : asList(ext.themes))
    });
  }
  if (s.gardenJournal !== false && s.sections.garden !== false) await growGardenFromJournal(app, s, daily, garden, gardenReport);
  let activeDays = 0;
  for (let i = 0; i < 182; i++) {
    const d = iso(today - i * DAY);
    if ((created.get(d) || 0) + (changed.get(d) || 0) > 0) activeDays++;
  }
  const files = {};
  const img = async (vaultPath, name) => {
    const f = vaultPath && app.vault.getAbstractFileByPath(vaultPath);
    if (f instanceof import_obsidian3.TFile) {
      const out = `img/${name}.${f.extension}`;
      files[out] = await app.vault.readBinary(f);
      return out;
    }
    return void 0;
  };
  const inbound = /* @__PURE__ */ new Map();
  const bump = (k) => inbound.set(k, (inbound.get(k) || 0) + 1);
  for (const targets of Object.values(app.metadataCache.resolvedLinks)) for (const t of Object.keys(targets)) bump(t.split("/").pop().replace(/\.md$/i, "").toLowerCase());
  for (const targets of Object.values(app.metadataCache.unresolvedLinks)) for (const t of Object.keys(targets)) bump(t.split("|")[0].split("/").pop().replace(/\.md$/i, "").toLowerCase());
  const linkCount = (name) => inbound.get(name.toLowerCase()) || 0;
  const topTopics = [...tagCounts.entries()].sort((a, b) => b[1] - a[1]);
  const kinds = vaultKinds(app, md);
  const notesSorted = publicNotes.sort((a, b) => b.updated.localeCompare(a.updated)).slice(0, 12);
  const tree = [{ name: "People", child: false }, { name: s.name || "Me", child: true, current: true, href: "#top" }];
  const projUrl = new Map((s.projects || []).map(([n, rest]) => [n.toLowerCase(), (rest.split("|")[1] || "").trim()]));
  const noteIds = new Set(notesSorted.map((n) => n.title.toLowerCase()));
  const hrefFor = (it) => {
    const k = it.toLowerCase(), u = projUrl.get(k);
    if (u !== void 0) return /^https?:\/\//.test(u) ? u : "#projects";
    const g = garden.find((n) => n.title.toLowerCase() === k);
    if (g) return `n/${g.slug}.html`;
    if (noteIds.has(k)) return "#" + slug("note-" + it);
    if (topTopics.some((t) => t[0].toLowerCase() === k)) return "#topics";
    return void 0;
  };
  const folderCount = (folder) => {
    if (!folder) return void 0;
    const pre = folder.replace(/^\/+|\/+$/g, "") + "/";
    const n = md.filter((f) => f.path.startsWith(pre)).length;
    return n || void 0;
  };
  const groups = s.tree?.length ? s.tree.map(([g, items, folder]) => [g, items.split(",").map((x) => x.trim()).filter(Boolean), folder]) : [["Topics", topTopics.slice(0, 5).map((t) => t[0])], ["Notes", notesSorted.slice(0, 5).map((n) => n.title)]];
  if (!s.tree?.length && !topTopics.length && !notesSorted.length)
    for (const [label, n] of kinds) tree.push({ name: label, child: false, count: n });
  for (const [g, items, folder] of groups) {
    const count = folderCount(folder);
    if (!items.length && !count) continue;
    tree.push({ name: g, child: false, count });
    for (const it of items) tree.push({ name: it, child: true, href: hrefFor(it) });
  }
  if (garden.length && s.sections.garden !== false && !tree.some((t) => !t.child && t.name.toLowerCase() === "garden")) {
    tree.push({ name: "Garden", child: false, count: garden.length, href: "garden.html" });
    for (const n of [...garden].sort((a, b) => b.updated.localeCompare(a.updated)).slice(0, 6)) tree.push({ name: n.title, child: true, href: `n/${n.slug}.html` });
  }
  const graph = (s.graph?.length ? s.graph.map((n) => ({ t: n, n: linkCount(n) })) : (topTopics.length ? topTopics : kinds).slice(0, 12).map(([t, n]) => ({ t, n }))).slice(0, 16);
  const backlinks = s.backlinks?.length ? s.backlinks : notesSorted.slice(0, 6).map((n) => [n.title, n.excerpt.slice(0, 70)]);
  const DAYMS = 864e5, todayD = /* @__PURE__ */ new Date();
  todayD.setHours(12, 0, 0, 0);
  const startD = new Date(todayD.getTime() - ((todayD.getDay() + 6) % 7 + 7 * 25) * DAYMS);
  const heat = [];
  for (let t = startD.getTime(); t <= todayD.getTime(); t += DAYMS) {
    const d = iso(t), e = external.get(d) || {};
    heat.push({ date: d, n: (created.get(d) || 0) + (changed.get(d) || 0) + (Number(e.docs) || 0) });
  }
  const createdDays = [...created.keys()].sort();
  const growth = [];
  if (createdDays.length) {
    const first = /* @__PURE__ */ new Date(createdDays[0] + "T12:00:00");
    first.setDate(first.getDate() - (first.getDay() + 6) % 7);
    let total = 0;
    for (let w = first.getTime(); w <= todayD.getTime(); w += 7 * DAYMS) {
      for (let k = 0; k < 7; k++) total += created.get(iso(w + k * DAYMS)) || 0;
      growth.push({ week: iso(w), total });
    }
  }
  const knows = s.knows?.length ? s.knows.map(([label, folder]) => {
    const pre = folder.replace(/^\/+|\/+$/g, "") + "/";
    return [label, md.filter((f) => f.path.startsWith(pre)).length];
  }) : Array.isArray(extra.knows) ? extra.knows.filter((k) => Array.isArray(k) && typeof k[1] === "number").map((k) => [String(k[0]), k[1]]) : kinds;
  const pc = extra.projects && typeof extra.projects === "object" ? extra.projects : {};
  const projects = (s.projects || []).map(([name, rest]) => {
    const [status = "", url = ""] = rest.split("|").map((x) => x.trim());
    return { name, status, url, commits: Number(pc[name]) || void 0 };
  });
  const avatarPath = await img(s.avatarPath, "avatar");
  let icon;
  if (avatarPath) try {
    const bmp = await createImageBitmap(new Blob([files[avatarPath]]));
    const N = 128, side = Math.min(bmp.width, bmp.height) * 0.75, sx = (bmp.width - side) / 2, sy = (bmp.height - side) * 0.12;
    const cv = new OffscreenCanvas(N, N), cx = cv.getContext("2d");
    cx.beginPath();
    cx.arc(N / 2, N / 2, N / 2, 0, Math.PI * 2);
    cx.clip();
    cx.drawImage(bmp, sx, sy, side, side, 0, 0, N, N);
    files["img/icon.png"] = await (await cv.convertToBlob({ type: "image/png" })).arrayBuffer();
    icon = "img/icon.png";
  } catch {
  }
  const data = {
    name: s.name || "Untitled",
    handle: s.handle || void 0,
    headline: s.headline,
    theme: s.theme,
    avatar: avatarPath,
    icon,
    banner: await img(s.bannerPath, "banner"),
    links: s.links.filter((l) => l[0] && l[1]),
    properties: s.properties.filter((p) => p[0] && p[1]),
    sections: s.sections,
    stats: { notes: md.length, words, links, activeDays },
    topics: [...tagCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 18),
    daily,
    publicNotes: notesSorted,
    tabs: s.tabs?.length ? s.tabs : void 0,
    summary: s.summary || void 0,
    now: s.now,
    timeline: s.timeline,
    projects,
    heat,
    growth,
    knows,
    inbox: extra.inbox && Array.isArray(extra.inbox.kinds) ? extra.inbox : void 0,
    code: extra.code && typeof extra.code.commits === "number" ? extra.code : void 0,
    ai: extra.ai && typeof extra.ai.total === "number" && Array.isArray(extra.ai.models) ? extra.ai : void 0,
    extraNumbers: Array.isArray(extra.numbers) ? extra.numbers.filter((x) => Array.isArray(x)).map((x) => [String(x[0]), String(x[1])]) : void 0,
    tree,
    graph,
    graphLabel: s.graph?.length ? "Local graph / sized by linked notes" : topTopics.length ? "Topics / sized by notes" : "The vault / sized by notes",
    backlinks,
    backlinkLabel: s.backlinks?.length ? `Backlinks / ${fmtN(linkCount(s.name || ""))} notes link here` : "Public notes",
    asks: s.asks,
    offers: s.offers,
    social,
    updated: (/* @__PURE__ */ new Date()).toISOString(),
    garden: garden.length ? garden : void 0,
    gardenExternal: s.gardenUrl || void 0,
    gardenImages
  };
  Object.assign(files, gardenFiles);
  let cityPrivate;
  if (s.sections.city !== false) {
    try {
      const path = "Caldera/city.json";
      if (await app.vault.adapter.exists(path)) {
        const raw = JSON.parse(await app.vault.adapter.read(path));
        const repos = parseCityRepos(raw);
        if (repos.length) {
          const byName = new Map(md.map((f) => [f.basename.toLowerCase(), f.path]));
          const resolved = app.metadataCache.resolvedLinks;
          const notes = (project) => {
            const target = byName.get(project.toLowerCase());
            if (!target) return { n: 0, paths: [] };
            const src = md.filter((f) => resolved[f.path]?.[target]).sort((a, b) => b.stat.mtime - a.stat.mtime);
            return { n: src.length, paths: [target, ...src.slice(0, 5).map((f) => f.path)] };
          };
          cityPrivate = cityData(repos, notes, typeof raw.generated === "string" ? raw.generated : void 0);
          const pub = publicCity(cityPrivate, (s.projects || []).map((p) => p[0]));
          if (pub.districts.length) data.city = pub;
        }
      }
    } catch (e) {
      console.warn("Caldera city.json unreadable:", e);
    }
  }
  return { data, files, gardenReport, cityPrivate };
}
function asList(v) {
  if (Array.isArray(v)) return v.map(String).filter(Boolean).slice(0, 3);
  if (typeof v === "string" && v.trim()) return [v.trim()];
  return [];
}
var IMG_EXT = /* @__PURE__ */ new Set(["png", "jpg", "jpeg", "webp"]);
var IMG_MAX = 2e6;
var IMG_TOTAL = 6e6;
function inGarden(path, fm, folder) {
  const flag = String(fm?.caldera ?? "").toLowerCase().trim();
  if (flag === "private" || flag === "friends") return false;
  if (path.startsWith("Caldera/")) return false;
  if (flag === "garden") return true;
  const pre = (folder || "").replace(/^\/+|\/+$/g, "");
  return !!pre && path.startsWith(pre + "/");
}
async function sha256hex(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function collectGarden(app, s, md) {
  const picked = md.filter((f) => inGarden(f.path, app.metadataCache.getFileCache(f)?.frontmatter || {}, s.gardenFolder ?? "Garden"));
  const garden = [], gardenReport = [];
  const gardenFiles = {}, gardenImages = {};
  if (!picked.length) return { garden, gardenImages, gardenFiles, gardenReport };
  const titles = new Map(picked.map((f) => [f.basename.toLowerCase(), f]));
  const used = /* @__PURE__ */ new Set(), slugOf = /* @__PURE__ */ new Map();
  for (const f of picked) {
    let sl = slug(f.basename), k = 2;
    while (used.has(sl)) sl = `${slug(f.basename)}-${k++}`;
    used.add(sl);
    slugOf.set(f, sl);
  }
  const ownerPublic = [s.name, ...(s.links || []).map((l) => l[0]), ...(s.publicTopics || []).map((t) => t[1]), ...(s.projects || []).map((p) => p[0]), ...picked.map((f) => f.basename)].filter(Boolean).map(String);
  const check = publicTextFilter(ownerPublic);
  let imgTotal = 0;
  for (const f of picked) {
    const fm = app.metadataCache.getFileCache(f)?.frontmatter || {};
    const raw = (await app.vault.cachedRead(f)).replace(/^---[\s\S]*?\n---\s*/, "").replace(/%%[\s\S]*?%%/g, "").trim();
    const { text, removed } = redact(raw);
    const out = /* @__PURE__ */ new Set();
    const xlinks = /* @__PURE__ */ new Map();
    for (const m of text.matchAll(/(?<!!)\[\[([^\]|#]+)/g)) {
      const t = m[1].trim(), x = parseXLink(t);
      if (x) {
        xlinks.set(`${x.handle}/${x.slug}`, x);
        continue;
      }
      const hit = titles.get(t.split("/").pop().replace(/\.md$/i, "").toLowerCase());
      if (hit && hit !== f) out.add(slugOf.get(hit));
    }
    for (const m of text.matchAll(/!\[\[([^\]|#]+)/g)) {
      const t = m[1].trim();
      if (gardenImages[t]) continue;
      const dest = app.metadataCache.getFirstLinkpathDest?.(t, f.path) ?? app.vault.getAbstractFileByPath(t);
      if (!(dest instanceof import_obsidian3.TFile) || !IMG_EXT.has(dest.extension.toLowerCase()) || dest.stat.size > IMG_MAX || imgTotal + dest.stat.size > IMG_TOTAL) continue;
      const outPath = `n/img/${slug(dest.basename)}-${slug(String(dest.stat.size))}.${dest.extension.toLowerCase()}`;
      gardenFiles[outPath] = await app.vault.readBinary(dest);
      imgTotal += dest.stat.size;
      gardenImages[t] = outPath;
    }
    const created = Date.parse(String(fm.created || fm.date || "")) || f.stat.ctime;
    const note = {
      slug: slugOf.get(f),
      title: f.basename,
      stage: normStage(fm.stage ?? fm.status),
      license: normLicense(fm.license),
      created: new Date(Math.min(created, f.stat.mtime)).toISOString(),
      updated: new Date(f.stat.mtime).toISOString(),
      markdown: text,
      sha256: await sha256hex(text),
      words: (text.match(/\S+/g) || []).length,
      excerpt: excerptOf(text),
      out: [...out],
      xlinks: [...xlinks.values()],
      tags: asList(fm.tags).map((t) => t.replace(/^#/, ""))
    };
    garden.push(note);
    const flags = text.split("\n").map((l) => l.trim()).filter((l) => l && !l.startsWith("```")).map((line) => ({ line: line.slice(0, 160), why: check.why(line) || "" })).filter((x) => x.why && x.why !== "name").slice(0, 12);
    gardenReport.push({ path: f.path, title: f.basename, slug: note.slug, stage: note.stage, license: note.license, words: note.words, removed, flags });
  }
  return { garden, gardenImages, gardenFiles, gardenReport };
}
async function growGardenFromJournal(app, s, daily, garden, report) {
  const fresh = daily.filter((d) => d.headline || d.focus?.length || d.wins?.length).map((d) => ({ date: d.date, headline: d.headline, focus: d.focus, wins: d.wins, themes: d.themes }));
  const path = `${app.vault.configDir}/plugins/caldera/journal-garden.json`;
  let kept = {};
  try {
    if (await app.vault.adapter.exists(path)) kept = JSON.parse(await app.vault.adapter.read(path)).days || {};
  } catch {
    kept = {};
  }
  for (const d of fresh) kept[d.date] = d;
  const dates = Object.keys(kept).sort().slice(-3650);
  kept = Object.fromEntries(dates.map((k) => [k, kept[k]]));
  try {
    await app.vault.adapter.write(path, JSON.stringify({ days: kept }));
  } catch {
  }
  const pages = journalGarden(Object.values(kept), (s.projects || []).map((p) => p[0]));
  const used = new Set(garden.map((n) => n.slug));
  for (const pg of pages) {
    const planted = garden.find((n) => n.title.toLowerCase() === pg.title.toLowerCase());
    if (planted) {
      planted.markdown += `

## From my journal

${pg.markdown.replace(/^\*[^\n]*\*\n\n/, "").replace(/^## /gm, "### ")}`;
      planted.sha256 = await sha256hex(planted.markdown);
      planted.words = (planted.markdown.match(/\S+/g) || []).length;
      if (pg.updated > planted.updated) planted.updated = pg.updated;
      continue;
    }
    let sl = slug(pg.title), k = 2;
    while (used.has(sl)) sl = `${slug(pg.title)}-${k++}`;
    used.add(sl);
    const note = {
      slug: sl,
      title: pg.title,
      stage: pg.stage,
      license: "all-rights",
      created: pg.created,
      updated: pg.updated,
      markdown: pg.markdown,
      sha256: await sha256hex(pg.markdown),
      words: (pg.markdown.match(/\S+/g) || []).length,
      excerpt: excerptOf(pg.markdown.replace(/^\*[^\n]*\*\n\n/, "").replace(/^## .*$/gm, "")),
      out: [],
      xlinks: [],
      tags: ["journal"]
    };
    garden.push(note);
    report.push({ path: "(grown from your journal)", title: note.title, slug: note.slug, stage: note.stage, license: note.license, words: note.words, removed: 0, flags: [] });
  }
  const byTitle = new Map(garden.map((n) => [n.title.toLowerCase(), n.slug]));
  for (const n of garden) {
    const out = new Set(n.out);
    for (const m of n.markdown.matchAll(/(?<!!)\[\[([^\]|#]+)/g)) {
      const t = m[1].trim();
      if (parseXLink(t)) continue;
      const sl = byTitle.get(t.split("/").pop().replace(/\.md$/i, "").toLowerCase());
      if (sl && sl !== n.slug) out.add(sl);
    }
    n.out = [...out];
  }
}

// src/profile-file.ts
var import_obsidian4 = require("obsidian");
var PROFILE_FILE = "Caldera/profile.md";
var pair = (v) => {
  const [a, ...b] = String(v ?? "").split("|");
  const k = a.trim(), val = b.join("|").trim();
  return k && val ? [k, val] : null;
};
var pairs = (v) => Array.isArray(v) ? v.map(pair).filter(Boolean) : null;
function effectiveSettings(app, s) {
  const f = app.vault.getAbstractFileByPath(PROFILE_FILE);
  const fm = f instanceof import_obsidian4.TFile ? app.metadataCache.getFileCache(f)?.frontmatter : null;
  if (!fm) return s;
  const e = { ...s, sections: { ...s.sections } };
  if (typeof fm.name === "string" && fm.name.trim()) e.name = fm.name.trim();
  if (typeof fm.headline === "string") e.headline = fm.headline.trim();
  if (typeof fm.photo === "string") e.avatarPath = fm.photo.trim();
  if (typeof fm.banner === "string") e.bannerPath = fm.banner.trim();
  e.links = pairs(fm.links) ?? e.links;
  e.properties = pairs(fm.properties) ?? e.properties;
  const topics = pairs(fm.topics);
  if (topics) e.publicTopics = topics.map(([tag, label]) => [tag.replace(/^#/, ""), label]);
  if (fm.sections && typeof fm.sections === "object") for (const [k, v] of Object.entries(fm.sections)) e.sections[k] = v !== false;
  if (typeof fm.listed === "boolean") e.listed = fm.listed;
  if (Array.isArray(fm.sidebar)) e.tree = fm.sidebar.map((x) => {
    const [g = "", items = "", folder = ""] = String(x ?? "").split("|").map((v) => v.trim());
    return [g, items, folder || void 0];
  }).filter(([g]) => g);
  if (Array.isArray(fm.graph)) e.graph = fm.graph.map((x) => String(x).trim()).filter(Boolean).slice(0, 20);
  e.backlinks = pairs(fm.backlinks) ?? e.backlinks;
  if (typeof fm.summary === "string") e.summary = fm.summary.trim();
  if (Array.isArray(fm.now)) e.now = fm.now.map((x) => String(x).trim()).filter(Boolean).slice(0, 8);
  e.timeline = pairs(fm.timeline) ?? e.timeline;
  e.projects = pairs(fm.projects) ?? e.projects;
  e.knows = pairs(fm.knows) ?? e.knows;
  if (typeof fm.garden === "string") e.gardenFolder = fm.garden.trim().replace(/^\/+|\/+$/g, "");
  if (typeof fm.garden_journal === "boolean") e.gardenJournal = fm.garden_journal;
  if (typeof fm.garden_url === "string") e.gardenUrl = /^https:\/\//.test(fm.garden_url.trim()) ? fm.garden_url.trim() : "";
  if (Array.isArray(fm.tabs)) e.tabs = fm.tabs.map((x) => String(x).trim()).filter(Boolean).slice(0, 5);
  return e;
}
var q = (v) => JSON.stringify(v);
function profileFileText(s, hubUrl) {
  const list = (rows) => rows.length ? rows.map((r) => `  - ${q(r)}`).join("\n") : "  []";
  return `---
name: ${q(s.name)}
headline: ${q(s.headline)}
photo: ${q(s.avatarPath)}
banner: ${q(s.bannerPath)}
links:
${list(s.links.map(([a, b]) => `${a} | ${b}`))}
properties:
${list(s.properties.map(([a, b]) => `${a} | ${b}`))}
topics:
${list(s.publicTopics.map(([a, b]) => `${a} | ${b}`))}
sections:
${Object.entries(s.sections).map(([k, v]) => `  ${k}: ${v}`).join("\n")}
listed: ${s.listed !== false}
summary: ${q(s.summary || "")}
now:
${list(s.now || [])}
timeline:
${list((s.timeline || []).map(([a, b]) => `${a} | ${b}`))}
projects:
${list((s.projects || []).map(([a, b]) => `${a} | ${b}`))}
knows:
${list((s.knows || []).map(([a, b]) => `${a} | ${b}`))}
tabs:
${list(s.tabs || [])}
garden: ${q(s.gardenFolder ?? "Garden")}
garden_url: ${q(s.gardenUrl || "")}
garden_journal: ${s.gardenJournal !== false}
sidebar:
${list((s.tree || []).map(([a, b, c]) => `${a} | ${b}${c ? ` | ${c}` : ""}`))}
graph:
${list(s.graph || [])}
backlinks:
${list((s.backlinks || []).map(([a, b]) => `${a} | ${b}`))}
---
# My Caldera profile

This note controls your public page at ${hubUrl.replace(/\/$/, "")}/@${s.handle}/ . Edit the properties above, or ask your AI agent to, and the page republishes itself about a minute after you save. **Everything above is public.**

- **name, headline** - shown at the top of your page.
- **photo, banner** - paths to images in this vault, e.g. \`Attachments/me.jpg\`.
- **links** - \`Label | https://...\`, one per line.
- **properties** - short facts, \`Label | value\` (e.g. \`Based in | Lisbon\`).
- **topics** - which of your tags may be counted publicly, \`tag | Label\`. Tags not listed are never shown.
- **sections** - switch parts of the page on or off: ${Object.keys(s.sections).join(", ")}.
- **listed** - \`true\` shows your card on the People page; \`false\` keeps the page link-only.
- **summary** - a short intro box. Links: \`[[Label|https://...]]\`, bold: \`**text**\`.
- **now** - what you're doing now, one line each.
- **timeline** - \`Year | what happened | optional one-line detail\`. Start a chapter with \`era | Name | 1995-2006\`.
- **projects** - \`Name | status | https://link\`.
- **knows** - \`Label | vault folder\`; shows how many notes are in each folder (counts only).
- **tabs** - extra tab labels in the top bar, like \`Now.md\`.
- **garden** - a folder whose notes are published as full pages (your digital garden). Default \`Garden\`. Any note can also opt in with \`caldera: garden\`; \`caldera: private\` keeps a note out. In a garden note, \`stage: seedling | budding | evergreen\` and \`license: all-rights | cc-by | cc-by-nc | cc0 | ai-licensable\`. Email addresses and phone numbers are removed automatically. Link a friend's note with \`[[@handle/Their note]]\`.
- **garden_journal** - \`true\` (default) grows garden pages from your daily journal: one per public project it keeps mentioning and one per recurring theme. Only journal text that is already public is used. \`false\` turns it off.
- **garden_url** - an existing garden elsewhere (Quartz, Obsidian Publish...), linked from your page.
- **sidebar** - the left column, \`Group | item, item | folder\` (e.g. \`Projects | Garden app, Newsletter | Projects\`). Items that match a project, public note or section on your page become links. The optional folder shows how many notes it holds (a count only). Empty: your topics and public notes.
- **graph** - note names for the graph on the right, sized by how many of your notes link to each (only the count is published). Empty: your topics.
- **backlinks** - the list under the graph, \`Title | short context\`. Empty: your public notes.

Your handle and identity key live in Settings -> Caldera, never here. Guide: ${hubUrl.replace(/\/$/, "")}/guide.html
`;
}
async function ensureProfileFile(app, s, hubUrl) {
  const existing = app.vault.getAbstractFileByPath(PROFILE_FILE);
  if (existing instanceof import_obsidian4.TFile) return existing;
  if (!app.vault.getAbstractFileByPath("Caldera")) await app.vault.createFolder("Caldera").catch(() => {
  });
  return app.vault.create(PROFILE_FILE, profileFileText(s, hubUrl));
}

// src/view.ts
var import_obsidian5 = require("obsidian");

// src/owner.ts
var esc4 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var ago = (iso2, now) => {
  const m = Math.max(0, Math.round((Date.parse(now) - Date.parse(iso2)) / 6e4));
  return m < 60 ? `${m}m ago` : m < 48 * 60 ? `${Math.floor(m / 60)}h ago` : `${Math.floor(m / 1440)} days ago`;
};
var open2 = (r) => `<a class="ow-link" href="#" data-open="${esc4(r.path)}">${esc4(r.title)}</a>`;
var pageName = (p) => p === "index.html" ? "your profile" : p === "garden.html" ? "garden home" : p.replace(/^n\//, "").replace(/\.html$/, "").replace(/-/g, " ");
function renderOwner(o) {
  const out = [];
  const card = (id, title, body, extra = "") => out.push(`<section class="ow-card" id="${id}"><div class="ow-h"><h3>${title}</h3>${extra}</div>${body}</section>`);
  {
    const a = o.activity;
    const when = o.lastLooked ? `since you last looked, ${ago(o.lastLooked, o.now)}` : "in the last 24 hours";
    let body = "";
    if (!a) body = `<p class="ow-muted">Publish your profile to start seeing visits, gravity and links here.</p>`;
    else if ("error" in a) body = `<p class="ow-muted">Couldn't reach the hub (${esc4(a.error)}). Your vault sections below still work offline.</p>`;
    else {
      const tiles = [[a.views, a.views === 1 ? "page view" : "page views"], [a.visitors, a.visitors === 1 ? "visitor" : "visitors"], [a.gravity.length, "gravity"], [a.friends.length, a.friends.length === 1 ? "new friend" : "new friends"]].concat(o.pending ? [[o.pending, o.pending === 1 ? "friend request" : "friend requests"]] : []);
      body += `<div class="ow-tiles">${tiles.map(([n, l]) => `<div class="ow-tile${Number(n) ? " is-up" : ""}"><b>${n}</b><span>${l}</span></div>`).join("")}</div>`;
      const byDay = new Map(a.days.map((d) => [d[0], d])), t0 = Date.parse(o.now);
      const days14 = Array.from({ length: 14 }, (_, i) => {
        const k = new Date(t0 - (13 - i) * 864e5).toISOString().slice(0, 10);
        return byDay.get(k) || [k, 0, 0];
      });
      const max = Math.max(1, ...days14.map((d) => d[1]));
      if (a.days.length) body += `<div class="ow-spark" title="Page views, last 14 days">${days14.map((d) => `<i style="height:${d[1] ? Math.max(6, Math.round(d[1] / max * 100)) : 2}%;${d[1] ? "" : "opacity:.25"}" title="${esc4(d[0])}: ${d[1]} views, ${d[2]} visitors"></i>`).join("")}</div><div class="ow-muted ow-small">Page views, last 14 days &middot; ${a.totalViews.toLocaleString("en-US")} all time</div>`;
      const lines = [];
      if (a.pages.length) lines.push(`<li>Most read: ${a.pages.slice(0, 4).map(([p, n]) => `${esc4(pageName(p))} (${n})`).join(", ")}</li>`);
      for (const g of a.gravity.slice(0, 5)) lines.push(`<li><b>${g.from ? "@" + esc4(g.from) : "Someone"}</b> gave you gravity${g.reason ? `: &ldquo;${esc4(g.reason)}&rdquo;` : ""} <span class="ow-muted">${ago(g.ts, o.now)}</span></li>`);
      for (const f of a.friends.slice(0, 5)) lines.push(`<li>You and <b>${f.handle ? "@" + esc4(f.handle) : "a new friend"}</b> are now friends <span class="ow-muted">${ago(f.ts, o.now)}</span></li>`);
      if (o.pending) lines.push(`<li><a href="#" data-action="panel" class="ow-link">${o.pending} friend request${o.pending === 1 ? "" : "s"} waiting</a></li>`);
      if (a.links.length) lines.push(`<li>Other gardens link to you ${a.links.length} time${a.links.length === 1 ? "" : "s"}: ${a.links.slice(0, 3).map((l) => `@${esc4(l.src_handle)}'s &ldquo;${esc4(l.src_title)}&rdquo;`).join(", ")}</li>`);
      body += lines.length ? `<ul class="ow-list">${lines.join("")}</ul>` : `<p class="ow-muted">Quiet so far. Share your invite link from the Caldera panel to bring friends in.</p>`;
    }
    card("ow-since", "Since you last looked", body, `<span class="ow-muted ow-small">${esc4(when)}</span>`);
  }
  {
    const t = o.today;
    const parts = [];
    if (t.headline) parts.push(`<p class="ow-lead">${esc4(t.headline)}</p>`);
    const chips = Object.entries(t.counts || {}).filter(([, n]) => n > 0).map(([k, n]) => `<span class="ow-chip">${n} ${esc4(k)}</span>`);
    if (chips.length) parts.push(`<div class="ow-chips">${chips.join("")}</div>`);
    for (const [lab, xs] of [["Focus", t.focus], ["Wins", t.wins]]) if (xs?.length) parts.push(`<div class="ow-small"><b>${lab}:</b> ${xs.map(esc4).join(" &middot; ")}</div>`);
    if (t.timeline.length) parts.push(`<ol class="ow-time">${t.timeline.map((r) => `<li><span class="ow-t">${esc4(r.time || "")}</span>${r.kind === "new" ? '<span class="ow-new">new</span>' : ""}${open2(r)}</li>`).join("")}</ol>`);
    else parts.push(`<p class="ow-muted">Nothing written yet today.</p>`);
    card("ow-today", "Today", parts.join(""), `<span class="ow-muted ow-small">${esc4(t.date)}</span>`);
  }
  if (o.onThisDay.some((d) => d.items.length)) card("ow-otd", "On this day", o.onThisDay.filter((d) => d.items.length).map((d) => `<div class="ow-otd"><div class="ow-small ow-muted">${esc4(d.label)} &middot; ${esc4(d.date)}</div>${d.items.slice(0, 2).map((r) => `<div>${open2(r)}${r.excerpt ? `<p class="ow-x">${esc4(r.excerpt)}</p>` : ""}</div>`).join("")}</div>`).join(""));
  if (o.rediscovered) {
    const r = o.rediscovered;
    card("ow-back", "Brought back", `<div class="ow-big">${open2(r)}</div>${r.excerpt ? `<p class="ow-x">${esc4(r.excerpt)}</p>` : ""}<div class="ow-small ow-muted">${esc4(r.why)}</div>`, `<span class="ow-muted ow-small">changes every 3 hours</span>`);
  }
  if (o.patterns.length) card("ow-pat", "Patterns", `<ul class="ow-list">${o.patterns.map((p) => `<li>${p}</li>`).join("")}</ul>`);
  if (o.goals === null) card("ow-goals", "Goals", `<p class="ow-muted">Track goals here with checkboxes in a note. <a href="#" class="ow-link" data-action="goals">Create Caldera/Goals.md</a></p>`);
  else if (o.goals?.length) card(
    "ow-goals",
    "Goals",
    o.goals.map((g) => {
      const pct = g.total ? Math.round(g.done / g.total * 100) : 0;
      return `<div class="ow-goal"><div class="ow-goal-h"><b>${esc4(g.heading)}</b><span class="ow-muted ow-small">${g.done}/${g.total}</span></div><div class="ow-bar"><i style="width:${pct}%"></i></div>${g.open.length ? `<div class="ow-small ow-muted">Next: ${g.open.slice(0, 2).map(esc4).join(" &middot; ")}</div>` : ""}</div>`;
    }).join(""),
    `<a href="#" class="ow-link ow-small" data-open="Caldera/Goals.md">edit</a>`
  );
  return `<style>${OWNER_CSS}</style><div class="ow" id="owner"><div class="ow-top"><span class="ow-lock">&#128274; Only you can see this</span><span class="ow-muted ow-small">Built from your vault inside Obsidian. None of it is published.</span></div><div class="ow-grid">${out.join("")}</div></div>`;
}
var OWNER_CSS = `
.ow{margin:18px 0 26px;padding:16px;border:1px dashed var(--accent);border-radius:var(--radius-md,10px);background:color-mix(in srgb,var(--accent) 5%,transparent)}
.ow-top{display:flex;flex-wrap:wrap;gap:6px 12px;align-items:baseline;margin-bottom:12px}
.ow-lock{font-family:var(--font-mono);font-size:var(--text-xs,12px);text-transform:uppercase;letter-spacing:.05em;color:var(--accent);font-weight:600}
.ow-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));gap:12px}
.ow-card{background:var(--bg-raised);border:1px solid var(--line);border-radius:var(--radius-md,10px);padding:14px 16px;min-width:0}
.ow-card#ow-since,.ow-card#ow-today{grid-column:1/-1}
.ow-h{display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-bottom:8px}
.ow-h h3{margin:0;font-size:1rem;font-family:var(--font-sans);font-weight:600;color:var(--text-strong)}
.ow-muted{color:var(--text-muted)}.ow-small{font-size:var(--text-sm,13px)}
.ow-tiles{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px}
.ow-tile{flex:1 1 90px;padding:8px 10px;border-radius:var(--radius-sm,6px);background:var(--bg-sunken);display:flex;flex-direction:column}
.ow-tile b{font-size:1.35rem;font-variant-numeric:tabular-nums;color:var(--text-muted)}.ow-tile.is-up b{color:var(--accent)}
.ow-tile span{font-size:var(--text-xs,12px);color:var(--text-muted)}
.ow-spark{display:flex;align-items:flex-end;gap:3px;height:38px;margin:4px 0}
.ow-spark i{flex:1;background:var(--accent);opacity:.75;border-radius:2px 2px 0 0;min-height:2px}
.ow-list{margin:8px 0 0;padding-left:18px;display:grid;gap:4px}
.ow-link{color:var(--accent);text-decoration:none}.ow-link:hover{text-decoration:underline}
.ow-lead{margin:0 0 8px;font-weight:500}
.ow-chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px}
.ow-chip{font-size:var(--text-xs,12px);padding:2px 8px;border-radius:999px;background:var(--bg-sunken);color:var(--text-muted);font-variant-numeric:tabular-nums}
.ow-time{list-style:none;margin:10px 0 0;padding:0;display:grid;gap:3px;max-height:260px;overflow:auto;columns:2}
.ow-time li{display:flex;gap:8px;align-items:baseline;min-width:0}
.ow-time .ow-link{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ow-t{font-family:var(--font-mono);font-size:var(--text-xs,12px);color:var(--text-muted);flex:0 0 40px;font-variant-numeric:tabular-nums}
.ow-new{font-size:10px;text-transform:uppercase;letter-spacing:.05em;color:var(--accent);flex:0 0 auto}
.ow-otd{display:grid;gap:4px;margin-bottom:10px}.ow-otd:last-child{margin-bottom:0}
.ow-x{margin:2px 0 0;font-size:var(--text-sm,13px);color:var(--text-muted);display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.ow-big{font-size:1.1rem;font-weight:600}
.ow-goal{margin-bottom:10px}.ow-goal-h{display:flex;justify-content:space-between;gap:8px}
.ow-bar{height:6px;border-radius:3px;background:var(--bg-sunken);margin:4px 0;overflow:hidden}.ow-bar i{display:block;height:100%;background:var(--accent)}
@media (max-width:600px){.ow{padding:12px}.ow-time{columns:1}}
`;

// src/view.ts
var PROFILE_VIEW = "caldera-profile";
var DAY2 = 864e5;
var ymd = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
var hm = (t) => {
  const d = new Date(t);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};
var esc5 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var SKIP = /^(\.|Caldera\/|templates?\/|_templates\/)/i;
var BRIDGE = `(function(){var P=parent;document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a,[data-open],[data-action]');if(!a||a.hasAttribute('data-invite'))return;
var o=a.getAttribute('data-open'),ac=a.getAttribute('data-action');if(o){e.preventDefault();P.postMessage({caldera:'open',path:o},'*');return}if(ac){e.preventDefault();P.postMessage({caldera:'action',name:ac},'*');return}
var h=a.getAttribute('href');if(!h||h.charAt(0)==='#')return;e.preventDefault();P.postMessage({caldera:/^[a-z][a-z0-9+.-]*:/i.test(h)?'ext':'nav',href:h},'*')},true);
var t;addEventListener('scroll',function(){clearTimeout(t);t=setTimeout(function(){P.postMessage({caldera:'scroll',y:scrollY},'*')},250)});
addEventListener('load',function(){var H=%%HASH%%,Y=%%Y%%;var el=H&&document.getElementById(H);if(el)el.scrollIntoView();else if(Y)scrollTo(0,Y)})})();`;
var ProfileView = class extends import_obsidian5.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.mode = "mine";
    this.current = "index.html";
    this.built = null;
    this.owner = "";
    this.scrollY = 0;
    this.timer = null;
    this.busy = false;
  }
  getViewType() {
    return PROFILE_VIEW;
  }
  getDisplayText() {
    return "My profile";
  }
  getIcon() {
    return "user-round";
  }
  async onOpen() {
    const root = this.contentEl;
    root.empty();
    root.addClass("caldera-profile-view");
    const bar = root.createDiv("caldera-pv-bar");
    const seg = bar.createDiv("caldera-pv-seg");
    const mine = seg.createEl("button", { text: "My view", attr: { "aria-label": "Your profile built from your vault, with private sections only you see" } });
    const pub = seg.createEl("button", { text: "Public view", attr: { "aria-label": "Your live page on the hub, exactly as visitors see it" } });
    const setMode = (m) => {
      this.mode = m;
      mine.toggleClass("is-on", m === "mine");
      pub.toggleClass("is-on", m === "public");
      this.scrollY = 0;
      void this.show();
    };
    mine.onclick = () => setMode("mine");
    pub.onclick = () => setMode("public");
    mine.addClass("is-on");
    this.status = bar.createSpan({ cls: "caldera-pv-status" });
    const btn = (icon, label, fn) => {
      const b = bar.createEl("button", { cls: "clickable-icon", attr: { "aria-label": label } });
      (0, import_obsidian5.setIcon)(b, icon);
      b.onclick = () => fn();
    };
    btn("refresh-cw", "Refresh", () => this.refresh(true));
    btn("external-link", "Open in browser", () => this.plugin.settings.handle ? window.open(this.plugin.profileUrl() + (this.current === "index.html" ? "" : this.current)) : new import_obsidian5.Notice("Publish your profile first"));
    if (this.plugin.settings.privateUrl) btn("lock", "Open my private web view (Tailscale)", async () => {
      await this.plugin.pushPrivate(false);
      window.open(this.plugin.settings.privateUrl);
    });
    btn("upload-cloud", "Publish now", async () => {
      const u = await this.plugin.publish();
      if (u && this.mode === "public") void this.show();
    });
    this.frame = root.createEl("iframe", { cls: "caldera-pv-frame" });
    this.frame.setAttr("sandbox", "allow-scripts allow-popups allow-popups-to-escape-sandbox");
    this.registerDomEvent(window, "message", (e) => this.onMessage(e));
    this.registerEvent(this.app.workspace.on("active-leaf-change", (leaf) => {
      if (leaf === this.leaf) this.markLooked(false);
    }));
    this.markLooked(true);
    await this.refresh(false);
    this.timer = window.setInterval(() => {
      if (this.mode === "mine" && this.contentEl.isShown()) void this.refresh(false);
    }, 10 * 6e4);
  }
  async onClose() {
    if (this.timer) window.clearInterval(this.timer);
  }
  /** "Since you last looked" moves forward when you come back after 30+ minutes away, not on every refresh. */
  markLooked(first) {
    const s = this.plugin.settings, now = Date.now(), last = s.ownerLastLooked ? Date.parse(s.ownerLastLooked) : 0;
    if (first || now - last > 30 * 6e4) {
      this.shownLooked = s.ownerLastLooked;
      s.ownerLastLooked = new Date(now).toISOString();
      void this.plugin.saveSettings();
      if (!first) void this.refresh(false);
    }
  }
  async refresh(loud) {
    if (this.busy) return;
    this.busy = true;
    try {
      this.status.setText("Building from your vault...");
      const { data, text, binaries, cityPrivate } = await this.plugin.build();
      const uris = /* @__PURE__ */ new Map();
      for (const [p, buf] of Object.entries(binaries)) {
        const mime = p.endsWith(".png") ? "image/png" : p.endsWith(".webp") ? "image/webp" : p.endsWith(".svg") ? "image/svg+xml" : "image/jpeg";
        uris.set(p, `data:${mime};base64,${b64.enc(new Uint8Array(buf))}`);
      }
      this.built = { text, data, uris, city: cityPrivate?.districts.length ? renderPrivateCity(data, cityPrivate) : void 0 };
      this.owner = renderOwner(await collectOwner(this.app, this.plugin, data, this.shownLooked));
      await this.show();
      if (loud) new import_obsidian5.Notice("Profile refreshed");
    } catch (e) {
      this.status.setText("Couldn't build: " + e.message);
    } finally {
      this.busy = false;
    }
  }
  async show() {
    if (this.mode === "public") {
      if (!this.plugin.settings.handle) {
        this.frame.removeAttribute("src");
        this.frame.srcdoc = `<p style="font-family:sans-serif;padding:24px">Publish your profile to see the public view.</p>`;
        return;
      }
      this.frame.removeAttribute("srcdoc");
      this.frame.src = this.plugin.profileUrl() + this.current + (this.current.includes("?") ? "&" : "?") + "caldera=owner";
      this.status.setText("Live on the hub, as visitors see it");
      return;
    }
    if (!this.built) return;
    this.frame.removeAttribute("src");
    this.frame.srcdoc = this.page(this.current.split("#")[0], this.current.split("#")[1] || "");
    const t = /* @__PURE__ */ new Date();
    this.status.setText(`My view, built ${hm(t.getTime())}. Private sections are only visible here.`);
  }
  page(path, hash) {
    const { text, uris } = this.built;
    let html = path === "city.html" && this.built.city ? this.built.city : text[path] ?? text["index.html"];
    html = html.replace(/<link rel="stylesheet" href="(?:\.\.\/)*(assets\/[\w-]+\.css)">/g, (m, a) => text[a] ? `<style>${text[a]}</style>` : m).replace(/<link rel="(?:icon|apple-touch-icon)"[^>]*>/g, "").replace(/(src|href)="(?:\.\.\/)*([^"#?]+\.(?:png|jpe?g|webp|svg))"/g, (m, k, p) => uris.has(p) ? `${k}="${uris.get(p)}"` : m);
    if (path === "index.html") html = html.replace("<!--caldera:owner-->", this.owner);
    const script = `<script>${BRIDGE.replace("%%HASH%%", JSON.stringify(hash)).replace("%%Y%%", String(hash ? 0 : this.scrollY))}<\/script>`;
    return html.includes("</body>") ? html.replace("</body>", script + "</body>") : html + script;
  }
  onMessage(e) {
    if (e.source !== this.frame?.contentWindow || !e.data || typeof e.data !== "object") return;
    const d = e.data;
    if (d.caldera === "scroll") {
      this.scrollY = Number(d.y) || 0;
      return;
    }
    if (d.caldera === "open" && d.path) {
      void this.app.workspace.openLinkText(d.path, "", true);
      return;
    }
    if (d.caldera === "action") {
      if (d.name === "panel") void this.plugin.openPanel();
      if (d.name === "goals") void this.createGoals();
      return;
    }
    if (d.caldera === "ext" && d.href) {
      const f = d.href.match(/^obsidian:\/\/caldera\?friend=([A-Za-z0-9_-]+)/);
      if (f) return void this.plugin.confirmFriend(f[1]);
      if (/^(https?:|mailto:|sms:)/i.test(d.href)) window.open(d.href);
      return;
    }
    if (d.caldera === "nav" && d.href && this.built) {
      const u = new URL(d.href, "https://profile.local/" + this.current.split("#")[0]);
      let p = decodeURIComponent(u.pathname.slice(1));
      if (!p || p.endsWith("/")) p += "index.html";
      if ((this.built.text[p] !== void 0 || p === "city.html" && this.built.city) && p.endsWith(".html")) {
        this.current = p + (u.hash ? u.hash : "");
        this.scrollY = 0;
        void this.show();
      } else if (this.plugin.settings.handle) window.open(this.plugin.profileUrl() + p);
    }
  }
  async createGoals() {
    const p = "Caldera/Goals.md";
    let f = this.app.vault.getAbstractFileByPath(p);
    if (!f) f = await this.app.vault.create(p, "# Goals\n\nOnly you see these, in the My profile tab. One heading per goal, checkboxes for the steps.\n\n## Example goal\n- [ ] First step\n- [ ] Second step\n");
    if (f instanceof import_obsidian5.TFile) await this.app.workspace.getLeaf(true).openFile(f);
  }
};
async function excerpt(app, f, n = 220) {
  try {
    const t = (await app.vault.cachedRead(f)).replace(/^---[\s\S]*?---\s*/, "");
    const para = t.split(/\n\s*\n/).map((x) => x.replace(/^#+\s.*$/gm, "").trim()).find((x) => x.replace(/[^A-Za-z]/g, "").length > 40 && (x.match(/\|/g) || []).length < 2 && !/^(navigation|nav|tags|source|sources|related|see also|aliases|links?)\s*:/i.test(x) && !/^[-*]?\s*\[\[/.test(x)) || "";
    const clean = para.replace(/!\[\[[^\]]*\]\]/g, "").replace(/\[\[([^\]|]+)(\|([^\]]+))?\]\]/g, (_m, a, _b, l) => l || a).replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/^\s*[-*>]\s+/gm, "").replace(/[*_`=~#]/g, "").replace(/\s+/g, " ").trim();
    return clean.length <= n ? clean : clean.slice(0, n).replace(/\s+\S*$/, "") + "\u2026";
  } catch {
    return "";
  }
}
async function collectOwner(app, plugin, data, lastLooked) {
  const now = Date.now(), today = ymd(now), startToday = /* @__PURE__ */ new Date();
  startToday.setHours(0, 0, 0, 0);
  const files = app.vault.getMarkdownFiles().filter((f) => !SKIP.test(f.path));
  const ref = (f, extra = {}) => ({ title: f.basename, path: f.path, ...extra });
  let activity;
  if (plugin.settings.identity && plugin.settings.handle) {
    try {
      activity = await plugin.ownerActivity(lastLooked || new Date(now - DAY2).toISOString());
    } catch (e) {
      activity = { error: e.message };
    }
  }
  const touched = files.filter((f) => f.stat.mtime >= startToday.getTime()).sort((a, b) => b.stat.mtime - a.stat.mtime);
  const d = data.daily?.[data.daily.length - 1];
  const todayRow = d && d.date === today ? d : void 0;
  const counts = todayRow ? Object.fromEntries(Object.entries(todayRow.counts || {}).filter(([, n]) => typeof n === "number")) : void 0;
  const onThisDay = [];
  for (const [days, label] of [[7, "A week ago"], [30, "A month ago"], [91, "Three months ago"], [365, "A year ago"]]) {
    const date = ymd(now - days * DAY2);
    const named = files.filter((f) => f.basename.includes(date)).sort((a, b) => Number(/digest|daily|journal/i.test(b.path)) - Number(/digest|daily|journal/i.test(a.path)));
    const made = files.filter((f) => ymd(f.stat.ctime) === date && !named.includes(f)).sort((a, b) => b.stat.size - a.stat.size);
    const pick = [...named, ...made].slice(0, 2);
    onThisDay.push({ label, date, items: await Promise.all(pick.map(async (f) => ref(f, { excerpt: await excerpt(app, f) }))) });
  }
  const mc = app.metadataCache;
  const near = /* @__PURE__ */ new Set();
  for (const f of touched.slice(0, 40)) {
    for (const t of Object.keys(mc.resolvedLinks[f.path] || {})) near.add(t);
    for (const t of mc.getFileCache(f)?.tags || []) near.add(t.tag);
  }
  const old = files.filter((f) => f.stat.mtime < now - 60 * DAY2 && f.stat.size > 1500 && !/\d{4}-\d{2}-\d{2}/.test(f.basename));
  const scored2 = old.map((f) => {
    const links = Object.keys(mc.resolvedLinks[f.path] || {}), tags = (mc.getFileCache(f)?.tags || []).map((t) => t.tag);
    const shared = [...links.filter((l) => near.has(l)), ...tags.filter((t) => near.has(t))];
    return { f, shared, score: shared.length + (near.has(f.path) ? 3 : 0) };
  });
  const block = Math.floor(now / (3 * 36e5));
  const pool = scored2.filter((x) => x.score > 0).sort((a, b) => b.score - a.score).slice(0, 24);
  const choice = pool.length ? pool[block % pool.length] : scored2.length ? scored2[block * 7919 % scored2.length] : void 0;
  let rediscovered;
  if (choice) {
    const s = choice.shared[0];
    const why = near.has(choice.f.path) ? "You linked to this today." : s ? `Connects to what you worked on today: ${s.startsWith("#") ? s : s.split("/").pop().replace(/\.md$/, "")}.` : `Last changed ${new Date(choice.f.stat.mtime).toLocaleDateString("en-US", { month: "short", year: "numeric" })}.`;
    let ex = await excerpt(app, choice.f, 320), pick = choice;
    for (let k = 1; !ex && k < Math.min(6, pool.length || scored2.length); k++) {
      const alt = pool.length ? pool[(block + k) % pool.length] : scored2[(block * 7919 + k) % scored2.length];
      ex = await excerpt(app, alt.f, 320);
      if (ex) pick = alt;
    }
    const s2 = pick.shared[0];
    const why2 = pick === choice ? why : near.has(pick.f.path) ? "You linked to this today." : s2 ? `Connects to what you worked on today: ${s2.startsWith("#") ? s2 : s2.split("/").pop().replace(/\.md$/, "")}.` : `Last changed ${new Date(pick.f.stat.mtime).toLocaleDateString("en-US", { month: "short", year: "numeric" })}.`;
    rediscovered = { ...ref(pick.f, { excerpt: ex }), why: why2 };
  }
  const patterns = [];
  const daily = data.daily || [];
  const sum = (xs) => xs.reduce((a, x) => a + (Number(x.counts?.notes) || 0), 0);
  const wk = sum(daily.slice(-7)), prev = sum(daily.slice(-14, -7));
  if (wk) patterns.push(`<b>${wk}</b> notes written or changed this week${prev ? `, ${wk >= prev ? "up" : "down"} ${Math.abs(Math.round((wk - prev) / prev * 100))}% on last week` : ""}.`);
  const hours = new Array(24).fill(0);
  for (const f of files) if (f.stat.mtime > now - 30 * DAY2) hours[new Date(f.stat.mtime).getHours()]++;
  const peak = hours.indexOf(Math.max(...hours));
  if (hours[peak] > 5) patterns.push(`Most of your writing lands around <b>${peak === 0 ? "midnight" : peak < 12 ? peak + "am" : peak === 12 ? "noon" : peak - 12 + "pm"}</b> (last 30 days).`);
  const tally = (lo, hi) => {
    const m = /* @__PURE__ */ new Map();
    for (const f of files) if (f.stat.mtime > now - hi * DAY2 && f.stat.mtime <= now - lo * DAY2) for (const t of Object.keys(mc.resolvedLinks[f.path] || {})) {
      const name = t.split("/").pop().replace(/\.md$/, "");
      if (/\d{4}-\d{2}-\d{2}/.test(name)) continue;
      m.set(name, (m.get(name) || 0) + 1);
    }
    return m;
  };
  const recent = tally(0, 7), before = tally(7, 35);
  const rising = [...recent].map(([k, n]) => [k, n - (before.get(k) || 0) / 4]).filter(([k, s]) => s >= 2 && (recent.get(k) || 0) >= 3).sort((a, b) => b[1] - a[1]).slice(0, 3);
  if (rising.length) patterns.push(`Rising this week: ${rising.map(([k]) => `<b>${esc5(k)}</b>`).join(", ")}.`);
  const heat = data.heat || [];
  if (heat.length) {
    let i = heat.length - 1;
    if (heat[i].n === 0) i--;
    let streak = 0;
    while (i >= 0 && heat[i].n > 0) {
      streak++;
      i--;
    }
    if (streak > 1) patterns.push(`<b>${streak}-day</b> streak of writing in your vault.`);
    const best = heat.reduce((a, b) => b.n > a.n ? b : a);
    const last = heat[heat.length - 1];
    if (last.n > 0 && last.n >= best.n) patterns.push(`Today is your <b>busiest day in 6 months</b> (${last.n} notes touched).`);
    else if (best.n) patterns.push(`Your busiest day in 6 months: ${esc5(best.date)} with ${best.n} notes touched. Today: ${last.n}.`);
  }
  let goals = null;
  const gf = app.vault.getAbstractFileByPath("Caldera/Goals.md");
  if (gf instanceof import_obsidian5.TFile) {
    goals = [];
    let cur = null;
    for (const line of (await app.vault.cachedRead(gf)).split("\n")) {
      const h = line.match(/^#{2,3}\s+(.+)/);
      if (h) {
        cur = { heading: h[1].trim(), done: 0, total: 0, open: [] };
        goals.push(cur);
        continue;
      }
      const c = line.match(/^\s*[-*]\s+\[([ xX])\]\s+(.+)/);
      if (!c) continue;
      if (!cur) {
        cur = { heading: "Goals", done: 0, total: 0, open: [] };
        goals.push(cur);
      }
      cur.total++;
      if (c[1] !== " ") cur.done++;
      else cur.open.push(c[2].trim());
    }
    goals = goals.filter((g) => g.total);
  }
  return {
    now: new Date(now).toISOString(),
    lastLooked,
    activity,
    pending: plugin.pending.length,
    today: {
      date: today,
      headline: todayRow?.headline,
      focus: todayRow?.focus,
      wins: todayRow?.wins,
      counts,
      timeline: touched.slice(0, 30).map((f) => ref(f, { time: hm(f.stat.mtime), kind: f.stat.ctime >= startToday.getTime() ? "new" : "edit" }))
    },
    onThisDay,
    rediscovered,
    patterns,
    goals
  };
}

// src/main.ts
var VIEW = "caldera-panel";
var CalderaPlugin = class extends import_obsidian6.Plugin {
  constructor() {
    super(...arguments);
    this.pending = [];
    this.friends = [];
    this.social = { friends: 0, gravity: 0, credits: 0 };
    this.token = null;
    this.timers = [];
    // republish shortly after the owner (or their agent) edits Caldera/profile.md or the activity file
    this.publishTimer = null;
    this.lastPublishError = "";
  }
  async onload() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    this.addSettingTab(new CalderaSettingTab(this.app, this));
    this.registerView(VIEW, (leaf) => new CalderaView(leaf, this));
    this.registerView(PROFILE_VIEW, (leaf) => new ProfileView(leaf, this));
    this.addRibbonIcon("flame", "Caldera", () => this.openPanel());
    this.addRibbonIcon("user-round", "My Caldera profile", () => this.openProfileTab());
    this.pending = [...this.settings.pendingRequests || []];
    this.registerObsidianProtocolHandler("caldera", (params) => {
      void this.confirmFriend(String(params.friend || ""));
    });
    this.addCommand({ id: "preview", name: "Preview my public profile", callback: () => this.preview() });
    this.addCommand({ id: "publish", name: "Publish my profile", callback: () => this.publish() });
    this.addCommand({ id: "open", name: "Open my public profile", callback: () => this.openProfile() });
    this.addCommand({ id: "profile-tab", name: "Open my profile in Obsidian (My view + Public view)", callback: () => this.openProfileTab() });
    this.addCommand({ id: "profile-file", name: "Edit my profile (open profile.md)", callback: () => this.openProfileFile() });
    this.addCommand({ id: "edit-prompt", name: "Copy AI prompt: change my profile", callback: () => this.copyPrompt("edit") });
    this.addCommand({ id: "whats-new", name: "What's new", callback: () => this.checkReleases(true) });
    this.addCommand({ id: "guide", name: "Open the guide", callback: () => window.open(this.settings.hubUrl.replace(/\/$/, "") + "/guide.html") });
    this.registerEvent(this.app.metadataCache.on("changed", (f, _d, cache) => {
      if (f.path === PROFILE_FILE) this.queuePublish("profile");
      else if (/^\d{4}-\d{2}-\d{2}$/.test(f.basename) && cache?.frontmatter && Object.keys(cache.frontmatter).some((k) => k.startsWith("caldera_"))) this.queuePublish("activity");
    }));
    this.registerEvent(this.app.vault.on("modify", (f) => {
      if (f.path === this.settings.activityFile) this.queuePublish("activity");
    }));
    this.addCommand({ id: "garden-preview", name: "Preview my garden (what goes public + privacy check)", callback: () => this.previewGarden() });
    this.addCommand({ id: "garden-plant", name: "Plant this note in my garden (make it public)", checkCallback: (check) => {
      const f = this.app.workspace.getActiveFile();
      if (!f || f.extension !== "md") return false;
      if (!check) void this.plantNote(f);
      return true;
    } });
    this.addCommand({ id: "welcome", name: "Set up my profile (welcome)", callback: () => new WelcomeModal(this.app, this).open() });
    this.addCommand({ id: "export", name: "Export profile to a vault folder (self-host)", callback: () => this.exportToFolder() });
    this.addCommand({ id: "panel", name: "Open friends panel", callback: () => this.openPanel() });
    this.addCommand({ id: "sync", name: "Sync inbox now", callback: () => this.syncInbox(true) });
    this.addCommand({ id: "share", name: "Share this note with a friend", checkCallback: (check) => {
      const f = this.app.workspace.getActiveFile();
      if (!f) return false;
      if (!check) void this.shareNote(f);
      return true;
    } });
    this.addCommand({ id: "delete", name: "Delete my profile from the hub", callback: () => new ConfirmModal(this.app, "Delete your Caldera profile from the hub? Your page, friendships, asks, offers, gravity and credits on the hub are erased. Your vault is not touched.", async () => {
      try {
        await this.send("profile.delete", {});
        new import_obsidian6.Notice("Your Caldera profile was deleted from the hub.");
      } catch (e) {
        new import_obsidian6.Notice(e.message);
      }
    }).open() });
    this.addCommand({ id: "agent-prompt", name: "Copy AI agent setup prompt (daily journal + activity)", callback: () => this.copyPrompt("setup") });
    this.addCommand({ id: "richer-prompt", name: "Copy AI prompt: make my profile richer", callback: () => this.copyPrompt("richer") });
    this.addCommand({ id: "ask", name: "Post an ask (I could use help with...)", callback: () => new AskModal(this.app, this, "ask").open() });
    this.addCommand({ id: "offer", name: "Post an offer (I can help with...)", callback: () => new AskModal(this.app, this, "offer").open() });
    this.app.workspace.onLayoutReady(() => {
      if (this.settings.openProfileOnStartup) void this.openProfileTab();
      this.schedulePrivatePush();
      if (this.settings.privateWeb) window.setTimeout(() => {
        void this.pushPrivate(false);
      }, 3e4);
      if (this.settings.identity && this.settings.handle) void this.syncInbox(false);
      else if (!this.settings.welcomed) new WelcomeModal(this.app, this).open();
      window.setTimeout(() => {
        void this.checkReleases(false);
      }, 8e3);
      window.setTimeout(() => {
        if (this.settings.identity && this.settings.handle && this.settings.autoPublishHours > 0 && Date.now() - (this.settings.lastPublished || 0) > 6 * 36e5) void this.publish(true);
      }, 2e4);
    });
    this.timers.push(window.setInterval(() => {
      if (this.settings.identity) void this.syncInbox(false);
    }, 10 * 6e4));
    this.scheduleAutoPublish();
  }
  onunload() {
    this.timers.forEach((t) => window.clearInterval(t));
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  async ensureIdentity(quiet = false) {
    if (!this.settings.identity) {
      this.settings.identity = newIdentity();
      await this.saveSettings();
      if (!quiet) new import_obsidian6.Notice("Caldera identity created. Export your recovery key from settings and keep it safe.");
    }
    return this.settings.identity;
  }
  scheduleAutoPublish() {
    if (this._auto) window.clearInterval(this._auto);
    const h = this.settings.autoPublishHours;
    if (h > 0) this._auto = window.setInterval(() => {
      void this.publish(true);
    }, h * 36e5);
  }
  // ---------------------------------------------------------------- hub client
  async api(method, path, body, auth = false) {
    const headers = { "content-type": "application/json" };
    if (auth) headers.authorization = "Bearer " + await this.authToken();
    const r = await (0, import_obsidian6.requestUrl)({ url: this.settings.hubUrl.replace(/\/$/, "") + path, method, headers, body: body ? JSON.stringify(body) : void 0, throw: false });
    if (r.status >= 400) throw new Error(r.json?.error || `hub error ${r.status}`);
    return r.json;
  }
  async send(type, body) {
    return this.api("POST", "/v1/envelopes", sign(await this.ensureIdentity(), type, body));
  }
  async authToken() {
    if (this.token && this.token.until > Date.now()) return this.token.value;
    const me = await this.ensureIdentity();
    const { nonce } = await this.api("POST", "/v1/auth/challenge", { id: me.id });
    const { token, expires_in } = await this.api("POST", "/v1/auth/verify", sign(me, "message", { nonce }));
    this.token = { value: token, until: Date.now() + (expires_in - 60) * 1e3 };
    return token;
  }
  // ---------------------------------------------------------------- profile
  /** Link counts are only right once Obsidian has resolved every link (it re-indexes after a restart). */
  /** Wait until Obsidian has indexed every note (so link counts are right), at most 10s. Obsidian has no public
   *  "resolved" flag and the "resolved" event may already have fired, so check the caches directly. */
  linksResolved() {
    const mc = this.app.metadataCache;
    const ready = () => this.app.vault.getMarkdownFiles().every((f) => mc.getFileCache(f));
    if (ready()) return Promise.resolve();
    return new Promise((r) => {
      const t0 = Date.now();
      const tick = window.setInterval(() => {
        if (ready() || Date.now() - t0 > 1e4) {
          window.clearInterval(tick);
          r();
        }
      }, 250);
    });
  }
  async build() {
    await this.linksResolved();
    const eff = effectiveSettings(this.app, this.settings);
    const { data, files, gardenReport, cityPrivate } = await collectProfile(this.app, eff, eff.sections.social ? this.social : void 0);
    data.hub = this.settings.hubUrl;
    data.id = this.settings.identity?.id;
    const text = renderProfile(data);
    return { data, text, binaries: files, eff, gardenReport, cityPrivate };
  }
  async openProfileFile() {
    const f = await ensureProfileFile(this.app, this.settings, this.settings.hubUrl);
    await this.app.workspace.getLeaf(true).openFile(f);
  }
  queuePublish(reason) {
    if (!this.settings.identity || !this.settings.handle) return;
    if (this.publishTimer) window.clearTimeout(this.publishTimer);
    this.publishTimer = window.setTimeout(() => {
      this.publishTimer = null;
      void this.publish(true).then((url) => {
        if (url && reason === "profile") new import_obsidian6.Notice("Caldera: your public page was updated.");
      });
    }, 45e3);
  }
  // What's new: the hub's release feed, shown only to the owner, inside Obsidian
  async checkReleases(manual = false) {
    try {
      const r = await (0, import_obsidian6.requestUrl)({ url: this.settings.hubUrl.replace(/\/$/, "") + "/releases.json", throw: false });
      const list = r.status === 200 ? r.json?.releases || [] : [];
      if (!list.length) {
        if (manual) new import_obsidian6.Notice("Couldn't load release notes.");
        return;
      }
      const seen = list.findIndex((x) => x.version === this.settings.lastSeenRelease);
      if (!this.settings.lastSeenRelease && !manual) {
        this.settings.lastSeenRelease = list[0].version;
        await this.saveSettings();
        return;
      }
      const unseen = manual ? list.slice(0, 3) : list.slice(0, seen === -1 ? 1 : seen);
      if (!unseen.length) return;
      const open3 = () => {
        new WhatsNewModal(this.app, this, unseen).open();
        this.settings.lastSeenRelease = list[0].version;
        void this.saveSettings();
      };
      if (manual) return open3();
      const frag = createFragment((f) => {
        f.createEl("b", { text: `Caldera ${unseen[0].version}: ` });
        f.appendText(unseen[0].title + " ");
        f.createEl("u", { text: "See what's new" });
      });
      const n = new import_obsidian6.Notice(frag, 2e4);
      n.noticeEl.addEventListener("click", open3);
    } catch {
      if (manual) new import_obsidian6.Notice("Couldn't load release notes.");
    }
  }
  async preview() {
    const { text, binaries } = await this.build();
    let html = text["index.html"].replace('<link rel="stylesheet" href="assets/theme.css">', `<style>${text["assets/theme.css"]}</style>`).replace('<link rel="stylesheet" href="assets/profile.css">', `<style>${text["assets/profile.css"]}</style>`);
    for (const [p, buf] of Object.entries(binaries)) {
      const mime = p.endsWith(".png") ? "image/png" : p.endsWith(".webp") ? "image/webp" : "image/jpeg";
      html = html.split(`src="${p}"`).join(`src="data:${mime};base64,${b64.enc(new Uint8Array(buf))}"`);
    }
    new PreviewModal(this.app, html).open();
  }
  async copyPrompt(kind) {
    const a = this.app.vault.adapter;
    const text = (kind === "richer" ? richerPrompt : kind === "edit" ? editPrompt : agentPrompt)({
      vaultPath: a instanceof import_obsidian6.FileSystemAdapter ? a.getBasePath() : void 0,
      hubUrl: this.settings.hubUrl,
      handle: this.settings.handle || void 0,
      activityFile: this.settings.activityFile,
      publicTopics: this.settings.publicTopics.map((t) => t[0]),
      installed: true
    });
    try {
      await navigator.clipboard.writeText(text);
      new import_obsidian6.Notice(kind === "richer" ? "Prompt copied. Paste it into your AI agent; it asks before making anything public." : "Agent prompt copied. Paste it into your AI agent (Claude Code, Codex, ...) and schedule it daily.");
    } catch {
      new PromptModal(this.app, text).open();
    }
  }
  async publish(quiet = false) {
    this.lastPublishError = "";
    try {
      if (!this.settings.handle) throw new Error("Set a handle in Caldera settings first");
      const me = await this.ensureIdentity();
      const { data, text, binaries, eff } = await this.build();
      const manifest = sign(me, "profile.manifest", {
        name: data.name,
        handle: this.settings.handle,
        boxKey: me.boxPublic,
        headline: data.headline || "",
        photos: { avatar: data.avatar, banner: data.banner },
        links: data.links,
        sections: Object.keys(data.sections).filter((k) => data.sections[k]),
        stats: data.stats,
        daily: data.daily.map((d) => ({ date: d.date, score: activityScore(d.counts), headline: d.headline || "", counts: d.counts })),
        topics: data.topics,
        asks: data.asks,
        offers: data.offers,
        listed: eff.listed !== false,
        page: "index.html",
        updated: data.updated,
        // the garden: every public note with its stage, license and a sha256 of the published text, signed with the profile
        garden: data.garden?.length && eff.sections.garden !== false ? gardenManifest(data.garden) : void 0,
        gardenUrl: data.gardenExternal
      });
      const files = {};
      for (const [p, t] of Object.entries(text)) files[p] = b64.enc(new TextEncoder().encode(t));
      for (const [p, b] of Object.entries(binaries)) files[p] = b64.enc(new Uint8Array(b));
      await this.api("POST", `/v1/profiles/${encodeURIComponent(me.id)}/bundle`, { manifest, files });
      this.settings.lastPublished = Date.now();
      await this.saveSettings();
      if (this.settings.privateWeb) void this.pushPrivate(false);
      const url = this.profileUrl();
      if (!quiet) new import_obsidian6.Notice(`Published: ${url}`);
      return url;
    } catch (e) {
      this.lastPublishError = e.message;
      if (!quiet) new import_obsidian6.Notice("Caldera publish failed: " + e.message);
      else console.warn("Caldera publish failed:", e.message);
      return null;
    }
  }
  async previewGarden() {
    const { gardenReport, eff } = await this.build();
    new GardenPreviewModal(this.app, gardenReport, eff.gardenFolder ?? "Garden", this.settings.handle ? `${this.profileUrl()}garden.html` : "").open();
  }
  /** Opt a note into the garden: caldera: garden + stage + license (only fills what is missing). */
  async plantNote(f) {
    await this.app.fileManager.processFrontMatter(f, (fm) => {
      fm.caldera = "garden";
      if (!fm.stage) fm.stage = "seedling";
      if (!fm.license) fm.license = "all-rights";
    });
    new import_obsidian6.Notice(`"${f.basename}" is now in your garden as a seedling. It goes public on the next publish; run "Preview my garden" to check it first.`);
  }
  profileUrl() {
    return `${this.settings.hubUrl.replace(/\/$/, "")}/@${this.settings.handle}/`;
  }
  openProfile() {
    if (this.settings.handle) window.open(this.profileUrl());
    else new WelcomeModal(this.app, this).open();
  }
  async exportToFolder() {
    const { text, binaries } = await this.build();
    const root = "Caldera/site";
    for (const [p, t] of Object.entries(text)) await this.write(`${root}/${p}`, t);
    for (const [p, b] of Object.entries(binaries)) await this.writeBinary(`${root}/${p}`, b);
    new import_obsidian6.Notice(`Exported to ${root}. Upload that folder to any static host.`);
  }
  // ---------------------------------------------------------------- inbox
  async syncInbox(loud) {
    try {
      const me = await this.ensureIdentity();
      const [{ envelopes }, fr, gr, cr] = await Promise.all([
        this.api("GET", `/v1/inbox/${encodeURIComponent(me.id)}?since=${encodeURIComponent(this.settings.lastInboxSync)}`, void 0, true),
        this.api("GET", `/v1/friends/${encodeURIComponent(me.id)}`),
        this.api("GET", `/v1/gravity/${encodeURIComponent(me.id)}`),
        this.api("GET", `/v1/credits/${encodeURIComponent(me.id)}`)
      ]);
      this.friends = fr.friends;
      this.social = { friends: fr.friends.length, gravity: gr.gravity, credits: cr.balance };
      let cards = 0;
      for (const e of envelopes) {
        if (!verify(e)) continue;
        if (e.type === "friend.request" && !this.friends.some((f) => f.id === e.from) && !this.pending.some((x) => x.from === e.from)) {
          let handle;
          try {
            handle = (await this.api("GET", `/v1/profiles/${encodeURIComponent(e.from)}`)).handle;
          } catch {
          }
          this.pending.push({ request: envelopeHash(e), from: e.from, handle, note: e.body.note, ts: e.ts });
          new import_obsidian6.Notice(`Caldera: friend request from ${handle ? "@" + handle : "someone new"}. Open the Caldera panel to accept.`);
        }
        if (e.type === "friend.accept") new import_obsidian6.Notice("Caldera: a friend request was accepted");
        if (e.type === "gravity") new import_obsidian6.Notice(`Caldera: someone gave you gravity${e.body.reason ? ': "' + e.body.reason + '"' : ""}`);
        if (e.type === "card") {
          if (await this.receiveCard(e)) cards++;
        }
        if (e.ts > this.settings.lastInboxSync) this.settings.lastInboxSync = e.ts;
      }
      this.pending = this.pending.filter((x) => !this.friends.some((f) => f.id === x.from));
      this.settings.pendingRequests = this.pending;
      await this.saveSettings();
      this.refreshPanel();
      if (loud || cards) new import_obsidian6.Notice(`Caldera: inbox synced${cards ? `, ${cards} shared note(s) received` : ""}`);
    } catch (e) {
      if (loud) new import_obsidian6.Notice("Caldera sync failed: " + e.message);
    }
  }
  async receiveCard(e) {
    const me = this.settings.identity;
    const sealed = e.body.payload?.[me.id];
    const sender = this.friends.find((f) => f.id === e.from);
    if (!sealed || !sender?.box_key) return false;
    const text = open(sealed, sender.box_key, me);
    if (text === null) return false;
    const who = sender.handle || e.from.slice(4, 12);
    const safe = String(e.body.title || "Shared note").replace(/[\\/:*?"<>|#^[\]]/g, " ").trim().slice(0, 80);
    const fm = `---
caldera_from: "${who}"
caldera_card: "${e.body.id}"
caldera_version: ${Number(e.body.version) || 1}
caldera_received: ${e.ts}
---
`;
    await this.write(`${this.settings.inboxFolder}/${who}/${safe}.md`, fm + text.replace(/^---[\s\S]*?---\s*/, ""));
    return true;
  }
  async acceptFriend(p) {
    await this.send("friend.accept", { request: p.request, to: p.from });
    this.pending = this.pending.filter((x) => x !== p);
    this.settings.pendingRequests = this.pending;
    await this.syncInbox(false);
    new import_obsidian6.Notice("Friend added");
  }
  /** "Add as friend" from a profile page (obsidian://caldera?friend=) or the My profile tab: confirm, then request. */
  async confirmFriend(raw) {
    const h = raw.replace(/^@/, "").trim();
    if (!/^[a-z0-9_-]{1,40}$/i.test(h)) return;
    if (!this.settings.identity || !this.settings.handle) {
      new import_obsidian6.Notice(`Publish your Caldera profile first, then click "Add @${h} as a friend" again.`);
      return void new WelcomeModal(this.app, this).open();
    }
    if (h.toLowerCase() === this.settings.handle.toLowerCase()) return void new import_obsidian6.Notice("That's your own profile. Share your invite link from the Caldera panel instead.");
    new ConfirmModal(this.app, `Send @${h} a friend request? Once they accept, you can share notes end-to-end encrypted and give each other gravity.`, async () => {
      try {
        await this.requestFriend(h);
      } catch (e) {
        new import_obsidian6.Notice(e.message);
      }
    }, "Send request", "Add a friend").open();
  }
  /** Private activity for the My view tab: visits, gravity, friends, links in. Signed in with the vault's key. */
  async ownerActivity(since) {
    const me = await this.ensureIdentity();
    return this.api("GET", `/v1/owner/${encodeURIComponent(me.id)}/activity?since=${encodeURIComponent(since)}`, void 0, true);
  }
  /** Private web address (Tailscale): push the owner layer, encrypted at rest on the hub, served only to the owner's tailnet login. */
  async pushPrivate(loud = false) {
    if (!this.settings.privateWeb || !this.settings.identity || !this.settings.handle) return null;
    try {
      const { data, cityPrivate } = await this.build();
      const vault = encodeURIComponent(this.app.vault.getName());
      const pages = {};
      if (cityPrivate?.districts.length) pages["city.html"] = renderPrivateCity(data, cityPrivate, `obsidian://open?vault=${vault}&file=`);
      const html = renderOwner(await collectOwner(this.app, this, data, this.settings.ownerLastLooked)).replace(/href="#"((?: [\w-]+="[^"]*")*?) data-open="([^"]*)"/g, (_m, attrs, p) => `${attrs.trim()} href="obsidian://open?vault=${vault}&amp;file=${encodeURIComponent(p.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">"))}" target="_blank" rel="noopener"`).replace(/<a href="#"[^>]*data-action="[^"]*"[^>]*>([\s\S]*?)<\/a>/g, "$1").replace("Built from your vault inside Obsidian. None of it is published.", "Pushed from your vault. Only your Tailscale account can see this page.");
      const me = await this.ensureIdentity();
      const r = await this.api("POST", `/v1/owner/${encodeURIComponent(me.id)}/private`, { html, pages, built: (/* @__PURE__ */ new Date()).toISOString() }, true);
      if (r.url && r.url !== this.settings.privateUrl) {
        this.settings.privateUrl = r.url;
        await this.saveSettings();
      }
      if (loud) new import_obsidian6.Notice("Private view pushed. Open it on any of your Tailscale devices: " + r.url);
      return r.url;
    } catch (e) {
      if (loud) new import_obsidian6.Notice("Couldn't push the private view: " + e.message);
      else console.warn("Caldera private push failed:", e.message);
      return null;
    }
  }
  schedulePrivatePush() {
    if (this._priv) window.clearInterval(this._priv);
    if (this.settings.privateWeb) this._priv = window.setInterval(() => {
      void this.pushPrivate(false);
    }, 10 * 6e4);
  }
  async openProfileTab() {
    const ws = this.app.workspace;
    const existing = ws.getLeavesOfType(PROFILE_VIEW)[0];
    if (existing) return void ws.revealLeaf(existing);
    const leaf = ws.getLeaf("tab");
    await leaf.setViewState({ type: PROFILE_VIEW, active: true });
    ws.revealLeaf(leaf);
  }
  async requestFriend(handleOrId, note = "") {
    const h = handleOrId.trim().replace(/^https?:\/\/[^/]+\/@?/, "").replace(/[/?#].*$/, "").replace(/^@/, "");
    if (!h) throw new Error("Enter a handle, like @orion, or their profile link");
    const pr = await this.api("GET", `/v1/profiles/${encodeURIComponent(h)}`);
    await this.send("friend.request", { to: pr.id, note });
    new import_obsidian6.Notice(`Friend request sent to @${pr.handle || pr.id}`);
  }
  async giveGravity(f, reason) {
    const r = await this.send("gravity", { to: f.id, reason: reason.slice(0, 140) });
    new import_obsidian6.Notice(`Gravity sent. @${f.handle || "friend"} now has ${r.gravity}`);
  }
  async shareNote(file) {
    if (!this.friends.length) await this.syncInbox(false);
    if (!this.friends.length) return new import_obsidian6.Notice("Add a friend first (Caldera panel)");
    new FriendPicker(this.app, this.friends, async (f) => {
      if (!f.box_key) return new import_obsidian6.Notice("That friend has not published a profile yet");
      const me = await this.ensureIdentity();
      const text = await this.app.vault.read(file);
      const version = Date.now();
      await this.send("card", {
        id: "card_" + b58encode(new TextEncoder().encode(file.path)).slice(0, 20),
        title: file.basename,
        to: [f.id],
        payload: { [f.id]: seal(text, f.box_key, me) },
        version
      });
      new import_obsidian6.Notice(`Shared "${file.basename}" with @${f.handle || "friend"} (end-to-end encrypted)`);
    }).open();
  }
  // ---------------------------------------------------------------- utils
  async ensureFolder(path) {
    const parts = (0, import_obsidian6.normalizePath)(path).split("/").slice(0, -1);
    let cur = "";
    for (const p of parts) {
      cur = cur ? `${cur}/${p}` : p;
      if (!this.app.vault.getAbstractFileByPath(cur)) await this.app.vault.createFolder(cur).catch(() => {
      });
    }
  }
  async write(path, text) {
    path = (0, import_obsidian6.normalizePath)(path);
    await this.ensureFolder(path);
    const f = this.app.vault.getAbstractFileByPath(path);
    if (f instanceof import_obsidian6.TFile) await this.app.vault.modify(f, text);
    else await this.app.vault.create(path, text);
  }
  async writeBinary(path, data) {
    path = (0, import_obsidian6.normalizePath)(path);
    await this.ensureFolder(path);
    const f = this.app.vault.getAbstractFileByPath(path);
    if (f instanceof import_obsidian6.TFile) await this.app.vault.modifyBinary(f, data);
    else await this.app.vault.createBinary(path, data);
  }
  async openPanel() {
    let leaf = this.app.workspace.getLeavesOfType(VIEW)[0];
    if (!leaf) {
      leaf = this.app.workspace.getRightLeaf(false);
      await leaf.setViewState({ type: VIEW, active: true });
    }
    void this.app.workspace.revealLeaf(leaf);
  }
  refreshPanel() {
    for (const l of this.app.workspace.getLeavesOfType(VIEW)) l.view.render();
  }
};
var CalderaView = class extends import_obsidian6.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
  }
  getViewType() {
    return VIEW;
  }
  getDisplayText() {
    return "Caldera";
  }
  getIcon() {
    return "flame";
  }
  async onOpen() {
    this.render();
    await this.plugin.syncInbox(false);
  }
  render() {
    const el = this.contentEl;
    el.empty();
    el.addClass("caldera-panel");
    const p = this.plugin, s = p.settings;
    el.createEl("h3", { text: "Caldera" });
    if (!s.identity || !s.handle) {
      el.createEl("p", { text: "Set your name and handle in settings, then publish your profile to join." });
      new import_obsidian6.Setting(el).addButton((b) => b.setButtonText("Open settings").setCta().onClick(() => {
        this.app.setting.open();
        this.app.setting.openTabById("caldera");
      }));
      return;
    }
    const stats = el.createDiv("caldera-stats");
    for (const [v, l] of [[p.social.friends, "friends"], [p.social.gravity, "gravity"], [p.social.credits, "credits"]]) {
      const st = stats.createDiv({ cls: "caldera-stat" });
      st.createEl("b", { text: String(v) });
      st.createSpan({ text: String(l) });
    }
    const actions = el.createDiv("caldera-actions");
    actions.createEl("button", { text: "My profile" }).onclick = () => p.openProfileTab();
    actions.createEl("button", { text: "Publish", cls: "mod-cta" }).onclick = () => p.publish();
    actions.createEl("button", { text: "Sync" }).onclick = () => p.syncInbox(true);
    if (p.pending.length) {
      el.createEl("h4", { text: "Friend requests" });
      for (const r of p.pending) {
        const row = el.createDiv("caldera-row");
        row.createSpan({ text: (r.handle ? "@" + r.handle : r.from.slice(0, 14)) + (r.note ? ` - "${r.note}"` : "") });
        row.createEl("button", { text: "Accept", cls: "mod-cta" }).onclick = () => p.acceptFriend(r);
      }
    }
    el.createEl("h4", { text: "Add a friend" });
    el.createEl("p", { cls: "setting-item-description", text: 'Already on Caldera: enter their handle or paste their profile link. Or click "Add as friend" on their profile page.' });
    let handle = "";
    new import_obsidian6.Setting(el).addText((t) => t.setPlaceholder("@handle or profile link").onChange((v) => handle = v)).addButton((b) => b.setButtonText("Request").onClick(async () => {
      try {
        await p.requestFriend(handle.trim());
      } catch (e) {
        new import_obsidian6.Notice(e.message);
      }
    }));
    el.createEl("h4", { text: "Invite someone new" });
    el.createEl("p", { cls: "setting-item-description", text: "Not on Caldera yet: send them this link. It walks them through installing, then they add you with one click." });
    const inv = `${s.hubUrl.replace(/\/$/, "")}/?invite=${encodeURIComponent(s.handle)}#install`;
    new import_obsidian6.Setting(el).addText((t) => {
      t.setValue(inv);
      t.inputEl.readOnly = true;
      t.inputEl.onfocus = () => t.inputEl.select();
    }).addButton((b) => b.setButtonText("Copy").setCta().onClick(async () => {
      await navigator.clipboard.writeText(inv);
      new import_obsidian6.Notice("Invite link copied");
    }));
    el.createEl("h4", { text: `Friends (${p.friends.length})` });
    for (const f of p.friends) {
      const row = el.createDiv("caldera-row");
      row.createSpan({ text: "@" + (f.handle || f.id.slice(4, 12)) + (f.name ? ` - ${f.name}` : "") });
      row.createEl("button", { text: "+ gravity" }).onclick = () => new GravityModal(this.app, f, (r) => p.giveGravity(f, r)).open();
    }
  }
};
var PreviewModal = class extends import_obsidian6.Modal {
  constructor(app, html) {
    super(app);
    this.html = html;
  }
  onOpen() {
    this.modalEl.addClass("caldera-preview-modal");
    this.titleEl.setText("Public profile preview (exactly what visitors will see)");
    const frame = this.contentEl.createEl("iframe", { cls: "caldera-preview" });
    frame.setAttr("sandbox", "allow-scripts");
    frame.srcdoc = this.html;
  }
};
var FriendPicker = class extends import_obsidian6.SuggestModal {
  constructor(app, list, pick) {
    super(app);
    this.list = list;
    this.pick = pick;
    this.setPlaceholder("Share with which friend?");
  }
  getSuggestions(q2) {
    return this.list.filter((f) => (f.handle || f.name || f.id).toLowerCase().includes(q2.toLowerCase()));
  }
  renderSuggestion(f, el) {
    el.setText("@" + (f.handle || f.id.slice(4, 12)) + (f.name ? ` - ${f.name}` : ""));
  }
  onChooseSuggestion(f) {
    void this.pick(f);
  }
};
var GravityModal = class extends import_obsidian6.Modal {
  constructor(app, f, done) {
    super(app);
    this.f = f;
    this.done = done;
  }
  onOpen() {
    this.titleEl.setText(`Add gravity to @${this.f.handle || "friend"}`);
    this.contentEl.createEl("p", { text: "Gravity is positive only. Say what they helped with (optional)." });
    let reason = "";
    new import_obsidian6.Setting(this.contentEl).addText((t) => t.setPlaceholder("They found me an operator").onChange((v) => reason = v)).addButton((b) => b.setButtonText("Add gravity").setCta().onClick(() => {
      void this.done(reason);
      this.close();
    }));
  }
};
var ConfirmModal = class extends import_obsidian6.Modal {
  constructor(app, msg, yes, label = "Delete", title = "Are you sure?") {
    super(app);
    this.msg = msg;
    this.yes = yes;
    this.label = label;
    this.title = title;
  }
  onOpen() {
    this.titleEl.setText(this.title);
    this.contentEl.createEl("p", { text: this.msg });
    new import_obsidian6.Setting(this.contentEl).addButton((b) => b.setButtonText("Cancel").onClick(() => this.close())).addButton((b) => {
      b.setButtonText(this.label).onClick(() => {
        void this.yes();
        this.close();
      });
      if (this.label === "Delete") b.setWarning();
      else b.setCta();
    });
  }
};
var AskModal = class extends import_obsidian6.Modal {
  constructor(app, plugin, kind) {
    super(app);
    this.plugin = plugin;
    this.kind = kind;
  }
  onOpen() {
    const ask = this.kind === "ask";
    this.titleEl.setText(ask ? "I could use help with..." : "I can help with...");
    let title = "", bounty = 20;
    new import_obsidian6.Setting(this.contentEl).setName("What").addText((t) => t.onChange((v) => title = v));
    if (ask) new import_obsidian6.Setting(this.contentEl).setName("Bounty (help credits)").setDesc("Held until you award it to whoever helps").addText((t) => t.setValue("20").onChange((v) => bounty = Math.max(0, Number(v) || 0)));
    new import_obsidian6.Setting(this.contentEl).addButton((b) => b.setButtonText(ask ? "Post ask" : "Post offer").setCta().onClick(async () => {
      if (!title.trim()) return;
      try {
        const id = newId(ask ? "ask" : "off");
        await this.plugin.send(ask ? "ask" : "offer", ask ? { id, title, bounty, tags: [], visibility: "public" } : { id, title, tags: [] });
        if (ask) this.plugin.settings.asks.push({ id, title, bounty });
        else this.plugin.settings.offers.push({ id, title });
        await this.plugin.saveSettings();
        new import_obsidian6.Notice(ask ? "Ask posted" : "Offer posted");
        this.close();
      } catch (e) {
        new import_obsidian6.Notice(e.message);
      }
    }));
  }
};
var PromptModal = class extends import_obsidian6.Modal {
  constructor(app, text) {
    super(app);
    this.text = text;
  }
  onOpen() {
    this.titleEl.setText("AI agent setup prompt");
    const ta = this.contentEl.createEl("textarea", { cls: "caldera-prompt" });
    ta.value = this.text;
    ta.rows = 18;
    ta.readOnly = true;
    ta.select();
  }
  onClose() {
    this.contentEl.empty();
  }
};
var WelcomeModal = class extends import_obsidian6.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    const s = this.plugin.settings;
    this.modalEl.addClass("caldera-welcome");
    this.titleEl.setText("Welcome to Caldera");
    this.contentEl.createEl("p", { text: "Pick a name and a handle. Caldera creates your identity on this device, publishes your profile, and opens it in your browser. Nothing private leaves your vault." });
    let name = s.name, handle = s.handle, headline = s.headline;
    const status = createDiv({ cls: "caldera-welcome-status" });
    const clean = (v) => v.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 30);
    new import_obsidian6.Setting(this.contentEl).setName("Your name").addText((t) => t.setPlaceholder("Ada Lovelace").setValue(name).onChange((v) => name = v.trim()));
    new import_obsidian6.Setting(this.contentEl).setName("Handle").setDesc(`${s.hubUrl.replace(/^https?:\/\//, "").replace(/\/$/, "")}/@handle`).addText((t) => t.setPlaceholder("ada").setValue(handle).onChange((v) => {
      handle = clean(v);
      if (v !== handle) t.setValue(handle);
      status.setText("");
    }));
    let listed = s.listed !== false;
    new import_obsidian6.Setting(this.contentEl).setName("List me in the directory").setDesc("Your card appears on the public People page. You can change this anytime.").addToggle((t) => t.setValue(listed).onChange((v) => listed = v));
    new import_obsidian6.Setting(this.contentEl).setName("Headline").setDesc("Optional, one line").addText((t) => t.setPlaceholder("Building things with notes").setValue(headline).onChange((v) => headline = v.trim()));
    this.contentEl.appendChild(status);
    const go = new import_obsidian6.Setting(this.contentEl).addButton((b) => b.setButtonText("Create my profile").setCta().onClick(async () => {
      if (!name) {
        status.setText("Add your name.");
        return;
      }
      if (handle.length < 3) {
        status.setText("Handles need at least 3 letters or numbers.");
        return;
      }
      b.setDisabled(true);
      b.setButtonText("Publishing...");
      try {
        const me = await this.plugin.ensureIdentity(true);
        const r = await (0, import_obsidian6.requestUrl)({ url: `${s.hubUrl.replace(/\/$/, "")}/v1/profiles/${handle}`, throw: false });
        if (r.status === 200 && r.json?.id !== me.id) {
          status.setText(`@${handle} is taken. Try another.`);
          b.setDisabled(false);
          b.setButtonText("Create my profile");
          return;
        }
        Object.assign(s, { name, handle, headline, listed });
        if (!s.autoPublishHours) s.autoPublishHours = 6;
        await this.plugin.saveSettings();
        const url = await this.plugin.publish(true);
        if (!url) {
          const why = this.plugin.lastPublishError;
          status.setText(why && !/network|fetch|ENOTFOUND|timed out/i.test(why) ? `Publishing failed: ${why}` : "Publishing failed. Check your connection and try again.");
          b.setDisabled(false);
          b.setButtonText("Create my profile");
          return;
        }
        s.welcomed = true;
        await this.plugin.saveSettings();
        this.plugin.scheduleAutoPublish();
        await ensureProfileFile(this.app, s, s.hubUrl).catch(() => {
        });
        window.open(url);
        this.done(url);
      } catch (e) {
        status.setText(e.message);
        b.setDisabled(false);
        b.setButtonText("Create my profile");
      }
    }));
    go.settingEl.addClass("caldera-welcome-go");
  }
  done(url) {
    this.contentEl.empty();
    this.titleEl.setText("Your profile is live");
    const link = this.contentEl.createEl("p").createEl("a", { text: url, href: url });
    link.addEventListener("click", (e) => {
      e.preventDefault();
      window.open(url);
    });
    this.contentEl.createEl("p", { text: "It updates itself from your vault. To change your name, headline, photo, links or sections, edit the note Caldera/profile.md - or ask your AI agent to. The page republishes about a minute after you save." });
    this.contentEl.createEl("p", { text: "Fill out your page: your AI agent (Claude Code, Codex, Cursor...) can draft your summary, timeline and projects, add a photo and links, and start your daily journal. Copy one prompt, paste it into your AI, and approve what it suggests. AI usage, activity and what your vault knows fill in by themselves." });
    new import_obsidian6.Setting(this.contentEl).addButton((b) => b.setButtonText("Copy AI prompt: fill out my page").setCta().onClick(() => this.plugin.copyPrompt("richer")));
    this.contentEl.createEl("p", { text: "Your login is a key stored in this vault - no password. Save a copy so you can recover your profile on another device:", cls: "caldera-welcome-key" });
    new import_obsidian6.Setting(this.contentEl).addButton((b) => b.setButtonText("Copy recovery key").onClick(async () => {
      await navigator.clipboard.writeText(btoa(JSON.stringify(this.plugin.settings.identity)));
      new import_obsidian6.Notice("Recovery key copied. Paste it into your password manager. Anyone with it can act as you.");
    })).addButton((b) => b.setButtonText("Open my profile").onClick(() => window.open(url))).addButton((b) => b.setButtonText("Done").onClick(() => this.close()));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var WhatsNewModal = class extends import_obsidian6.Modal {
  constructor(app, plugin, releases) {
    super(app);
    this.plugin = plugin;
    this.releases = releases;
  }
  onOpen() {
    this.titleEl.setText("What's new in Caldera");
    for (const r of this.releases) {
      const box = this.contentEl.createDiv({ cls: "caldera-release" });
      box.createDiv({ cls: "caldera-release-meta", text: `${r.version} \xB7 ${r.date}` });
      box.createEl("h3", { text: r.title });
      const ul = box.createEl("ul");
      for (const it of r.items) ul.createEl("li", { text: it });
      if (r.howto) box.createEl("p", { cls: "caldera-release-howto", text: r.howto });
    }
    const hub = this.plugin.settings.hubUrl.replace(/\/$/, "");
    new import_obsidian6.Setting(this.contentEl).addButton((b) => b.setButtonText("All release notes").onClick(() => window.open(hub + "/changelog.html"))).addButton((b) => b.setButtonText("Guide").onClick(() => window.open(hub + "/guide.html"))).addButton((b) => b.setButtonText("Done").setCta().onClick(() => this.close()));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var GardenPreviewModal = class extends import_obsidian6.Modal {
  constructor(app, report, folder, url) {
    super(app);
    this.report = report;
    this.folder = folder;
    this.url = url;
  }
  onOpen() {
    const c = this.contentEl;
    c.empty();
    c.createEl("h2", { text: "Your garden" });
    if (!this.report.length) {
      c.createEl("p", { text: `No garden notes yet. Put notes in the "${this.folder || "(no folder set)"}" folder, or run "Plant this note in my garden" on any note. Nothing is published until you do.` });
      return;
    }
    const words = this.report.reduce((a, r) => a + r.words, 0);
    c.createEl("p", { text: `${this.report.length} notes (${words.toLocaleString()} words) will be public as full pages${this.url ? ` at ${this.url}` : ""}. Email addresses and phone numbers are removed automatically. Lines below were flagged as possibly private: edit them, or add "caldera: private" to keep a note out.` });
    for (const r of this.report) {
      const box = c.createDiv({ cls: "caldera-garden-row" });
      box.createEl("h4", { text: `${r.title}  (${r.stage}, ${LICENSES[r.license]?.short || r.license}, ${r.words} words)` });
      box.createDiv({ text: r.path, cls: "setting-item-description" });
      if (r.removed) box.createDiv({ text: `${r.removed} email/phone value(s) will be removed.` });
      if (!r.flags.length) box.createDiv({ text: "No flagged lines.", cls: "setting-item-description" });
      for (const fl of r.flags) box.createDiv({ text: `[${fl.why}] ${fl.line}` });
    }
  }
};
